"""
Rockwood Planetarium — Comet Survey Software
Rockwood, TX  |  31.9°N  99.1°W

Built on Aladin Lite v3 (real DSS/survey sky) + PyQt6 WebEngine bridge.

Requirements:
    pip install PyQt6 PyQt6-WebEngine websockets

Run:
    python rockwood_planetarium.py
"""

import sys
import math
import datetime
import threading
import json
import http.client
from dataclasses import dataclass
from typing import List, Optional

from PyQt6.QtWidgets import (
    QTextEdit,
    QScrollArea,
    QApplication, QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QLabel, QPushButton, QComboBox, QSlider, QCheckBox, QTableWidget,
    QTableWidgetItem, QHeaderView, QLineEdit, QSplitter, QGroupBox,
    QStatusBar, QSizePolicy, QMessageBox, QInputDialog, QSpinBox,
    QDialog, QDialogButtonBox, QFormLayout, QDoubleSpinBox,
    QListWidget, QTabWidget,
)
from PyQt6.QtCore import (
    Qt, QTimer, pyqtSignal, QObject, QUrl, pyqtSlot,
)
from PyQt6.QtGui import QFont, QColor, QPixmap
from PyQt6.QtCore import QSettings
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineSettings
from PyQt6.QtWebChannel import QWebChannel

# ═════════════════════════════════════════════════════════════════════════════
# SITE CONFIG
# ═════════════════════════════════════════════════════════════════════════════
SITE_LAT   = 31.9
SITE_LON   = -99.1
SITE_NAME  = "Rockwood, TX"
SF_SERVER  = "api.starfront.space"

# ── Observatory camera URLs (Supabase static JPEGs, cache-busted with timestamp) ──
_CAM_BASE = "https://zyssufjepmbhqznfuwcw.supabase.co/storage/v1/object/public/status-assets-public"
CAM_ALLSKY = f"{_CAM_BASE}/building-0009/allsky/images/image.jpg"
CAM_BUILDINGS = {
    "Building 1":  f"{_CAM_BASE}/building-0001/allsky/images/image.jpg",
    "Building 2":  f"{_CAM_BASE}/building-0002/allsky/images/image.jpg",
    "Building 3":  f"{_CAM_BASE}/building-0003/allsky/images/image.jpg",
    "Building 4":  f"{_CAM_BASE}/building-0004/allsky/images/image.jpg",
    "Building 5":  f"{_CAM_BASE}/building-0005/allsky/images/image.jpg",
    "Building 6":  f"{_CAM_BASE}/building-0006/allsky/images/image.jpg",
    "Building 7":  f"{_CAM_BASE}/building-0007/allsky/images/image.jpg",
    "Building 8":  f"{_CAM_BASE}/building-0008/current.jpg",
    "Building 9":  f"{_CAM_BASE}/building-0011/allsky/images/image.jpg",
    "Building 10": f"{_CAM_BASE}/building-0010/current.jpg",
    "Building 19": f"{_CAM_BASE}/building-0019/current.jpg",
    "Building 20": f"{_CAM_BASE}/building-0020/current.jpg",
}
CAM_REFRESH_SECS = 30

# ── Weather resources ──────────────────────────────────────────────────────────
GOES_GIF_URL = "https://cdn.star.nesdis.noaa.gov/GOES16/ABI/SECTOR/sp/GEOCOLOR/GOES16-SP-GEOCOLOR-600x600.gif"

# ── WeatherFlow Tempest API ────────────────────────────────────────────────────
WF_STATION_ID = "174867"
WF_TOKEN      = "e8eafc08-c727-4a35-9786-6988e42d0a09"
WF_URL        = f"https://swd.weatherflow.com/swd/rest/observations/station/{WF_STATION_ID}?token={WF_TOKEN}"
WF_REFRESH_SECS = 60
CLEAR_DARK_SKY = "https://www.cleardarksky.com/c/StrfrntObsTXcsk.gif?c=2725210"

# ─────────────────────────────────────────────────────────────────────────────
# COMET CATALOGUE
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class CometEntry:
    designation: str
    name: str
    ra_h: float
    dec_deg: float
    mag: float
    notes: str = ""

COMET_CATALOG: List[CometEntry] = [
    CometEntry("C/2023 A3", "Tsuchinshan-ATLAS", 14.2, -12.1, 5.8, "Post-perihelion"),
    CometEntry("C/2024 G3", "ATLAS G3",          20.1,  18.4, 7.2, "Elongating"),
    CometEntry("12P",       "Pons-Brooks",        18.5,  44.2, 9.1, "Outburst watch"),
]

# ─────────────────────────────────────────────────────────────────────────────
# ASTRONOMY HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def julian_date(dt: datetime.datetime) -> float:
    a = (14 - dt.month) // 12
    y = dt.year + 4800 - a
    m = dt.month + 12 * a - 3
    jdn = dt.day + (153*m+2)//5 + 365*y + y//4 - y//100 + y//400 - 32045
    return jdn + (dt.hour-12)/24 + dt.minute/1440 + dt.second/86400

def gmst_deg(jd: float) -> float:
    T = (jd - 2451545.0) / 36525.0
    g = (280.46061837 + 360.98564736629*(jd-2451545.0)
         + 0.000387933*T*T - T*T*T/38710000.0)
    return g % 360.0

def lst_deg(dt: datetime.datetime, lon: float) -> float:
    return (gmst_deg(julian_date(dt)) + lon) % 360.0

def ra_dec_to_alt_az(ra_h, dec_deg, lst_d, lat_deg):
    ha  = math.radians(lst_d - ra_h * 15.0)
    dec = math.radians(dec_deg)
    lat = math.radians(lat_deg)
    sin_alt = math.sin(dec)*math.sin(lat) + math.cos(dec)*math.cos(lat)*math.cos(ha)
    sin_alt = max(-1.0, min(1.0, sin_alt))
    alt = math.asin(sin_alt)
    cos_alt = math.cos(alt)
    if cos_alt < 1e-9:
        return math.degrees(alt), 0.0
    sin_az = -math.cos(dec)*math.sin(ha)/cos_alt
    cos_az = (math.sin(dec) - sin_alt*math.sin(lat))/(cos_alt*math.cos(lat))
    return math.degrees(alt), math.degrees(math.atan2(sin_az, cos_az)) % 360.0

def ra_h_to_deg(ra_h: float) -> float:
    return ra_h * 15.0

def rockwood_default_ra_dec(dt: datetime.datetime):
    """
    Centre of the sky as seen from Rockwood TX right now:
    meridian at 35 deg altitude looking SOUTH (az=180).
    dec = lat - (90 - alt) = 31.9 - 55 = -23.1
    Returns (ra_deg, dec_deg).
    """
    lst = lst_deg(dt, SITE_LON)
    # South meridian at alt=35: dec = lat - (90-35) = lat - 55
    dec = SITE_LAT - 55.0   # ≈ -23.1 for Rockwood TX
    ra_deg = lst             # on the meridian: HA=0 → RA=LST
    return ra_deg, dec

# ─────────────────────────────────────────────────────────────────────────────
# JAVASCRIPT / PYTHON BRIDGE
# ─────────────────────────────────────────────────────────────────────────────

class AladinBridge(QObject):
    """Exposed to Aladin page as window.pyBridge via QWebChannel."""
    object_clicked = pyqtSignal(str, float, float)
    view_changed   = pyqtSignal(float, float, float)

    def __init__(self, parent=None):
        super().__init__(parent)

    @pyqtSlot(str, float, float)
    def objectClicked(self, name: str, ra: float, dec: float):
        self.object_clicked.emit(name, ra, dec)

    @pyqtSlot(float, float, float)
    def viewChanged(self, ra: float, dec: float, fov: float):
        win = self.parent()
        win.__view_ra = ra; win.__view_dec = dec; win.__view_fov = fov
        if win._ws_conn:
            import json as _j, asyncio
            loop = getattr(win, "_ws_event_loop", None)
            if loop and loop.is_running():
                asyncio.run_coroutine_threadsafe(
                    win._ws_conn.send(_j.dumps({
                        "_event":"view_pos","ra":ra,"dec":dec,"fov":fov})), loop)

    @pyqtSlot(float, float, float)
    def viewChanged(self, ra: float, dec: float, fov: float):
        self.view_changed.emit(ra, dec, fov)

    @pyqtSlot(int)
    def joinChatZone(self, idx: int):
        self.parent()._on_join_chat(idx)

    @pyqtSlot(str)
    def reportZones(self, zones_json: str):
        import json as _j
        try:
            zones = _j.loads(zones_json)
            self.parent()._cluster_zones = zones
        except Exception:
            pass

    @pyqtSlot(str)
    def log(self, msg: str):
        print(f"[JS] {msg}")

# ─────────────────────────────────────────────────────────────────────────────
# ALADIN HTML
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
# SCOPE COLOR  — deterministic vivid color from scope UUID
# ─────────────────────────────────────────────────────────────────────────────

# A palette of vivid, readable-on-dark-sky colors
_SCOPE_COLORS = [
    "#50e0a0",  # teal-green
    "#e07050",  # coral
    "#60b0ff",  # sky-blue
    "#f0c040",  # amber
    "#c070f0",  # violet
    "#50d0d0",  # cyan
    "#f06090",  # pink
    "#80e040",  # lime
    "#f08030",  # orange
    "#70a0ff",  # periwinkle
    "#e0a050",  # gold
    "#a0f080",  # mint
]

def _scope_color(scope_id: str) -> str:
    """Return a consistent vivid color for a scope based on its UUID."""
    # Hash the UUID to pick a palette index — same ID always gets same color
    h = 0
    for ch in scope_id:
        h = (h * 31 + ord(ch)) & 0xFFFFFF
    return _SCOPE_COLORS[h % len(_SCOPE_COLORS)]

# HTML template is stored in ALADIN_HTML_TEMPLATE (set at module load below)
ALADIN_HTML_TEMPLATE = '<!DOCTYPE html>\n<html>\n<head>\n<meta charset="utf-8"/>\n<style>\n* { margin:0; padding:0; box-sizing:border-box; }\nhtml,body { width:100%; height:100%; background:#000; overflow:hidden; }\n#aladin-lite-div { width:100%; height:100%; }\n#overlay-canvas {\n  position:fixed; top:0; left:0; width:100%; height:100%;\n  pointer-events:none; z-index:9999;\n}\n#hud {\n  position:fixed; bottom:8px; left:8px;\n  color:#7090b0; font:11px \'Courier New\',monospace;\n  background:rgba(5,8,20,.80); padding:6px 10px; border-radius:4px;\n  pointer-events:none; z-index:9999; line-height:1.7;\n}\n</style>\n</head>\n<body>\n<div id="aladin-lite-div"></div>\n<canvas id="overlay-canvas"></canvas>\n<div id="hud">\n  <span id="hud-lst">LST --:--:--</span><br/>\n  <span id="hud-site">Rockwood TX 31.9N 99.1W</span><br/>\n  <span id="hud-cursor">---</span>\n</div>\n<script src="https://aladin.cds.unistra.fr/AladinLite/api/v3/latest/aladin.js"></script>\n<script src="qrc:///qtwebchannel/qwebchannel.js"></script>\n<script>\n"use strict";\nvar SITE_LAT = __LAT__;\nvar SITE_LON = __LON__;\nvar DEG = Math.PI / 180;\nvar aladin = null, pyBridge = null;\nvar scopeData = {}, pendingScopes = null;\nvar _lstOverride = -1;\n\n// Display toggles (set by Python)\nvar showMeridian = false;\nvar showAltAzGrid = false;\n\nfunction computeLST() {\n  if (_lstOverride >= 0) return _lstOverride;\n  var jd = Date.now() / 86400000.0 + 2440587.5;\n  var T  = (jd - 2451545.0) / 36525.0;\n  var g  = (280.46061837 + 360.98564736629*(jd-2451545.0)\n            + 0.000387933*T*T - T*T*T/38710000.0) % 360.0;\n  if (g < 0) g += 360.0;\n  var lst = (g + __LON__) % 360.0;\n  if (lst < 0) lst += 360.0;\n  return lst;\n}\n\nvar ov = document.getElementById(\'overlay-canvas\');\nvar ctx = ov.getContext(\'2d\');\nvar _cW = 0, _cH = 0, _needFull = true;\n\nfunction syncSize() {\n  var W = window.innerWidth || 800, H = window.innerHeight || 600;\n  if (W !== _cW || H !== _cH) {\n    _cW = W; _cH = H;\n    ov.width = W; ov.height = H;\n    _needFull = true;\n  }\n}\nsyncSize();\nwindow.addEventListener(\'resize\', syncSize);\n\n// ── Altitude from RA/Dec ──────────────────────────────────────────────────────\nfunction getAlt(ra_deg, dec_deg) {\n  var lst = computeLST();\n  var h  = (lst - ra_deg) * DEG;\n  var d  = dec_deg * DEG;\n  var lt = SITE_LAT * DEG;\n  var sa = Math.sin(d)*Math.sin(lt) + Math.cos(d)*Math.cos(lt)*Math.cos(h);\n  return Math.asin(Math.max(-1, Math.min(1, sa))) / DEG;\n}\n\n// ── Alt/Az → RA/Dec ──────────────────────────────────────────────────────────\nfunction altaz2radec(alt_deg, az_deg) {\n  var lst = computeLST();\n  var alt = alt_deg * DEG, az = az_deg * DEG, lt = SITE_LAT * DEG;\n  var sinDec = Math.sin(alt)*Math.sin(lt) + Math.cos(alt)*Math.cos(lt)*Math.cos(az);\n  var dec = Math.asin(Math.max(-1, Math.min(1, sinDec)));\n  var cosDec = Math.cos(dec);\n  if (cosDec < 1e-9) return [lst, dec/DEG];\n  var cosHA = (Math.sin(alt) - Math.sin(lt)*sinDec) / (Math.cos(lt)*cosDec);\n  var ha = Math.acos(Math.max(-1, Math.min(1, cosHA)));\n  if (Math.sin(az) > 0) ha = 2*Math.PI - ha;\n  var ra = ((lst - ha/DEG) % 360 + 360) % 360;\n  return [ra, dec/DEG];\n}\n\n// ── Sun & Moon positions ──────────────────────────────────────────────────────\nfunction getJD() { return Date.now() / 86400000.0 + 2440587.5; }\n\nfunction sunRaDec(jd) {\n  var n = jd - 2451545.0;\n  var L = (280.460 + 0.9856474*n) % 360;\n  var g = ((357.528 + 0.9856003*n) % 360) * DEG;\n  var lam = (L + 1.915*Math.sin(g) + 0.020*Math.sin(2*g)) * DEG;\n  var eps = 23.4393 * DEG;\n  var ra = Math.atan2(Math.cos(eps)*Math.sin(lam), Math.cos(lam)) / DEG;\n  if (ra < 0) ra += 360;\n  return [ra, Math.asin(Math.sin(eps)*Math.sin(lam)) / DEG];\n}\n\nfunction moonRaDec(jd) {\n  var n = jd - 2451545.0;\n  var Lm = (218.316 + 13.176396*n) % 360;\n  var Mm = ((134.963 + 13.064993*n) % 360) * DEG;\n  var F  = ((93.272  + 13.229350*n) % 360) * DEG;\n  var Ms = ((357.528 +  0.985600*n) % 360) * DEG;\n  var lam = (Lm + 6.289*Math.sin(Mm) - 1.274*Math.sin(2*F-Mm)\n             + 0.658*Math.sin(2*F) - 0.214*Math.sin(2*Mm)\n             - 0.186*Math.sin(Ms)) * DEG;\n  var beta = (5.128*Math.sin(F) + 0.281*Math.sin(Mm+F) - 0.277*Math.sin(Mm-F)) * DEG;\n  var eps = 23.4393 * DEG;\n  var sinDec = Math.sin(beta)*Math.cos(eps) + Math.cos(beta)*Math.sin(eps)*Math.sin(lam);\n  var dec = Math.asin(Math.max(-1, Math.min(1, sinDec))) / DEG;\n  var cosDec = Math.cos(dec*DEG);\n  if (cosDec < 1e-9) return [0, dec];\n  var sinRa = (Math.cos(beta)*Math.cos(eps)*Math.sin(lam) - Math.sin(beta)*Math.sin(eps)) / cosDec;\n  var cosRa = Math.cos(beta)*Math.cos(lam) / cosDec;\n  var ra = Math.atan2(sinRa, cosRa) / DEG;\n  if (ra < 0) ra += 360;\n  return [ra, dec];\n}\n\nfunction moonPhase(jd) {\n  return ((jd - 2451550.1) % 29.53059) / 29.53059;\n}\n\n// ── Moon phase icon ───────────────────────────────────────────────────────────\nfunction drawMoonIcon(cx, cy, phase, R) {\n  var phaseAngle = phase * 2 * Math.PI;\n  var termX = Math.cos(phaseAngle) * R;   // terminator x-radius\n\n  ctx.save();\n\n  // Dark disc\n  ctx.fillStyle = \'rgba(15,20,40,0.9)\';\n  ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI*2); ctx.fill();\n\n  // Lit portion\n  ctx.fillStyle = \'rgba(215,222,240,0.92)\';\n  ctx.beginPath();\n  if (phase < 0.5) {\n    // Waxing — right limb lit\n    ctx.arc(cx, cy, R, -Math.PI/2, Math.PI/2, false);\n    if (termX >= 0) {\n      ctx.ellipse(cx, cy, termX, R, 0, Math.PI/2, -Math.PI/2, true);\n    } else {\n      ctx.ellipse(cx, cy, -termX, R, 0, Math.PI/2, -Math.PI/2, false);\n    }\n  } else {\n    // Waning — left limb lit\n    ctx.arc(cx, cy, R, Math.PI/2, -Math.PI/2, false);\n    if (termX <= 0) {\n      ctx.ellipse(cx, cy, -termX, R, 0, -Math.PI/2, Math.PI/2, true);\n    } else {\n      ctx.ellipse(cx, cy, termX, R, 0, -Math.PI/2, Math.PI/2, false);\n    }\n  }\n  ctx.closePath();\n  ctx.fill();\n\n  // Rim\n  ctx.strokeStyle = \'rgba(140,155,185,0.5)\';\n  ctx.lineWidth = 0.8;\n  ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI*2); ctx.stroke();\n  ctx.restore();\n}\n\n// ── Alt/Az grid ───────────────────────────────────────────────────────────────\nfunction drawAltAzGrid(W, H) {\n  ctx.save();\n  ctx.strokeStyle = \'rgba(80,110,160,0.35)\';\n  ctx.lineWidth = 0.8;\n  ctx.setLineDash([4, 6]);\n  ctx.font = \'10px Courier New\';\n  ctx.fillStyle = \'rgba(80,120,180,0.7)\';\n  ctx.textAlign = \'left\';\n\n  // Altitude rings: 10, 20, 30, ... 80\n  for (var alt = 10; alt <= 80; alt += 10) {\n    ctx.beginPath();\n    var started = false;\n    for (var az = 0; az <= 360; az += 3) {\n      var rd = altaz2radec(alt, az);\n      var p  = aladin.world2pix(rd[0], rd[1]);\n      if (!p || p[0]==null || isNaN(p[0])) { started = false; continue; }\n      if (!started) { ctx.moveTo(p[0], p[1]); started = true; }\n      else ctx.lineTo(p[0], p[1]);\n    }\n    ctx.stroke();\n    // Label the 30/60 rings at south (az=180)\n    if (alt === 30 || alt === 60) {\n      var rd2 = altaz2radec(alt, 178);\n      var pl  = aladin.world2pix(rd2[0], rd2[1]);\n      if (pl && pl[0]!=null && !isNaN(pl[0]) && pl[0]>0&&pl[0]<W&&pl[1]>0&&pl[1]<H) {\n        ctx.shadowColor=\'rgba(0,0,0,0.8)\'; ctx.shadowBlur=2;\n        ctx.fillText(alt + \'deg\', pl[0]+4, pl[1]-3);\n        ctx.shadowBlur=0;\n      }\n    }\n  }\n\n  // Azimuth spokes: every 30 deg\n  for (var az2 = 0; az2 < 360; az2 += 30) {\n    ctx.beginPath();\n    var started2 = false;\n    for (var alt2 = 2; alt2 <= 88; alt2 += 4) {\n      var rd3 = altaz2radec(alt2, az2);\n      var p3  = aladin.world2pix(rd3[0], rd3[1]);\n      if (!p3 || p3[0]==null || isNaN(p3[0])) { started2 = false; continue; }\n      if (!started2) { ctx.moveTo(p3[0], p3[1]); started2 = true; }\n      else ctx.lineTo(p3[0], p3[1]);\n    }\n    ctx.stroke();\n  }\n\n  ctx.setLineDash([]);\n  ctx.restore();\n}\n\n// ── Meridian line ─────────────────────────────────────────────────────────────\nfunction drawMeridian(W, H) {\n  ctx.save();\n  ctx.strokeStyle = \'rgba(100,180,255,0.55)\';\n  ctx.lineWidth = 1.2;\n  ctx.setLineDash([6, 5]);\n  ctx.shadowColor = \'rgba(0,0,0,0.6)\'; ctx.shadowBlur = 2;\n\n  // Draw south arc and north arc as two separate paths so they never connect\n  var i, rd, p, started;\n\n  ctx.beginPath(); started = false;\n  for (i = 0; i <= 90; i += 2) {\n    rd = altaz2radec(i, 180);\n    p  = aladin.world2pix(rd[0], rd[1]);\n    if (!p || p[0]==null || isNaN(p[0])) { started = false; continue; }\n    if (!started) { ctx.moveTo(p[0], p[1]); started = true; }\n    else ctx.lineTo(p[0], p[1]);\n  }\n  ctx.stroke();\n\n  ctx.beginPath(); started = false;\n  for (i = 0; i <= 90; i += 2) {\n    rd = altaz2radec(i, 0);\n    p  = aladin.world2pix(rd[0], rd[1]);\n    if (!p || p[0]==null || isNaN(p[0])) { started = false; continue; }\n    if (!started) { ctx.moveTo(p[0], p[1]); started = true; }\n    else ctx.lineTo(p[0], p[1]);\n  }\n  ctx.stroke();\n\n  // Label\n  var rdZ = altaz2radec(88, 0);\n  var pZ  = aladin.world2pix(rdZ[0], rdZ[1]);\n  if (pZ && pZ[0]!=null && !isNaN(pZ[0]) && pZ[0]>0&&pZ[0]<W&&pZ[1]>0&&pZ[1]<H) {\n    ctx.setLineDash([]);\n    ctx.font = \'10px Courier New\';\n    ctx.fillStyle = \'rgba(100,180,255,0.8)\';\n    ctx.textAlign = \'center\';\n    ctx.fillText(\'Meridian\', pZ[0], pZ[1]-6);\n  }\n\n  ctx.setLineDash([]);\n  ctx.restore();\n}\n\n// ── Main draw loop ────────────────────────────────────────────────────────────\nvar GRID = 8, _hf = 0, _lastLst = -9999;\nvar _lastRA = -1, _lastDec = -999, _lastFov = -1;\n\nfunction drawAll() {\n  var W = _cW, H = _cH;\n  _hf++;\n\n  if (!aladin) { requestAnimationFrame(drawAll); return; }\n\n  // Detect pan/zoom by checking if aladin\'s view centre or FOV changed\n  var cen = aladin.getRaDec ? aladin.getRaDec() : null;\n  var fov = aladin.getFov  ? aladin.getFov()[0]  : -1;\n  var cenRA  = cen ? cen[0] : -1;\n  var cenDec = cen ? cen[1] : -999;\n  var viewChanged = (Math.abs(cenRA-_lastRA)>0.01 || Math.abs(cenDec-_lastDec)>0.01 || Math.abs(fov-_lastFov)>0.01);\n  if (viewChanged) { _lastRA=cenRA; _lastDec=cenDec; _lastFov=fov; _needFull=true; }\n\n  var doFull = _needFull || (Math.abs(computeLST() - _lastLst) > 0.004);\n\n  if (doFull) {\n    _needFull = false;\n    _lastLst = computeLST();\n\n    ctx.clearRect(0, 0, W, H);\n\n    // ── Alt/Az grid (drawn first, under everything) ──────────────────────────\n    if (showAltAzGrid) drawAltAzGrid(W, H);\n\n    // ── Meridian ─────────────────────────────────────────────────────────────\n    if (showMeridian) drawMeridian(W, H);\n\n    // ── Ground mask ──────────────────────────────────────────────────────────\n    var n = 0, errs = 0;\n    try {\n      for (var cy = 0; cy < H; cy += GRID) {\n        for (var cx = 0; cx < W; cx += GRID) {\n          try {\n            var rd = aladin.pix2world(cx + GRID/2, cy + GRID/2);\n            if (!rd || rd[0]==null || isNaN(rd[0])) continue;\n            var alt = getAlt(rd[0], rd[1]);\n            if (alt < 0) {\n              ctx.fillStyle = \'rgba(0,0,0,0.55)\';\n              ctx.fillRect(cx, cy, GRID, GRID);\n              n++;\n            }\n          } catch(e2) { errs++; }\n        }\n      }\n    } catch(e3) {}\n\n    // ── Smooth horizon line ───────────────────────────────────────────────────\n    // Draw a crisp anti-aliased line over the blocky grid edge\n    ctx.save();\n    ctx.strokeStyle = \'rgba(140, 180, 255, 0.55)\';\n    ctx.lineWidth = 1.5;\n    ctx.lineJoin = \'round\';\n    ctx.shadowColor = \'rgba(0,0,0,0.7)\'; ctx.shadowBlur = 2;\n    ctx.beginPath();\n    var hStarted = false;\n    for (var haz = 0; haz <= 360; haz += 1) {\n      var hrd = altaz2radec(0, haz);\n      var hp  = aladin.world2pix(hrd[0], hrd[1]);\n      if (!hp || hp[0]==null || isNaN(hp[0])) { hStarted = false; continue; }\n      // Only draw if on screen with some margin\n      if (hp[0] < -20 || hp[0] > W+20 || hp[1] < -20 || hp[1] > H+20) { hStarted = false; continue; }\n      if (!hStarted) { ctx.moveTo(hp[0], hp[1]); hStarted = true; }\n      else ctx.lineTo(hp[0], hp[1]);\n    }\n    ctx.stroke();\n    ctx.restore();\n\n    // ── Cardinal labels at horizon ────────────────────────────────────────────\n    ctx.save();\n    ctx.font = \'bold 13px Courier New\'; ctx.textAlign = \'center\';\n    var dirs=[[\'N\',0],[\'NE\',45],[\'E\',90],[\'SE\',135],[\'S\',180],[\'SW\',225],[\'W\',270],[\'NW\',315]];\n    for (var i = 0; i < dirs.length; i++) {\n      var lbl=dirs[i][0], az=dirs[i][1];\n      var rd2 = altaz2radec(1, az);\n      var p2  = aladin.world2pix(rd2[0], rd2[1]);\n      if (p2&&p2[0]!=null&&!isNaN(p2[0])&&p2[0]>10&&p2[0]<W-10&&p2[1]>10&&p2[1]<H-10) {\n        ctx.fillStyle=\'rgba(0,0,0,0.65)\'; ctx.fillRect(p2[0]-20,p2[1]-14,40,18);\n        ctx.fillStyle=\'rgba(120,180,255,0.95)\';\n        ctx.shadowColor=\'rgba(0,0,0,0.9)\'; ctx.shadowBlur=3;\n        ctx.fillText(lbl, p2[0], p2[1]);\n      }\n    }\n    ctx.restore();\n\n    // ── Sun ───────────────────────────────────────────────────────────────────\n    var jd  = getJD();\n    var sun = sunRaDec(jd);\n    var sp  = aladin.world2pix(sun[0], sun[1]);\n    if (sp && sp[0]!=null && !isNaN(sp[0])) {\n      var sAlt = getAlt(sun[0], sun[1]);\n      ctx.save();\n      ctx.globalAlpha = sAlt < 0 ? 0.35 : 1.0;\n      // Simple solid shadow — no gradient (gradients flicker)\n      ctx.shadowColor = \'rgba(255,200,50,0.6)\'; ctx.shadowBlur = 16;\n      ctx.fillStyle = \'rgba(255,230,80,0.95)\';\n      ctx.beginPath(); ctx.arc(sp[0], sp[1], 7, 0, Math.PI*2); ctx.fill();\n      ctx.shadowBlur = 0;\n      ctx.strokeStyle = \'rgba(255,200,50,0.7)\'; ctx.lineWidth = 1.2;\n      ctx.stroke();\n      ctx.font = \'bold 11px Courier New\'; ctx.fillStyle = \'rgba(255,240,130,0.95)\';\n      ctx.shadowColor = \'rgba(0,0,0,0.9)\'; ctx.shadowBlur = 3;\n      ctx.textAlign = \'left\';\n      ctx.fillText(\'Sun\' + (sAlt < 0 ? \' (below)\' : \'\'), sp[0]+12, sp[1]+4);\n      ctx.restore();\n    }\n\n    // ── Moon ──────────────────────────────────────────────────────────────────\n    var moon  = moonRaDec(jd);\n    var phase = moonPhase(jd);\n    var mp    = aladin.world2pix(moon[0], moon[1]);\n    if (mp && mp[0]!=null && !isNaN(mp[0])) {\n      var mAlt  = getAlt(moon[0], moon[1]);\n      var illum = Math.round((1 - Math.cos(phase*2*Math.PI))/2 * 100);\n      var pname = phase < 0.03 ? \'New\' :\n                  phase < 0.22 ? \'Wax Crescent\' : phase < 0.28 ? \'First Qtr\' :\n                  phase < 0.47 ? \'Wax Gibbous\'  : phase < 0.53 ? \'Full\' :\n                  phase < 0.72 ? \'Wan Gibbous\'  : phase < 0.78 ? \'Last Qtr\' :\n                  phase < 0.97 ? \'Wan Crescent\' : \'New\';\n      ctx.save();\n      ctx.globalAlpha = mAlt < 0 ? 0.35 : 1.0;\n      // Soft shadow instead of gradient glow\n      if (illum > 20) {\n        ctx.shadowColor = \'rgba(200,215,240,0.5)\'; ctx.shadowBlur = 14;\n      }\n      drawMoonIcon(mp[0], mp[1], phase, 10);\n      ctx.shadowBlur = 0;\n      ctx.font = \'bold 11px Courier New\';\n      ctx.fillStyle = \'rgba(200,215,245,0.95)\';\n      ctx.shadowColor = \'rgba(0,0,0,0.9)\'; ctx.shadowBlur = 3;\n      ctx.textAlign = \'left\';\n      ctx.fillText(\'Moon  \' + pname + \'  \' + illum + \'%\' + (mAlt < 0 ? \' (below)\' : \'\'), mp[0]+15, mp[1]+4);\n      ctx.restore();\n    }\n\n    // ── Planets ───────────────────────────────────────────────────────────────\n    var _planetData = [\n      // name, L0, L1, a, e, i, omega, w, color, size\n      // Simplified orbital elements for J2000, mean motion per day\n      // We use pre-computed RA/Dec updated from Python every 60s\n    ];\n    if (typeof _planets !== \'undefined\' && _planets.length > 0) {\n      ctx.save();\n      ctx.font = \'bold 11px Courier New\';\n      for (var pi = 0; pi < _planets.length; pi++) {\n        var pl = _planets[pi];\n        var pp2 = aladin.world2pix(pl.ra, pl.dec);\n        if (!pp2 || pp2[0]==null || isNaN(pp2[0])) continue;\n        var px = pp2[0], py = pp2[1];\n        if (px < -30 || px > W+30 || py < -30 || py > H+30) continue;\n        var pAlt = getAlt(pl.ra, pl.dec);\n        ctx.globalAlpha = pAlt < 0 ? 0.3 : 1.0;\n        ctx.shadowColor = pl.color; ctx.shadowBlur = 8;\n        ctx.fillStyle = pl.color;\n        ctx.beginPath(); ctx.arc(px, py, pl.size || 4, 0, Math.PI*2); ctx.fill();\n        ctx.shadowBlur = 0;\n        ctx.fillStyle = pl.color;\n        ctx.shadowColor = \'rgba(0,0,0,0.9)\'; ctx.shadowBlur = 3;\n        ctx.textAlign = \'left\';\n        ctx.fillText(pl.name + (pAlt < 0 ? \' (below)\' : \'\'), px + (pl.size||4) + 4, py + 4);\n      }\n      ctx.restore();\n    }\n    // ── Comets ────────────────────────────────────────────────────────────────\n    if (typeof _comets !== \'undefined\' && _comets.length > 0) {\n      ctx.save();\n      ctx.font = \'10px Courier New\';\n      for (var coi = 0; coi < _comets.length; coi++) {\n        var co = _comets[coi];\n        var cop = aladin.world2pix(co.ra, co.dec);\n        if (!cop || cop[0]==null || isNaN(cop[0])) continue;\n        var cox = cop[0], coy = cop[1];\n        if (cox < -30 || cox > W+30 || coy < -30 || coy > H+30) continue;\n        var coAlt = getAlt(co.ra, co.dec);\n        ctx.globalAlpha = coAlt < 0 ? 0.25 : 0.85;\n        // Draw comet as small circle with tail hint\n        ctx.shadowColor = \'rgba(180,255,180,0.8)\'; ctx.shadowBlur = 6;\n        ctx.fillStyle = \'rgba(180,255,200,0.9)\';\n        ctx.beginPath(); ctx.arc(cox, coy, 3, 0, Math.PI*2); ctx.fill();\n        ctx.shadowBlur = 0;\n        ctx.fillStyle = \'rgba(160,240,180,0.9)\';\n        ctx.shadowColor = \'rgba(0,0,0,0.9)\'; ctx.shadowBlur = 3;\n        ctx.textAlign = \'left\';\n        ctx.fillText(co.name + (co.mag ? \' m=\' + co.mag : \'\') + (coAlt < 0 ? \' (below)\' : \'\'), cox + 7, coy + 4);\n      }\n      ctx.restore();\n    }\n  }  // end doFull\n\n  // ── Scopes (every frame) ─────────────────────────────────────────────────\n  if (pendingScopes!==null){scopeData=pendingScopes;pendingScopes=null;}\n\n  var _clusterZonesThisFrame=[];\n  // ── Cluster detection: find groups of 3+ scopes within 4 degrees ─────────\n  var ids = Object.keys(scopeData);\n  // For each scope, count how many others are within 4 deg (angular separation)\n  var clusterCount = {};  // id -> number of neighbours within 4 deg\n  for (var ci = 0; ci < ids.length; ci++) {\n    clusterCount[ids[ci]] = 0;\n    var si = scopeData[ids[ci]];\n    var ri = si.ra * DEG, di = si.dec * DEG;\n    for (var cj = 0; cj < ids.length; cj++) {\n      if (ci === cj) continue;\n      var sj = scopeData[ids[cj]];\n      var rj = sj.ra * DEG, dj = sj.dec * DEG;\n      // Angular separation via haversine\n      var dra = rj - ri, ddec = dj - di;\n      var a = Math.sin(ddec/2)*Math.sin(ddec/2) +\n              Math.cos(di)*Math.cos(dj)*Math.sin(dra/2)*Math.sin(dra/2);\n      var sep = 2 * Math.asin(Math.sqrt(a)) / DEG;\n      if (sep < 4.0) clusterCount[ids[ci]]++;\n    }\n  }\n\n  // Draw hotspot rings for cluster centres (scopes with 2+ neighbours)\n  // Find unique cluster centres by grouping\n  var drawnClusters = [];\n  for (var ci2 = 0; ci2 < ids.length; ci2++) {\n    if (clusterCount[ids[ci2]] < 2) continue;\n    var sc2 = scopeData[ids[ci2]];\n    var cp = aladin.world2pix(sc2.ra, sc2.dec);\n    if (!cp || cp[0]==null || isNaN(cp[0])) continue;\n\n    // Check we haven\'t already drawn a hotspot for this cluster\n    // Compare in sky coords (degrees) not pixels — works at any zoom\n    var alreadyDrawn = false;\n    for (var dk = 0; dk < drawnClusters.length; dk++) {\n      var dra3 = (sc2.ra - drawnClusters[dk][0]) * DEG;\n      var ddec3 = (sc2.dec - drawnClusters[dk][1]) * DEG;\n      var a3 = Math.sin(ddec3/2)*Math.sin(ddec3/2) +\n               Math.cos(sc2.dec*DEG)*Math.cos(drawnClusters[dk][1]*DEG)*Math.sin(dra3/2)*Math.sin(dra3/2);\n      if (2*Math.asin(Math.sqrt(a3))/DEG < 4.0) { alreadyDrawn = true; break; }\n    }\n    if (alreadyDrawn) continue;\n\n    // Compute centroid of this cluster in screen space\n    var cxSum = 0, cySum = 0, cCount = 0;\n    for (var ck = 0; ck < ids.length; ck++) {\n      var sk = scopeData[ids[ck]];\n      var rk = sk.ra * DEG, dk2 = sk.dec * DEG;\n      var ri2 = sc2.ra * DEG, di2 = sc2.dec * DEG;\n      var dra2 = rk-ri2, ddec2 = dk2-di2;\n      var a2 = Math.sin(ddec2/2)*Math.sin(ddec2/2) +\n               Math.cos(di2)*Math.cos(rk)*Math.sin(dra2/2)*Math.sin(dra2/2);\n      if (2*Math.asin(Math.sqrt(a2))/DEG < 4.0) {\n        var pk = aladin.world2pix(sk.ra, sk.dec);\n        if (pk && pk[0]!=null && !isNaN(pk[0])) { cxSum+=pk[0]; cySum+=pk[1]; cCount++; }\n      }\n    }\n    if (cCount < 3) continue;\n    var cxCen = cxSum/cCount, cyCen = cySum/cCount;\n    drawnClusters.push([sc2.ra, sc2.dec]);  // store sky coords for dedup\n\n    var n = clusterCount[ids[ci2]] + 1;  // total scopes in cluster\n    var R = 18 + n * 2;  // smaller ring\n    ctx.save();\n    ctx.globalAlpha = 0.35;\n    ctx.strokeStyle = \'rgba(180,200,255,0.9)\';\n    ctx.lineWidth = 0.8;\n    ctx.setLineDash([3, 6]);\n    ctx.beginPath(); ctx.arc(cxCen, cyCen, R, 0, Math.PI*2); ctx.stroke();\n    ctx.setLineDash([]);\n\n    // Tiny count badge\n    ctx.globalAlpha = 0.7;\n    ctx.font = \'10px Courier New\';\n    ctx.fillStyle = \'rgba(160,190,255,0.9)\';\n    ctx.textAlign = \'center\';\n    ctx.fillText(\'×\' + n, cxCen, cyCen - R - 3);\n    ctx.restore();\n    _clusterZonesThisFrame.push({cx:cxCen,cy:cyCen,R:R,ra:sc2.ra,dec:sc2.dec});\n  }\n  if(typeof updateZoneBtns!==\'undefined\')updateZoneBtns(_clusterZonesThisFrame);\n\n  for (var id in scopeData) {\n    var s=scopeData[id];\n    var pp=aladin.world2pix(s.ra,s.dec);\n    if(!pp||pp[0]==null||isNaN(pp[0]))continue;\n    var x=pp[0],y=pp[1];\n    if(x<-30||x>W+30||y<-30||y>H+30)continue;\n    var above=getAlt(s.ra,s.dec)>-1;\n    var col=s.color||\'#50e0a0\',sz=s.mine?20:14,lw=s.mine?2:1.4,g=4;\n    ctx.save();\n    ctx.globalAlpha=above?1:0.35; ctx.strokeStyle=col; ctx.lineWidth=lw;\n    ctx.shadowColor=\'rgba(0,0,0,.9)\'; ctx.shadowBlur=4;\n    ctx.beginPath();\n    ctx.moveTo(x-sz,y);ctx.lineTo(x-g,y);ctx.moveTo(x+g,y);ctx.lineTo(x+sz,y);\n    ctx.moveTo(x,y-sz);ctx.lineTo(x,y-g);ctx.moveTo(x,y+g);ctx.lineTo(x,y+sz);\n    ctx.stroke();\n    ctx.beginPath();ctx.arc(x,y,g*1.2,0,Math.PI*2);ctx.stroke();\n    if(s.name){\n      ctx.font=s.mine?\'bold 12px Courier New\':\'11px Courier New\';\n      ctx.shadowBlur=5;\n      if(s.username===\'astrofalls\'){\n        var cx2=x+sz+5,cy2=y+4;\n        for(var ci4=0;ci4<s.name.length;ci4++){\n          var hue=(_hf*2+ci4*30)%360;\n          ctx.fillStyle=\'hsl(\'+hue+\',100%,65%)\';\n          ctx.fillText(s.name[ci4],cx2,cy2);\n          cx2+=ctx.measureText(s.name[ci4]).width;\n        }\n      } else {\n        ctx.fillStyle=col;ctx.fillText(s.name,x+sz+5,y+4);\n      }\n    }\n    if(s.name&&!above){\n      ctx.font=\'10px Courier New\';ctx.fillStyle=\'rgba(200,100,50,.8)\';\n      ctx.fillText(\'(below horizon)\',x+sz+5,y+16);\n    }\n\n    // FOV footprint — drawn if server sends fov/rotation fields\n    var fovW = s.fov_w || s.fov || null;\n    var fovH = s.fov_h || s.fov || null;\n    var rot  = s.rotation || s.camera_angle || 0;  // degrees, 0=N up\n    if (fovW && fovH && above) {\n      // px/deg scale: sample ±0.5deg in RA and measure pixel distance\n      var raOff = 0.5 / Math.max(0.1, Math.cos(s.dec * DEG));\n      var pA = aladin.world2pix(s.ra - raOff, s.dec);\n      var pB = aladin.world2pix(s.ra + raOff, s.dec);\n      var pxPerDeg = (pA && pB && pA[0]!=null && pB[0]!=null)\n                     ? Math.abs(pB[0] - pA[0])  // already spans 1 deg total\n                     : 0;\n      if (pxPerDeg > 1) {\n        var hw = (fovW / 2) * pxPerDeg;  // half-width in px\n        var hh2 = (fovH / 2) * pxPerDeg; // half-height in px\n        var rotR = rot * DEG;\n\n        // Four corners of the FOV rectangle, rotated\n        var cos_r = Math.cos(rotR), sin_r = Math.sin(rotR);\n        var corners = [\n          [-hw, -hh2], [hw, -hh2], [hw, hh2], [-hw, hh2]\n        ];\n        ctx.save();\n        ctx.strokeStyle = col;\n        ctx.globalAlpha = above ? 0.5 : 0.15;\n        ctx.lineWidth = 0.8;\n        ctx.setLineDash([3, 4]);\n        ctx.shadowBlur = 0;\n        ctx.beginPath();\n        for (var ci3 = 0; ci3 < 4; ci3++) {\n          var cx3 = corners[ci3][0], cy3 = corners[ci3][1];\n          var rx = x + cx3*cos_r - cy3*sin_r;\n          var ry = y + cx3*sin_r + cy3*cos_r;\n          if (ci3 === 0) ctx.moveTo(rx, ry); else ctx.lineTo(rx, ry);\n        }\n        ctx.closePath();\n        ctx.stroke();\n        // Rotation tick — short line from centre toward N\n        ctx.globalAlpha = above ? 0.4 : 0.1;\n        ctx.beginPath();\n        ctx.moveTo(x, y);\n        ctx.lineTo(x - Math.sin(rotR)*hh2*0.6, y - Math.cos(rotR)*hh2*0.6);\n        ctx.stroke();\n        ctx.setLineDash([]);\n        ctx.restore();\n      }\n    }\n\n    ctx.restore();\n  }\n\n  requestAnimationFrame(drawAll);\n}\nrequestAnimationFrame(drawAll);\n\ndocument.getElementById(\'aladin-lite-div\').addEventListener(\'mousemove\',function(e){\n  if(!aladin)return;\n  try{\n    var rect=e.currentTarget.getBoundingClientRect();\n    var rd=aladin.pix2world(e.clientX-rect.left,e.clientY-rect.top);\n    if(rd&&rd[0]!=null){\n      var alt=getAlt(rd[0],rd[1]);\n      var az=0;\n      var rh=rd[0]/15,hh=Math.floor(rh),mm=Math.floor((rh-hh)*60),ss=((rh-hh)*60-mm)*60;\n      var ds=rd[1]>=0?\'+\':\'-\',ad=Math.abs(rd[1]);\n      var dd=Math.floor(ad),dm=Math.floor((ad-dd)*60),dsc=((ad-dd)*60-dm)*60;\n      document.getElementById(\'hud-cursor\').textContent=\n        \'Alt \'+alt.toFixed(1)+\'deg  \'\n        +\'RA \'+String(hh).padStart(2,\'0\')+\'h \'+String(mm).padStart(2,\'0\')+\'m \'+ss.toFixed(1)+\'s\'\n        +\'  Dec \'+ds+String(dd).padStart(2,\'0\')+\'deg \'+String(dm).padStart(2,\'0\')+"\' "+dsc.toFixed(0)+\'"\';\n    }\n  }catch(err){}\n});\n\nnew QWebChannel(qt.webChannelTransport,function(ch){\n  pyBridge=ch.objects.pyBridge;\n  A.init.then(function(){\n    aladin=A.aladin(\'#aladin-lite-div\',{\n      survey:\'CDS/P/DSS2/color\',fov:120,target:\'__RA__ __DEC__\',\n      cooFrame:\'ICRS\',showReticle:true,showZoomControl:false,\n      showFullscreenControl:false,showLayersControl:true,showGotoControl:false,\n      showShareControl:false,showCooGridControl:true,\n      showSimbadPointerControl:false,backgroundColor:\'#00000a\',\n      projectionMethod:\'STG\'\n    });\n    aladin.on(\'objectClicked\',function(obj){\n      if(!obj||!pyBridge)return;\n      var name=(obj.data&&obj.data.name)||obj.name||\'?\';\n      pyBridge.objectClicked(name,obj.ra||0,obj.dec||0);\n    });\n    _needFull=true;\n    // Set stereographic projection — try all known Aladin v3 API variants\n    try {\n      if (typeof aladin.setProjection === \'function\') {\n        aladin.setProjection(\'STG\');\n      } else if (aladin.view && typeof aladin.view.setProjection === \'function\') {\n        aladin.view.setProjection(\'STG\');\n      } else if (aladin.view && typeof aladin.view.changeProjection === \'function\') {\n        aladin.view.changeProjection(\'STG\');\n      }\n    } catch(pe) { console.warn(\'Projection API not found:\', pe); }\n    console.log(\'Aladin ready\');\n  });\n});\n\nfunction updateScopes(s){try{var p=typeof s===\'string\'?JSON.parse(s):s;if(p&&typeof p===\'object\'&&!Array.isArray(p)){if(aladin)scopeData=p;else pendingScopes=p;}}catch(e){console.warn(\'[Scopes]\',e);}}\nfunction gotoTarget(ra,dec,fov){if(aladin){aladin.gotoRaDec(ra,dec);if(fov)aladin.setFov(fov);}}\nfunction setSurvey(id){if(aladin)aladin.setImageSurvey(id);}\nfunction updateHUD(s){document.getElementById(\'hud-lst\').textContent=\'LST \'+s;}\nfunction setLST(d){_lstOverride=d;_needFull=true;}\nfunction setShowMeridian(v){showMeridian=v;_needFull=true;}\nfunction setShowGrid(v){showAltAzGrid=v;_needFull=true;}\n\nvar _planets = [];\nvar _comets  = [];\nfunction updatePlanets(data) {\n  try {\n    var d = typeof data === \'string\' ? JSON.parse(data) : data;\n    _planets = d.planets || [];\n    _comets  = d.comets  || [];\n    _needFull = true;\n  } catch(e) { console.warn(\'[Planets]\', e); }\n}\nfunction flashScope(id){if(!scopeData[id])return;var o=scopeData[id].color;scopeData[id].color=\'#ffffff\';setTimeout(function(){if(scopeData[id])scopeData[id].color=o;},500);}\n</script>\n</body>\n</html>\n'
def build_aladin_html(ra_deg: float, dec_deg: float) -> str:
    """Fill the Aladin HTML template with site coords and initial target."""
    _ej = "\nvar _zoneBtns=[];\nfunction updateZoneBtns(zones){\n  while(_zoneBtns.length<zones.length){\n    var b=document.createElement('button');\n    b.className='zone-chat-btn';\n    b.textContent='💬 Join Chat';\n    var i=_zoneBtns.length;\n    b.onclick=(function(idx){return function(e){e.stopPropagation();if(typeof pyBridge!='undefined')pyBridge.joinChatZone(idx);};})(i);\n    document.body.appendChild(b);\n    _zoneBtns.push(b);\n  }\n  for(var j=0;j<_zoneBtns.length;j++)_zoneBtns[j].style.display='none';\n  for(var k=0;k<zones.length;k++){\n    var z=zones[k],btn=_zoneBtns[k];\n    btn.style.left=z.cx+'px';\n    btn.style.top=(z.cy+z.R+8)+'px';\n    btn.style.display='block';\n  }\n  if(typeof pyBridge!='undefined')pyBridge.reportZones(JSON.stringify(zones));\n}\n"
    _css = "\n<style>\n.zone-chat-btn{\n  position:fixed;display:none;\n  background:rgba(8,20,55,0.92);color:#7ab8ff;\n  border:1.5px solid #3a7fff;border-radius:5px;\n  font:bold 12px 'Courier New';padding:5px 12px;\n  cursor:pointer;z-index:99999;transform:translateX(-50%);\n}\n.zone-chat-btn:hover{background:rgba(20,50,130,0.95);}\n</style>\n"
    return (ALADIN_HTML_TEMPLATE
            .replace("__LAT__", str(SITE_LAT))
            .replace("__LON__", str(SITE_LON))
            .replace("__RA__",  f"{ra_deg:.4f}")
            .replace("__DEC__", f"{dec_deg:.4f}")
            .replace("</head>", _css + "</head>", 1)
            .replace("\n</script>\n</body>", _ej + "\n</script>\n</body>", 1))

DARK_STYLE = """
QMainWindow, QWidget {
    background-color: #0b0e1a;
    color: #c8d4f0;
    font-family: 'Courier New', monospace;
    font-size: 12px;
}
QGroupBox {
    border: 1px solid #1e2a4a;
    border-radius: 6px;
    margin-top: 10px;
    padding-top: 6px;
    color: #7090c0;
    font-size: 11px;
    letter-spacing: 1px;
}
QGroupBox::title { subcontrol-position: top left; left: 8px; }
QPushButton {
    background: #111828;
    border: 1px solid #1e2a4a;
    border-radius: 4px;
    padding: 4px 10px;
    color: #9ab0e0;
}
QPushButton:hover  { background: #1a2540; border-color: #3a5080; }
QPushButton:pressed{ background: #0d1420; }
QPushButton#goto_btn {
    background: #0e2a18; border-color: #1a5030; color: #50e090;
}
QPushButton#goto_btn:hover { background: #143820; border-color: #30a060; }
QPushButton#stop_btn {
    background: #2a0e0e; border-color: #501a1a; color: #e05050;
}
QPushButton#stop_btn:hover { background: #381414; }
QLabel#dot {
    border-radius: 5px;
    min-width: 10px; max-width: 10px;
    min-height: 10px; max-height: 10px;
}
QSlider::groove:horizontal {
    height: 3px; background: #1e2a4a; border-radius: 2px;
}
QSlider::handle:horizontal {
    background: #4a70c0; width: 12px; height: 12px;
    margin: -5px 0; border-radius: 6px;
}
QComboBox, QLineEdit, QSpinBox {
    background: #0d1220; border: 1px solid #1e2a4a;
    border-radius: 4px; padding: 3px 6px; color: #c8d4f0;
}
QComboBox::drop-down { border: none; }
QTableWidget {
    background: #080c18; gridline-color: #141e38; border: none;
}
QTableWidget::item { padding: 3px 6px; }
QTableWidget::item:selected { background: #1a2a50; color: #e0eaff; }
QHeaderView::section {
    background: #0d1428; color: #6080b0; border: none;
    border-bottom: 1px solid #1e2a4a; padding: 4px 6px; font-size: 11px;
}
QCheckBox::indicator {
    width: 13px; height: 13px;
    border: 1px solid #2a3a6a; border-radius: 3px; background: #0d1220;
}
QCheckBox::indicator:checked { background: #2a5090; border-color: #4a70c0; }
QStatusBar {
    background: #070a14; color: #405080; font-size: 11px;
    border-top: 1px solid #141e38;
}
QSplitter::handle { background: #141e38; width: 1px; height: 1px; }
"""

# ─────────────────────────────────────────────────────────────────────────────
# LOCAL HTTP SERVER  (gives the page a real origin so HiPS CORS works)
# ─────────────────────────────────────────────────────────────────────────────

_local_server_port: int = 0
_local_html_content: bytes = b""

def _start_local_server(html: str) -> int:
    import http.server, threading, socket
    global _local_html_content, _local_server_port
    _local_html_content = html.encode("utf-8")

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(_local_html_content)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(_local_html_content)
        def log_message(self, *args):
            pass

    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]

    server = http.server.HTTPServer(("127.0.0.1", port), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    _local_server_port = port
    print(f"[Server] Serving Aladin page on http://127.0.0.1:{port}/")
    return port

def _write_aladin_tmp(html: str) -> str:
    """Start local server and return its URL."""
    port = _start_local_server(html)
    return f"http://127.0.0.1:{port}/"

# ─────────────────────────────────────────────────────────────────────────────
# LOADING SPINNER  (shown while Aladin CDN script downloads)
# ─────────────────────────────────────────────────────────────────────────────

def _loading_html() -> str:
    return """<!DOCTYPE html><html><head><meta charset="utf-8"/>
<style>
*{margin:0;padding:0;}
html,body{width:100%;height:100%;background:#00000a;
          display:flex;align-items:center;justify-content:center;
          flex-direction:column;gap:18px;}
.spinner{width:48px;height:48px;border:3px solid #1a2a4a;
         border-top-color:#4a70c0;border-radius:50%;
         animation:spin 0.9s linear infinite;}
@keyframes spin{to{transform:rotate(360deg);}}
p{color:#4a6a90;font:12px "Courier New",monospace;letter-spacing:1px;}
</style></head>
<body>
<div class="spinner"></div>
<p>Loading Aladin Lite&hellip;</p>
<p style="color:#2a3a5a;font-size:10px;">Connecting to CDS Strasbourg</p>
</body></html>"""

# ─────────────────────────────────────────────────────────────────────────────
# MAIN WINDOW
# ─────────────────────────────────────────────────────────────────────────────


class ScopeFOVWindow(QWidget):
    """Standalone window for configuring a scope's camera FOV."""
    saved = pyqtSignal(dict)

    def __init__(self, scope_name, cfg, parent=None):
        super().__init__(parent, Qt.WindowType.Window)
        self.setWindowTitle(f"FOV Setup — {scope_name}")
        self.setMinimumWidth(340)
        self.setStyleSheet(parent.styleSheet() if parent else "")

        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 20, 20, 20)
        lay.setSpacing(12)

        lay.addWidget(QLabel(f"<b>{scope_name}</b>"))

        form = QFormLayout()
        form.setSpacing(8)

        def dbl(val, lo, hi, dec=1, suffix=""):
            w = QDoubleSpinBox()
            w.setRange(lo, hi); w.setDecimals(dec)
            w.setValue(val)
            if suffix: w.setSuffix("  " + suffix)
            return w

        self.px_w  = dbl(cfg.get("px_w",  4144), 1, 50000, 0, "px")
        self.px_h  = dbl(cfg.get("px_h",  2822), 1, 50000, 0, "px")
        self.px_um = dbl(cfg.get("px_um", 4.63), 0.1, 50,  2, "µm")
        self.focal = dbl(cfg.get("focal", 700),  10, 20000, 0, "mm")
        self.angle = dbl(cfg.get("angle", 0.0), -180, 180,  1, "°")

        form.addRow("Sensor width:",      self.px_w)
        form.addRow("Sensor height:",     self.px_h)
        form.addRow("Pixel size:",        self.px_um)
        form.addRow("Focal length:",      self.focal)
        form.addRow("Rotation (N=0°):",   self.angle)
        lay.addLayout(form)

        self.fov_lbl = QLabel("—")
        self.fov_lbl.setStyleSheet("color:#5080a0; font-size:11px; padding:4px 0;")
        lay.addWidget(self.fov_lbl)

        btns = QHBoxLayout()
        btn_ok  = QPushButton("Apply")
        btn_ok.clicked.connect(self._save)
        btn_can = QPushButton("Close")
        btn_can.clicked.connect(self.close)
        btns.addWidget(btn_ok); btns.addWidget(btn_can)
        lay.addLayout(btns)

        for w in (self.px_w, self.px_h, self.px_um, self.focal, self.angle):
            w.valueChanged.connect(self._update_preview)
        self._update_preview()

    def _update_preview(self):
        try:
            import math
            fw = self.px_w.value() * self.px_um.value() / 1000.0
            fh = self.px_h.value() * self.px_um.value() / 1000.0
            fl = self.focal.value()
            fw_deg = math.degrees(2 * math.atan(fw / (2 * fl)))
            fh_deg = math.degrees(2 * math.atan(fh / (2 * fl)))
            self.fov_lbl.setText(
                f"FOV: {fw_deg*60:.1f}′ × {fh_deg*60:.1f}′  "
                f"({fw_deg:.3f}° × {fh_deg:.3f}°)")
        except Exception:
            pass

    def _save(self):
        self.saved.emit({
            "px_w":  self.px_w.value(),
            "px_h":  self.px_h.value(),
            "px_um": self.px_um.value(),
            "focal": self.focal.value(),
            "angle": self.angle.value(),
        })
        self.fov_lbl.setStyleSheet(
            "color:#50e090; font-size:11px; padding:4px 0;")
        self.fov_lbl.setText(self.fov_lbl.text() + "  ✓ Applied")



class _BarChartWidget(QWidget):
    """Simple canvas bar chart."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._labels = []
        self._values = []
        self._color  = "#3a7fff"

    def set_data(self, labels, values, color="#3a7fff"):
        self._labels = labels
        self._values = values
        self._color  = color
        self.update()

    def paintEvent(self, event):
        from PyQt6.QtGui import QPainter, QPen
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        W, H = self.width(), self.height()
        pad_l, pad_r, pad_t, pad_b = 52, 12, 16, 36

        if not self._values:
            p.setPen(QColor("#3a5a80"))
            p.drawText(0, 0, W, H, Qt.AlignmentFlag.AlignCenter, "No data yet")
            p.end(); return

        max_val = max(self._values) or 1
        n       = len(self._values)
        chart_w = W - pad_l - pad_r
        chart_h = H - pad_t - pad_b
        bar_w   = max(4, int(chart_w / n * 0.65))
        gap     = chart_w / n

        p.fillRect(0, 0, W, H, QColor("#050d20"))
        font = QFont("Courier New", 8)
        p.setFont(font)

        for frac in (0.25, 0.5, 0.75, 1.0):
            y = pad_t + int(chart_h * (1 - frac))
            p.setPen(QPen(QColor("#1a2a40"), 1))
            p.drawLine(pad_l, y, W - pad_r, y)
            p.setPen(QColor("#3a6080"))
            p.drawText(0, y - 6, pad_l - 4, 14,
                       Qt.AlignmentFlag.AlignRight, f"{max_val * frac:.1f}h")

        base_color = QColor(self._color)
        for i, (lbl, val) in enumerate(zip(self._labels, self._values)):
            bar_h = int(chart_h * val / max_val)
            x     = pad_l + int(gap * i + (gap - bar_w) / 2)
            y     = pad_t + chart_h - bar_h
            ratio = val / max_val
            r = int(base_color.red()   * (0.4 + 0.6 * ratio))
            g = int(base_color.green() * (0.4 + 0.6 * ratio))
            b = int(base_color.blue()  * (0.4 + 0.6 * ratio))
            p.fillRect(x, y, bar_w, bar_h, QColor(r, g, b))
            p.setPen(QPen(QColor(base_color.red(), base_color.green(),
                                 base_color.blue(), 180), 1))
            p.drawRect(x, y, bar_w, bar_h)
            p.setPen(QColor("#4a7090"))
            p.drawText(x - 4, H - pad_b + 4, bar_w + 8, 20,
                       Qt.AlignmentFlag.AlignCenter, lbl)
            if bar_h > 20:
                p.setPen(QColor("#8ab8e0"))
                p.drawText(x - 4, y - 14, bar_w + 8, 14,
                           Qt.AlignmentFlag.AlignCenter, f"{val:.1f}h")
        p.end()




class _SettingsDialog(QDialog):
    """Account, scopes, and NINA plugin configuration in one place."""
    def __init__(self, main_win, parent=None):
        super().__init__(parent)
        self._main = main_win
        self.setWindowTitle("Starfront Settings")
        self.setMinimumWidth(480)
        self.setStyleSheet(
            "QDialog { background:#050d18; color:#7ab0e0; }"
            "QGroupBox { font-size:10px; color:#5a8ab0; border:1px solid #1a3060;"
            "  border-radius:4px; margin-top:6px; padding-top:4px; }"
            "QGroupBox::title { subcontrol-origin:margin; left:8px; padding:0 4px; }"
            "QLabel { font-size:11px; color:#7ab0e0; }"
            "QLineEdit { background:#050d20; color:#c0d8f0; border:1px solid #1a3060;"
            "  border-radius:3px; padding:4px 8px; font-size:11px; }"
            "QPushButton { background:#0d1e3a; color:#7ab0e0; border:1px solid #1a3060;"
            "  border-radius:3px; padding:5px 12px; font-size:11px; }"
            "QPushButton:hover { background:#1a2e50; }"
        )
        lay = QVBoxLayout(self)
        lay.setSpacing(12)
        lay.setContentsMargins(16, 16, 16, 16)

        # ── Account ─────────────────────────────────────────────────────────
        box_acct = QGroupBox("STARFRONT ACCOUNT")
        av = QVBoxLayout(box_acct)
        av.setSpacing(6)

        # Re-use the hidden widgets on the main window
        mw = self._main
        cred_row = QHBoxLayout()
        self._user_input = QLineEdit()
        self._user_input.setPlaceholderText("Username")
        self._user_input.setText(mw.sf_user.text())
        self._pass_input = QLineEdit()
        self._pass_input.setPlaceholderText("Password")
        self._pass_input.setEchoMode(QLineEdit.EchoMode.Password)
        self._pass_input.setText(mw.sf_pass.text())
        cred_row.addWidget(self._user_input)
        cred_row.addWidget(self._pass_input)
        av.addLayout(cred_row)

        self._invite_input = QLineEdit()
        self._invite_input.setPlaceholderText("Invite code (only needed to register)")
        self._invite_input.setStyleSheet("font-size:10px;")
        av.addWidget(self._invite_input)

        btn_row = QHBoxLayout()
        btn_login = QPushButton("Login")
        btn_login.clicked.connect(self._do_login)
        btn_reg   = QPushButton("Register")
        btn_reg.clicked.connect(self._do_register)
        btn_logout = QPushButton("Logout")
        btn_logout.setStyleSheet("color:#c07070;")
        btn_logout.clicked.connect(self._do_logout)
        btn_row.addWidget(btn_login)
        btn_row.addWidget(btn_reg)
        btn_row.addStretch()
        btn_row.addWidget(btn_logout)
        av.addLayout(btn_row)

        self.lbl_acct_status = QLabel(mw.lbl_auth.text())
        self.lbl_acct_status.setStyleSheet("font-size:10px; color:#5070a0;")
        av.addWidget(self.lbl_acct_status)
        lay.addWidget(box_acct)

        # ── My Scopes ────────────────────────────────────────────────────────
        box_scopes = QGroupBox("MY SCOPES")
        sv = QVBoxLayout(box_scopes)
        sv.setSpacing(6)

        self.scopes_tbl = QTableWidget(0, 2)
        self.scopes_tbl.setHorizontalHeaderLabels(["Scope Name", ""])
        self.scopes_tbl.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.scopes_tbl.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        self.scopes_tbl.setColumnWidth(1, 28)
        self.scopes_tbl.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.scopes_tbl.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.scopes_tbl.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.scopes_tbl.verticalHeader().setVisible(False)
        self.scopes_tbl.setShowGrid(False)
        self.scopes_tbl.setMinimumHeight(90)
        self.scopes_tbl.setStyleSheet(
            "QTableWidget { background:#0d1520; }"
            "QTableWidget::item:selected { background:#1e3a6e; }")
        self.scopes_tbl.itemSelectionChanged.connect(self._scope_selected)
        sv.addWidget(self.scopes_tbl)

        scope_btns = QHBoxLayout()
        btn_new = QPushButton("+ New Scope")
        btn_new.clicked.connect(mw._nina_register_scope)
        self._btn_rename = QPushButton("✏ Rename")
        self._btn_rename.setStyleSheet("color:#70a0d0;")
        self._btn_rename.setEnabled(False)
        self._btn_rename.clicked.connect(self._rename_scope)
        self._btn_del = QPushButton("🗑 Delete")
        self._btn_del.setStyleSheet("color:#c05050;")
        self._btn_del.setEnabled(False)
        self._btn_del.clicked.connect(self._delete_scope)
        scope_btns.addWidget(btn_new)
        scope_btns.addWidget(self._btn_rename)
        scope_btns.addWidget(self._btn_del)
        scope_btns.addStretch()
        sv.addLayout(scope_btns)
        lay.addWidget(box_scopes)

        # ── NINA Plugin Credentials ──────────────────────────────────────────
        box_nina = QGroupBox("NINA PLUGIN CREDENTIALS  (for selected scope)")
        nv = QVBoxLayout(box_nina)
        nv.setSpacing(4)

        nv.addWidget(QLabel("Server:"))
        self.nina_server = QLineEdit(SF_SERVER)
        self.nina_server.setReadOnly(True)
        self.nina_server.setStyleSheet("font-family:'Courier New'; font-size:11px;")
        nv.addWidget(self.nina_server)

        nv.addWidget(QLabel("API Key:"))
        self.nina_apikey = QLineEdit()
        self.nina_apikey.setReadOnly(True)
        self.nina_apikey.setPlaceholderText("Select a scope above")
        self.nina_apikey.setStyleSheet("font-family:'Courier New'; font-size:10px;")
        nv.addWidget(self.nina_apikey)

        nv.addWidget(QLabel("Scope ID:"))
        self.nina_scopeid = QLineEdit()
        self.nina_scopeid.setReadOnly(True)
        self.nina_scopeid.setPlaceholderText("Select a scope above")
        self.nina_scopeid.setStyleSheet("font-family:'Courier New'; font-size:10px;")
        nv.addWidget(self.nina_scopeid)

        lay.addWidget(box_nina)

        # Close button
        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.accept)
        lay.addWidget(btn_close)

        # Populate scopes from main window's cached list
        self._populate_scopes()

    def _populate_scopes(self):
        mw = self._main
        self.scopes_tbl.setRowCount(0)
        for sc in getattr(mw, "_nina_scopes", []):
            r = self.scopes_tbl.rowCount()
            self.scopes_tbl.insertRow(r)
            self.scopes_tbl.setItem(r, 0, QTableWidgetItem(sc.get("name", "")))
            self.scopes_tbl.setItem(r, 1, QTableWidgetItem(""))

    def _scope_selected(self):
        rows = self.scopes_tbl.selectedItems()
        has = bool(rows)
        self._btn_rename.setEnabled(has)
        self._btn_del.setEnabled(has)
        if not has:
            self.nina_apikey.clear(); self.nina_scopeid.clear(); return
        row = self.scopes_tbl.currentRow()
        mw  = self._main
        scopes = getattr(mw, "_nina_scopes", [])
        if row < len(scopes):
            sc = scopes[row]
            self.nina_apikey.setText(sc.get("api_key", ""))
            self.nina_scopeid.setText(sc.get("id", ""))
            # Mirror to main window hidden fields for compatibility
            mw.nina_apikey.setText(sc.get("api_key", ""))
            mw.nina_scopeid.setText(sc.get("id", ""))

    def _rename_scope(self):
        row = self.scopes_tbl.currentRow()
        mw  = self._main
        scopes = getattr(mw, "_nina_scopes", [])
        if row < 0 or row >= len(scopes): return
        # Select on main window table then call rename
        mw.my_scopes_table.selectRow(row)
        mw._rename_my_selected_scope()
        self._populate_scopes()

    def _delete_scope(self):
        row = self.scopes_tbl.currentRow()
        mw  = self._main
        scopes = getattr(mw, "_nina_scopes", [])
        if row < 0 or row >= len(scopes): return
        mw.my_scopes_table.selectRow(row)
        mw._delete_my_selected_scope()
        self._populate_scopes()

    def _do_login(self):
        mw = self._main
        mw.sf_user.setText(self._user_input.text())
        mw.sf_pass.setText(self._pass_input.text())
        mw._sf_login()
        self.lbl_acct_status.setText(mw.lbl_auth.text())
        self._populate_scopes()

    def _do_register(self):
        mw = self._main
        mw.sf_user.setText(self._user_input.text())
        mw.sf_pass.setText(self._pass_input.text())
        mw.sf_invite.setText(self._invite_input.text())
        mw._sf_register()
        self.lbl_acct_status.setText(mw.lbl_auth.text())

    def _do_logout(self):
        mw = self._main
        mw._sf_logout()
        self.lbl_acct_status.setText(mw.lbl_auth.text())
        self._populate_scopes()



class _ObservatoryWindow(QDialog):
    """Full grid view of all Rockwood Observatory cameras, plus weather."""

    _cam_signal = pyqtSignal(str, bytes)   # (cam_key, scaled_jpeg)

    def __init__(self, main_win, parent=None):
        super().__init__(parent)
        self._main = main_win
        self.setWindowTitle("Rockwood Observatory — Live Cameras")
        self.setMinimumSize(1100, 700)
        self.setStyleSheet("QDialog { background:#020810; } QLabel { color:#3a6080; }")
        self._cam_signal.connect(self._on_cam_data)

        outer_lay = QVBoxLayout(self)
        outer_lay.setContentsMargins(8, 8, 8, 8)
        outer_lay.setSpacing(6)

        # Header — outside scroll
        hdr = QHBoxLayout()
        title = QLabel("\U0001f4e1  Rockwood Observatory \u2014 Live Cameras")
        title.setStyleSheet("color:#50e090; font-size:14px; font-weight:bold;")
        hdr.addWidget(title)
        hdr.addStretch()
        self.lbl_updated = QLabel("")
        self.lbl_updated.setStyleSheet("font-size:9px; color:#2a4060;")
        hdr.addWidget(self.lbl_updated)
        outer_lay.addLayout(hdr)

        # ── Live Weather Strip ────────────────────────────────────────────────
        wx_strip = QWidget()
        wx_strip.setStyleSheet(
            "QWidget { background:#030e1a; border:1px solid #1a3060;"
            "border-radius:4px; }"
            "QLabel { font-size:11px; font-family:'Courier New'; }")
        wx_lay = QHBoxLayout(wx_strip)
        wx_lay.setContentsMargins(12, 6, 12, 6)
        wx_lay.setSpacing(20)

        def _wx_cell(icon, label):
            col = QVBoxLayout()
            col.setSpacing(0)
            lbl_icon = QLabel(icon)
            lbl_icon.setStyleSheet("font-size:16px;")
            lbl_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lbl_val = QLabel("—")
            lbl_val.setStyleSheet("color:#c0e0ff; font-size:12px; font-weight:bold;")
            lbl_val.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lbl_name = QLabel(label)
            lbl_name.setStyleSheet("color:#3a6080; font-size:9px;")
            lbl_name.setAlignment(Qt.AlignmentFlag.AlignCenter)
            col.addWidget(lbl_icon)
            col.addWidget(lbl_val)
            col.addWidget(lbl_name)
            wx_lay.addLayout(col)
            return lbl_val

        self._wx_temp     = _wx_cell("🌡",  "Temp")
        self._wx_dew      = _wx_cell("💧",  "Dew Δ")
        self._wx_wind     = _wx_cell("💨",  "Wind")
        self._wx_gust     = _wx_cell("🌬",  "Gust")
        self._wx_humidity = _wx_cell("☁",  "Humidity")
        self._wx_pressure = _wx_cell("📊",  "Pressure")
        self._wx_rain     = _wx_cell("🌧",  "Rain")
        self._wx_lightning= _wx_cell("⚡",  "Lightning")

        wx_lay.addStretch()
        self._wx_updated = QLabel("Weather loading…")
        self._wx_updated.setStyleSheet("color:#1a3a60; font-size:9px;")
        wx_lay.addWidget(self._wx_updated)

        outer_lay.addWidget(wx_strip)

        # Weather refresh timer
        self._wx_timer = QTimer(self)
        self._wx_timer.timeout.connect(self._refresh_weather)
        self._wx_timer.start(WF_REFRESH_SECS * 1000)
        import threading as _wt
        _wt.Thread(target=self._fetch_weather, daemon=True).start()

        # Scroll area so allsky and floor cams never overlap
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border:none; background:#020810; }")
        content_w = QWidget()
        content_w.setStyleSheet("background:#020810;")
        lay = QVBoxLayout(content_w)
        lay.setContentsMargins(0, 4, 0, 4)
        lay.setSpacing(10)
        scroll.setWidget(content_w)
        outer_lay.addWidget(scroll, 1)

        self._cam_labels = {}

        # Allsky — fixed height, centered horizontally
        allsky_col = QVBoxLayout()
        allsky_col.setSpacing(2)
        t_allsky = QLabel("\U0001f30c  Allsky")
        t_allsky.setStyleSheet("font-size:9px; color:#3a6080;")
        t_allsky.setAlignment(Qt.AlignmentFlag.AlignCenter)
        allsky_col.addWidget(t_allsky)
        allsky_lbl = self._make_cam_label("allsky", 380)
        allsky_lbl.setFixedHeight(380)
        allsky_col.addWidget(allsky_lbl)
        allsky_row = QHBoxLayout()
        allsky_row.addStretch(1)
        allsky_row.addLayout(allsky_col, 2)
        allsky_row.addStretch(1)
        lay.addLayout(allsky_row)

        # Buildings — 4 per row, fixed height
        bldg_names = list(CAM_BUILDINGS.keys())
        row_layout = None
        for i, name in enumerate(bldg_names):
            if i % 4 == 0:
                row_layout = QHBoxLayout()
                row_layout.setSpacing(6)
                lay.addLayout(row_layout)
            col = QVBoxLayout()
            col.setSpacing(2)
            t = QLabel(f"\U0001f3d7  {name}")
            t.setStyleSheet("font-size:9px; color:#3a6080;")
            col.addWidget(t)
            lbl = self._make_cam_label(name, 180)
            lbl.setFixedHeight(180)
            col.addWidget(lbl)
            row_layout.addLayout(col, 1)
        remainder = len(bldg_names) % 4
        if remainder and row_layout:
            for _ in range(4 - remainder):
                row_layout.addStretch(1)
        lay.addStretch()

        # ── Weather section ───────────────────────────────────────────────────
        weather_hdr = QLabel("🌦  Weather")
        weather_hdr.setStyleSheet("font-size:11px; color:#50c0e0; font-weight:bold; margin-top:8px;")
        lay.addWidget(weather_hdr)

        weather_row = QHBoxLayout()
        weather_row.setSpacing(10)

        # GOES Southern Plains loop — direct GIF from NOAA CDN
        goes_col = QVBoxLayout()
        goes_col.setSpacing(2)
        goes_col.addWidget(QLabel("🛰  GOES-16 Southern Plains GeoColor"))
        self.lbl_goes = QLabel("Loading…")
        self.lbl_goes.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_goes.setFixedHeight(340)
        self.lbl_goes.setStyleSheet("background:#020810; border:1px solid #1a2a40; border-radius:3px; color:#3a5a80;")
        goes_col.addWidget(self.lbl_goes)
        weather_row.addLayout(goes_col, 3)

        self._goes_frames = []
        self._goes_idx    = 0
        self._goes_anim   = QTimer(self)
        self._goes_anim.timeout.connect(self._advance_goes)

        # ClearDarkSky chart — static GIF fetched as image
        cds_col = QVBoxLayout()
        cds_col.setSpacing(2)
        cds_col.addWidget(QLabel("🔭  Clear Dark Sky — Starfront Observatory TX"))
        self.lbl_cds = QLabel("Loading…")
        self.lbl_cds.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_cds.setFixedHeight(320)
        self.lbl_cds.setStyleSheet("background:#020810; border:1px solid #1a2a40; border-radius:3px; color:#3a5a80;")
        cds_col.addWidget(self.lbl_cds)
        weather_row.addLayout(cds_col, 2)

        lay.addLayout(weather_row)

        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.close)
        outer_lay.addWidget(btn_close)

        # Refresh timer while window is open
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._fetch_all)
        self._timer.start(CAM_REFRESH_SECS * 1000)
        import threading
        threading.Thread(target=self._fetch_all_bg, daemon=True).start()

    def _refresh_weather(self):
        import threading
        threading.Thread(target=self._fetch_weather, daemon=True).start()

    def _fetch_weather(self):
        import urllib.request, json, datetime
        try:
            req = urllib.request.Request(WF_URL, headers={"User-Agent": "RockwoodPlanetarium/1.0"})
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read())
            obs = data.get("obs", [{}])[0]
            # WeatherFlow field indices for station observations
            # obs format: [timestamp, wind_lull, wind_avg, wind_gust, wind_dir,
            #              wind_interval, pressure, temp, humidity, lux, uv, solar,
            #              rain_accum, precip_type, strike_avg_dist, strike_count,
            #              battery, report_interval, ...]
            fields = obs.get("obs", [[]])[0] if obs.get("obs") else []
            if not fields:
                # Try flat format
                fields = obs

            def _get(key, default=None):
                return obs.get(key, default)

            temp_c     = _get("air_temperature")
            dew_c      = _get("dew_point")
            wind_avg   = _get("wind_avg")        # m/s
            wind_gust  = _get("wind_gust")       # m/s
            humidity   = _get("relative_humidity")
            pressure   = _get("sea_level_pressure") or _get("barometric_pressure")
            rain       = _get("precip_accum_local_day", 0)
            lightning_d= _get("lightning_strike_last_distance")
            lightning_c= _get("lightning_strike_count_last_3hr", 0)

            def c_to_f(c):
                return round(c * 9/5 + 32, 1) if c is not None else None
            def ms_to_mph(ms):
                return round(ms * 2.237, 1) if ms is not None else None

            temp_f  = c_to_f(temp_c)
            dew_f   = c_to_f(dew_c)
            dew_delta = round(temp_f - dew_f, 1) if temp_f is not None and dew_f is not None else None
            wind_mph  = ms_to_mph(wind_avg)
            gust_mph  = ms_to_mph(wind_gust)

            # Dew delta color: green >10°F, yellow 5-10°F, red <5°F
            if dew_delta is not None:
                if dew_delta > 10:   dew_color = "#50e090"
                elif dew_delta > 5:  dew_color = "#f0c040"
                else:                dew_color = "#e04040"
            else:
                dew_color = "#c0e0ff"

            updated = datetime.datetime.now().strftime("%H:%M:%S")

            # Update UI on main thread via cam_signal
            self._wx_pending = {
                "temp":      f"{temp_f}°F" if temp_f is not None else "—",
                "dew":       f"{dew_delta}°F" if dew_delta is not None else "—",
                "dew_color": dew_color,
                "wind":      f"{wind_mph} mph" if wind_mph is not None else "—",
                "gust":      f"{gust_mph} mph" if gust_mph is not None else "—",
                "humidity":  f"{humidity}%" if humidity is not None else "—",
                "pressure":  f"{round(pressure, 1)} mb" if pressure is not None else "—",
                "rain":      f"{round(rain, 2)} in" if rain is not None else "—",
                "lightning": f"{lightning_d} mi ({lightning_c})" if lightning_d else "None",
                "updated":   updated,
            }
            self._cam_signal.emit("__wx__", b"1")
            print(f"[Obs] Weather: {temp_f}°F  dew_delta={dew_delta}°F  wind={wind_mph}mph")
        except Exception as e:
            print(f"[Obs] Weather fetch fail: {e}")
            self._cam_signal.emit("__wx__", b"0")

    def _make_cam_label(self, key, min_h):
        lbl = QLabel("Loading…")
        lbl.setObjectName(key)
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl.setMinimumHeight(min_h)
        lbl.setStyleSheet(
            "background:#020810; border:1px solid #1a2a40;"
            "border-radius:3px; color:#2a4060; font-size:10px;")
        self._cam_labels[key] = lbl
        return lbl

    def _fetch_all(self):
        import threading
        threading.Thread(target=self._fetch_all_bg, daemon=True).start()

    def _fetch_all_bg(self):
        import datetime
        mw = self._main
        # Allsky
        try:
            raw  = mw._fetch_jpeg(CAM_ALLSKY)
            data = mw._scale_jpeg(raw, 440)
            self._cam_signal.emit("allsky", data or b"")
        except Exception as e:
            self._cam_signal.emit("allsky", b"")
            print(f"[Obs] allsky fail: {e}")
        # Each building
        for name, url in CAM_BUILDINGS.items():
            try:
                raw  = mw._fetch_jpeg(url)
                data = mw._scale_jpeg(raw, 160)
                self._cam_signal.emit(name, data or b"")
            except Exception as e:
                self._cam_signal.emit(name, b"")
                print(f"[Obs] {name} fail: {e}")
        # GOES GIF — fetch and split into frames using PIL
        try:
            import io as _io
            raw = mw._fetch_jpeg(GOES_GIF_URL)
            print(f"[Obs] GOES GIF {len(raw)} bytes")
            from PIL import Image as _PILImage
            gif = _PILImage.open(_io.BytesIO(raw))
            frames = []
            try:
                while True:
                    frame = gif.copy().convert("RGB")
                    buf = _io.BytesIO()
                    frame.resize((600, 600), _PILImage.LANCZOS).save(buf, format="JPEG", quality=85)
                    frames.append(buf.getvalue())
                    gif.seek(gif.tell() + 1)
            except EOFError:
                pass
            print(f"[Obs] GOES {len(frames)} frames extracted")
            self._goes_frame_data = frames  # store directly, avoid large signal payload
            self._cam_signal.emit("__goes_ready__", b"1")
        except Exception as e:
            print(f"[Obs] GOES fail: {e}")
            self._goes_frame_data = []
            self._cam_signal.emit("__goes_ready__", b"0")

        # ClearDarkSky chart
        try:
            cds_raw  = mw._fetch_jpeg(CLEAR_DARK_SKY)
            cds_data = mw._scale_jpeg(cds_raw, 300)
            self._cam_signal.emit("__cds__", cds_data or b"")
        except Exception as e:
            self._cam_signal.emit("__cds__", b"")
            print(f"[Obs] CDS fail: {e}")

        import datetime
        updated = datetime.datetime.now().strftime("%H:%M:%S")
        self._cam_signal.emit("__updated__", updated.encode())

    def _advance_goes(self):
        if not self._goes_frames: return
        self._goes_idx = (self._goes_idx + 1) % len(self._goes_frames)
        self.lbl_goes.setPixmap(self._goes_frames[self._goes_idx])

    def _on_cam_data(self, key, data):
        if key == "__wx__":
            wx = getattr(self, "_wx_pending", None)
            if not wx: return
            self._wx_temp.setText(wx["temp"])
            dew_lbl = self._wx_dew
            dew_lbl.setText(wx["dew"])
            dew_lbl.setStyleSheet(f"color:{wx['dew_color']}; font-size:12px; font-weight:bold;")
            self._wx_wind.setText(wx["wind"])
            self._wx_gust.setText(wx["gust"])
            self._wx_humidity.setText(wx["humidity"])
            self._wx_pressure.setText(wx["pressure"])
            self._wx_rain.setText(wx["rain"])
            self._wx_lightning.setText(wx["lightning"])
            self._wx_updated.setText(f"Weather updated {wx['updated']}")
            return

        if key == "__updated__":
            self.lbl_updated.setText(f"Updated {data.decode()}  ·  auto-refreshes every {CAM_REFRESH_SECS}s")
            return
        if key == "__goes_ready__":
            from PyQt6.QtGui import QImage, QPixmap
            self._goes_frames = []
            self._goes_anim.stop()
            for part in getattr(self, "_goes_frame_data", []):
                if len(part) > 64:
                    img = QImage.fromData(bytes(part))
                    if not img.isNull():
                        self._goes_frames.append(QPixmap.fromImage(img))
            if self._goes_frames:
                self._goes_idx = 0
                self.lbl_goes.setPixmap(self._goes_frames[0])
                self._goes_anim.setInterval(150)
                self._goes_anim.start()
                print(f"[Obs] GOES animating {len(self._goes_frames)} frames")
            else:
                self.lbl_goes.setText("GOES data unavailable")
            return

        if key == "__cds__":
            if data and len(data) > 64:
                from PyQt6.QtGui import QMovie, QImage, QPixmap
                from PyQt6.QtCore import QByteArray, QBuffer
                img = QImage.fromData(bytes(data))
                if not img.isNull():
                    self.lbl_cds.setPixmap(QPixmap.fromImage(img))
            return
        lbl = self._cam_labels.get(key)
        if not lbl: return
        if not data or len(data) < 64:
            lbl.setText("Unavailable")
            return
        from PyQt6.QtGui import QImage, QPixmap
        img = QImage.fromData(bytes(data))
        if img.isNull():
            lbl.setText("Bad image")
            return
        px = QPixmap.fromImage(img)
        lbl.setPixmap(px)

    def closeEvent(self, event):
        self._timer.stop()
        self._goes_anim.stop()
        self._wx_timer.stop()
        super().closeEvent(event)



class _GuidingChartWidget(QWidget):
    """Dual-line guiding chart: RA (green) and Dec (magenta) error in arcsec over time."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._ra_pts   = []
        self._dec_pts  = []
        self._time_labels = []
        self._rms_ra   = None
        self._rms_dec  = None
        self.setMinimumHeight(180)

    def set_data(self, frames):
        if not frames:
            self._ra_pts = []; self._dec_pts = []; self._time_labels = []
            self._rms_ra = self._rms_dec = None
            self.update(); return
        ts_vals = [f["ts"] for f in frames if f.get("ts") is not None]
        if not ts_vals:
            self.update(); return
        t_min, t_max = min(ts_vals), max(ts_vals)
        span = (t_max - t_min) or 1.0
        self._ra_pts = []; self._dec_pts = []
        ra_vals = []; dec_vals = []
        for f in frames:
            if f.get("ts") is None: continue
            x = (f["ts"] - t_min) / span
            if f.get("ra_raw") is not None:
                try:
                    v = float(f["ra_raw"])
                    self._ra_pts.append((x, v)); ra_vals.append(v)
                except: pass
            if f.get("dec_raw") is not None:
                try:
                    v = float(f["dec_raw"])
                    self._dec_pts.append((x, v)); dec_vals.append(v)
                except: pass
        import math
        self._rms_ra  = math.sqrt(sum(v*v for v in ra_vals)  / len(ra_vals))  if ra_vals  else None
        self._rms_dec = math.sqrt(sum(v*v for v in dec_vals) / len(dec_vals)) if dec_vals else None
        import datetime
        self._time_labels = []
        for frac in (0.0, 0.25, 0.5, 0.75, 1.0):
            t = t_min + frac * span
            lbl = datetime.datetime.utcfromtimestamp(t).strftime("%H:%M")
            self._time_labels.append((frac, lbl))
        self.update()

    def paintEvent(self, event):
        from PyQt6.QtGui import QPainter
        p = QPainter(self)
        try: self._do_paint(p)
        except Exception as e: print(f"[GuidingChart] paint error: {e}")
        finally: p.end()

    def _do_paint(self, p):
        from PyQt6.QtGui import QPen, QFont
        from PyQt6.QtCore import QPointF
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        W, H = self.width(), self.height()
        pad_l, pad_r, pad_t, pad_b = 52, 52, 20, 32
        p.fillRect(0, 0, W, H, QColor("#050d20"))

        if not self._ra_pts and not self._dec_pts:
            p.setPen(QColor("#3a5a80"))
            p.drawText(0, 0, W, H, Qt.AlignmentFlag.AlignCenter, "No guiding data yet")
            return

        chart_w = W - pad_l - pad_r
        chart_h = H - pad_t - pad_b
        p.setFont(QFont("Courier New", 8))

        all_vals = [v for _, v in self._ra_pts] + [v for _, v in self._dec_pts]
        if not all_vals: return
        max_abs = max(abs(v) for v in all_vals)
        max_abs = max(max_abs * 1.2, 0.5)   # symmetric around zero, min ±0.5"

        def to_px(x_norm, val):
            px = pad_l + int(chart_w * x_norm)
            py = pad_t + int(chart_h * (0.5 - val / (2 * max_abs)))
            return QPointF(float(px), float(py))

        # Zero line and grid
        zero_y = pad_t + chart_h // 2
        p.setPen(QPen(QColor("#1a3060"), 1))
        p.drawLine(pad_l, zero_y, W - pad_r, zero_y)
        for frac in (0.25, 0.75):
            y = pad_t + int(chart_h * frac)
            p.setPen(QPen(QColor("#111e30"), 1))
            p.drawLine(pad_l, y, W - pad_r, y)

        # Y axis labels (arcsec)
        p.setPen(QColor("#3a6080"))
        for frac in (0.0, 0.5, 1.0):
            val = max_abs - frac * 2 * max_abs
            y   = pad_t + int(chart_h * frac)
            p.drawText(0, y - 6, pad_l - 4, 14, Qt.AlignmentFlag.AlignRight, f'{val:+.1f}"')

        RA_COLOR  = "#40e080"
        DEC_COLOR = "#e040a0"

        def draw_line(pts, color, dashed=False):
            if len(pts) < 2: return
            style = Qt.PenStyle.DashLine if dashed else Qt.PenStyle.SolidLine
            p.setPen(QPen(QColor(color), 1.5, style))
            for i in range(1, len(pts)):
                p.drawLine(to_px(*pts[i-1]), to_px(*pts[i]))

        draw_line(self._ra_pts,  RA_COLOR)
        draw_line(self._dec_pts, DEC_COLOR, dashed=True)

        # RMS readout top-right
        rms_parts = []
        if self._rms_ra  is not None: rms_parts.append(f'RA {self._rms_ra:.2f}"')
        if self._rms_dec is not None: rms_parts.append(f'Dec {self._rms_dec:.2f}"')
        if rms_parts:
            p.setPen(QColor("#5a8a6a"))
            p.drawText(pad_l, 2, chart_w, 16, Qt.AlignmentFlag.AlignRight,
                       "RMS  " + "  ".join(rms_parts))

        # X axis time labels
        p.setPen(QColor("#3a6080"))
        for x_norm, lbl in self._time_labels:
            x = pad_l + int(chart_w * x_norm)
            p.drawText(x - 20, H - pad_b + 4, 40, 16, Qt.AlignmentFlag.AlignCenter, lbl)

        p.setPen(QPen(QColor("#1a3060"), 1))
        p.drawRect(pad_l, pad_t, chart_w, chart_h)



class _LeaderboardWindow(QDialog):
    """Non-modal leaderboard window with category and period tabs."""

    _data_signal = pyqtSignal(dict)

    def __init__(self, main_win, parent=None):
        super().__init__(parent)
        self._main = main_win
        self.setWindowTitle("Starfront — Leaderboard")
        self.setMinimumSize(560, 560)
        self.setWindowFlags(
            Qt.WindowType.Window |
            Qt.WindowType.WindowCloseButtonHint |
            Qt.WindowType.WindowMinimizeButtonHint)
        self.setStyleSheet(
            "QDialog { background:#050d18; color:#7ab0e0; }"
            "QLabel  { color:#7ab0e0; font-size:10px; }")
        self._data_signal.connect(self._on_data)
        self._lb_period   = "alltime"
        self._lb_category = "exposure"

        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 12, 10)
        lay.setSpacing(8)

        # Title + my stats
        hdr = QHBoxLayout()
        title = QLabel("🏆  Leaderboard")
        title.setStyleSheet("color:#f0c040; font-size:14px; font-weight:bold;")
        hdr.addWidget(title)
        hdr.addStretch()
        lay.addLayout(hdr)

        self.lbl_my_stats = QLabel(main_win.lbl_my_stats.text())
        self.lbl_my_stats.setStyleSheet(
            "background:rgba(10,20,50,180);color:#7ab0e0;font-size:10px;"
            "padding:6px 8px;border-radius:4px;border:1px solid #1a3060;")
        self.lbl_my_stats.setWordWrap(True)
        lay.addWidget(self.lbl_my_stats)

        def _btn_style(color="#4a8af0"):
            return (
                f"QPushButton {{ background:#0d1520; color:#4a7090; border:1px solid #1a3060;"
                f"border-radius:3px; font-size:10px; padding:3px 8px; }}"
                f"QPushButton:checked {{ background:#1a3060; color:{color}; border-color:{color}; }}"
                f"QPushButton:hover {{ background:#1a2540; }}")

        # Period row
        period_row = QHBoxLayout(); period_row.setSpacing(6)
        self.btn_alltime = QPushButton("All Time")
        self.btn_month   = QPushButton("This Month")
        for btn in (self.btn_alltime, self.btn_month):
            btn.setCheckable(True); btn.setStyleSheet(_btn_style())
        self.btn_alltime.setChecked(True)
        self.btn_alltime.clicked.connect(lambda: self._set_period("alltime"))
        self.btn_month.clicked.connect(lambda: self._set_period("month"))
        period_row.addWidget(QLabel("Period:"))
        period_row.addWidget(self.btn_alltime)
        period_row.addWidget(self.btn_month)
        period_row.addStretch()
        lay.addLayout(period_row)

        # Category row
        cat_row = QHBoxLayout(); cat_row.setSpacing(6)
        self._cat_btns = {}
        cats = [
            ("exposure",    "⏱ Exposure",   "#a0d0ff"),
            ("deep_diver",  "🔭 Deep Diver", "#f0c040"),
            ("marathon",    "🌙 Marathon",   "#c060ff"),
            ("sii",         "🟥 SII",        "#ff6060"),
            ("guiding_rms", "📡 Guiding",    "#50e090"),
        ]
        for cat_id, label, color in cats:
            btn = QPushButton(label)
            btn.setCheckable(True)
            btn.setStyleSheet(_btn_style(color))
            btn.clicked.connect(lambda _, c=cat_id: self._set_category(c))
            self._cat_btns[cat_id] = btn
            cat_row.addWidget(btn)
        self._cat_btns["exposure"].setChecked(True)
        cat_row.addStretch()
        lay.addLayout(cat_row)

        # Table
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["User", "Exposure", "Nights"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        self.table.setShowGrid(False)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setStyleSheet(
            "QTableWidget { background:#0a1525; alternate-background-color:#0d1a2e;"
            "border:1px solid #1a2a40; font-size:11px; }"
            "QHeaderView::section { background:#0d1520; color:#5a8ab0; font-size:10px;"
            "padding:4px; border-bottom:1px solid #1a3060; }"
            "QTableWidget::item { padding:5px 8px; border-bottom:1px solid #111d2e; }")
        self.table.doubleClicked.connect(self._on_row_double_clicked)
        lay.addWidget(self.table, 1)

        self.lbl_status = QLabel("Loading…")
        self.lbl_status.setStyleSheet("color:#2a4060; font-size:9px;")
        lay.addWidget(self.lbl_status)

        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.close)
        lay.addWidget(btn_close)

        self._refresh()

    def _set_period(self, period):
        self._lb_period = period
        self.btn_alltime.setChecked(period == "alltime")
        self.btn_month.setChecked(period == "month")
        self._refresh()

    def _set_category(self, category):
        self._lb_category = category
        for cid, btn in self._cat_btns.items():
            btn.setChecked(cid == category)
        self._refresh()

    def _refresh(self):
        self.lbl_status.setText("Loading…")
        import threading
        threading.Thread(target=self._fetch, daemon=True).start()

    def _fetch(self):
        period   = self._lb_period
        category = self._lb_category
        res, st  = self._main._sf_api("GET", f"/stats?period={period}&category={category}")
        if st == 200:
            rows = res.get("leaderboard", [])
            print(f"[LB] {category}/{period} got {len(rows)} rows, sample={rows[:2]}")
            self._data_signal.emit({"rows": rows, "category": category})
        else:
            print(f"[LB] HTTP {st}: {res}")
            self._data_signal.emit({"rows": [], "category": category, "error": st})

    def _on_data(self, data):
        from PyQt6.QtCore import Qt as _Qt
        rows     = data.get("rows", [])
        category = data.get("category", "exposure")
        error    = data.get("error")

        if error:
            self.lbl_status.setText(f"Error loading data ({error})")
            return

        headers = {
            "exposure":    ("User", "Exposure",  "Nights"),
            "deep_diver":  ("User", "Exposure",  "Target"),
            "marathon":    ("User", "Streak",    ""),
            "sii":         ("User", "SII Time",  ""),
            "guiding_rms": ("User", 'RMS"',      "Frames"),
        }
        h = headers.get(category, ("User", "Value", ""))
        self.table.setHorizontalHeaderLabels(list(h))

        medals = ["🥇", "🥈", "🥉"]
        self.table.setRowCount(0)
        for i, r in enumerate(rows):
            row = self.table.rowCount()
            self.table.insertRow(row)
            medal = medals[i] if i < 3 else f"#{i+1}"
            ni = QTableWidgetItem(f"{medal}  {r['username']}")

            if category == "exposure":
                ei = QTableWidgetItem(self._main._fmt_exposure(r.get("total_secs", 0)))
                di = QTableWidgetItem(str(r.get("nights", 0)))
            elif category == "deep_diver":
                ei = QTableWidgetItem(self._main._fmt_exposure(r.get("total_secs", 0)))
                di = QTableWidgetItem(r.get("target", "")[:24])
            elif category == "marathon":
                ei = QTableWidgetItem(f"{r.get('streak', 0)} nights")
                di = QTableWidgetItem("")
            elif category == "sii":
                ei = QTableWidgetItem(self._main._fmt_exposure(r.get("total_secs", 0)))
                di = QTableWidgetItem("")
            elif category == "guiding_rms":
                ei = QTableWidgetItem(f"{r.get('rms', 0):.3f}\"")
                di = QTableWidgetItem(str(r.get("guide_frames", 0)))
            else:
                ei = QTableWidgetItem("")
                di = QTableWidgetItem("")

            ei.setTextAlignment(_Qt.AlignmentFlag.AlignCenter)
            di.setTextAlignment(_Qt.AlignmentFlag.AlignCenter)
            is_me = r.get("username","").lower() == self._main._sf_username.lower()
            color = QColor("#ffcc44") if is_me else QColor("#8ab8e0")
            for item in (ni, ei, di): item.setForeground(color)
            self.table.setItem(row, 0, ni)
            self.table.setItem(row, 1, ei)
            self.table.setItem(row, 2, di)

        self.lbl_status.setText(f"{len(rows)} users  ·  {'all time' if self._lb_period == 'alltime' else 'this month'}")

        # Keep main window my_stats in sync
        self.lbl_my_stats.setText(self._main.lbl_my_stats.text())

    def _on_row_double_clicked(self, index):
        item = self.table.item(index.row(), 0)
        if not item: return
        text = item.text().strip()
        # Strip medal prefix
        for pfx in ["🥇", "🥈", "🥉"]:
            text = text.replace(pfx, "")
        for i in range(1, 100):
            text = text.replace(f"#{i}", "")
        username = text.strip()
        if not username: return
        if getattr(self._main, "_profile_open", False): return
        self._main._profile_open = True
        dlg = UserProfileDialog(username, self._main._sf_host, self,
                                token=self._main._sf_token)
        dlg.finished.connect(lambda: setattr(self._main, "_profile_open", False))
        dlg.show()


class _ScopeDetailWindow(QDialog):
    """Non-modal floating window showing guiding graph for the user's own scope."""

    _data_signal = pyqtSignal(list, list)   # (guiding_frames, imaging_frames)

    def __init__(self, scope, session, sf_host, token, parent=None, last_image=None):
        super().__init__(parent)
        self._scope   = scope
        self._session = session
        self._sf_host = sf_host
        self._token   = token

        scope_name = scope.get("scope_name", scope.get("name", "Scope"))
        username   = scope.get("username", "")
        target     = session.get("targets", session.get("scope", "")) if session else ""
        date       = session.get("date", "") if session else ""

        self.setWindowTitle(f"{scope_name}  —  Scope Status")
        self.setMinimumSize(860, 580)
        self.setWindowFlags(
            Qt.WindowType.Window |
            Qt.WindowType.WindowCloseButtonHint |
            Qt.WindowType.WindowMinimizeButtonHint)
        self.setStyleSheet(
            "QDialog{background:#050d18;color:#7ab0e0;}"
            "QLabel{color:#7ab0e0;font-size:10px;}")
        self._data_signal.connect(self._on_data)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 8)
        outer.setSpacing(10)

        # ── Left: charts ─────────────────────────────────────────────────────
        lay = QVBoxLayout()
        lay.setSpacing(8)
        outer.addLayout(lay, 3)

        # Header
        hdr = QLabel(f"<b>{scope_name}</b>" +
                     (f"  ·  <span style='color:#5090c0;'>{username}</span>" if username else "") +
                     (f"  ·  {target}" if target else "") +
                     (f"  ·  <span style='color:#3a6080;'>{date}</span>" if date else ""))
        hdr.setStyleSheet("color:#a0d0f0; font-size:12px;")
        lay.addWidget(hdr)

        # Guiding chart
        guide_hdr = QHBoxLayout()
        guide_hdr.addWidget(QLabel(
            '<span style="color:#40e080;">━━  RA error (arcsec)</span>' +
            '&nbsp;&nbsp;' +
            '<span style="color:#e040a0;">╌╌  Dec error (arcsec)</span>'))
        guide_hdr.addStretch()
        self._lbl_guide_status = QLabel("Loading guiding data…")
        self._lbl_guide_status.setStyleSheet("color:#3a6080; font-size:9px;")
        guide_hdr.addWidget(self._lbl_guide_status)
        lay.addLayout(guide_hdr)

        self._guide_chart = _GuidingChartWidget(self)
        lay.addWidget(self._guide_chart, 2)

        sep = QLabel()
        sep.setFixedHeight(1)
        sep.setStyleSheet("background:#1a3060;")
        lay.addWidget(sep)

        fwhm_hdr = QLabel(
            '<span style="color:#40d0d0;">━━  FWHM (arcsec)</span>' +
            '&nbsp;&nbsp;' +
            '<span style="color:#f0c040;">╌╌  Airmass</span>')
        lay.addWidget(fwhm_hdr)

        self._fwhm_chart = _LineChartWidget(self)
        lay.addWidget(self._fwhm_chart, 1)

        self._lbl_fwhm_status = QLabel("")
        self._lbl_fwhm_status.setStyleSheet("color:#3a6080; font-size:9px;")
        lay.addWidget(self._lbl_fwhm_status)

        btn = QPushButton("Close")
        btn.clicked.connect(self.close)
        lay.addWidget(btn)

        # ── Right: last image ────────────────────────────────────────────────
        img_col = QVBoxLayout()
        img_col.setSpacing(4)
        img_lbl_hdr = QLabel("🖼  Last Subframe")
        img_lbl_hdr.setStyleSheet("color:#5090c0; font-size:10px; font-weight:bold;")
        img_col.addWidget(img_lbl_hdr)

        self._lbl_last_image = QLabel("No image yet")
        self._lbl_last_image.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._lbl_last_image.setMinimumWidth(280)
        self._lbl_last_image.setStyleSheet(
            "background:#020810; border:1px solid #1a2a40; border-radius:3px;"
            "color:#3a5a80; font-size:10px;")
        img_col.addWidget(self._lbl_last_image, 1)

        self._lbl_image_info = QLabel("")
        self._lbl_image_info.setStyleSheet("color:#3a6080; font-size:9px;")
        self._lbl_image_info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._lbl_image_info.setWordWrap(True)
        img_col.addWidget(self._lbl_image_info)

        img_col.addStretch()
        outer.addLayout(img_col, 1)

        # Load initial image if provided
        if last_image:
            self.update_image(last_image)

        import threading
        threading.Thread(target=self._load, daemon=True).start()

    def update_image(self, data):
        """Called from main thread when a new image arrives for this scope."""
        from PyQt6.QtGui import QImage, QPixmap
        if not data or len(data) < 64: return
        img = QImage.fromData(bytes(data))
        if img.isNull(): return
        px = QPixmap.fromImage(img)
        # Scale to fit the label
        lbl_w = self._lbl_last_image.width() or 280
        lbl_h = self._lbl_last_image.height() or 400
        scaled = px.scaled(lbl_w, lbl_h,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation)
        self._lbl_last_image.setPixmap(scaled)
        self._lbl_last_image.setText("")
        import datetime
        self._lbl_image_info.setText(
            f"Updated {datetime.datetime.now().strftime('%H:%M:%S')}  ·  "
            f"{px.width()}×{px.height()}px")

    def _load(self):
        import http.client, json as _j
        session_id = (self._session or {}).get("session_id", "")
        guiding_frames = []
        imaging_frames = []

        if session_id:
            try:
                conn = http.client.HTTPSConnection(self._sf_host, 443, timeout=10)
                conn.request("GET", f"/session/{session_id}/guiding",
                             headers={"Authorization": f"Bearer {self._token}"})
                r = conn.getresponse()
                data = _j.loads(r.read())
                conn.close()
                guiding_frames = data.get("frames", [])
            except Exception as e:
                print(f"[ScopeDetail] guiding fetch error: {e}")

            try:
                conn = http.client.HTTPSConnection(self._sf_host, 443, timeout=10)
                conn.request("GET", f"/session/{session_id}/frames",
                             headers={"Authorization": f"Bearer {self._token}"})
                r = conn.getresponse()
                data = _j.loads(r.read())
                conn.close()
                imaging_frames = data.get("frames", [])
            except Exception as e:
                print(f"[ScopeDetail] frames fetch error: {e}")

        self._data_signal.emit(guiding_frames, imaging_frames)

    def _on_data(self, guiding_frames, imaging_frames):
        self._guide_chart.set_data(guiding_frames)
        self._fwhm_chart.set_data(imaging_frames)

        if guiding_frames:
            self._lbl_guide_status.setText(f"{len(guiding_frames)} guide frames")
        else:
            self._lbl_guide_status.setText("No guiding data for this session — requires plugin v1.0.1+")

        if imaging_frames:
            has_fwhm    = any(f.get("fwhm")    is not None for f in imaging_frames)
            has_airmass = any(f.get("airmass") is not None for f in imaging_frames)
            parts = []
            if has_fwhm:    parts.append("FWHM")
            if has_airmass: parts.append("airmass")
            msg = f"{len(imaging_frames)} frames" + (f"  ·  {' & '.join(parts)}" if parts else "")
            self._lbl_fwhm_status.setText(msg)
        else:
            self._lbl_fwhm_status.setText("No imaging frames for this session")


class _LineChartWidget(QWidget):
    """Dual-axis line chart: FWHM (left, cyan) and Airmass (right, amber) over time."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._fwhm_pts    = []
        self._air_pts     = []
        self._time_labels = []
        self.setMinimumHeight(200)

    def set_data(self, frames):
        if not frames:
            self._fwhm_pts = []; self._air_pts = []; self._time_labels = []
            self.update(); return
        ts_vals = [f["ts"] for f in frames if f.get("ts") is not None]
        if not ts_vals:
            self.update(); return
        t_min, t_max = min(ts_vals), max(ts_vals)
        span = (t_max - t_min) or 1.0
        self._fwhm_pts, self._air_pts = [], []
        for f in frames:
            if f.get("ts") is None:
                continue
            x = (f["ts"] - t_min) / span
            if f.get("fwhm") is not None:
                try: self._fwhm_pts.append((x, float(f["fwhm"])))
                except: pass
            if f.get("airmass") is not None:
                try: self._air_pts.append((x, float(f["airmass"])))
                except: pass
        import datetime
        self._time_labels = []
        for frac in (0.0, 0.25, 0.5, 0.75, 1.0):
            t = t_min + frac * span
            lbl = datetime.datetime.utcfromtimestamp(t).strftime("%H:%M")
            self._time_labels.append((frac, lbl))
        self.update()

    def paintEvent(self, event):
        from PyQt6.QtGui import QPainter, QPen
        from PyQt6.QtCore import QPointF
        p = QPainter(self)
        try:
            self._do_paint(p)
        except Exception as e:
            print(f"[LineChart] paint error: {e}")
        finally:
            p.end()

    def _do_paint(self, p):
        from PyQt6.QtGui import QPainter, QPen
        from PyQt6.QtCore import QPointF
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        W, H = self.width(), self.height()
        pad_l, pad_r, pad_t, pad_b = 52, 52, 16, 32
        p.fillRect(0, 0, W, H, QColor("#050d20"))
        if not self._fwhm_pts and not self._air_pts:
            p.setPen(QColor("#3a5a80"))
            p.drawText(0, 0, W, H, Qt.AlignmentFlag.AlignCenter, "No frame data yet")
            return
        chart_w = W - pad_l - pad_r
        chart_h = H - pad_t - pad_b
        p.setFont(QFont("Courier New", 8))

        # Grid
        for frac in (0.25, 0.5, 0.75, 1.0):
            y = pad_t + int(chart_h * (1.0 - frac))
            p.setPen(QPen(QColor("#1a2a40"), 1))
            p.drawLine(pad_l, y, W - pad_r, y)

        FWHM_COLOR = "#40d0d0"
        AIR_COLOR  = "#f0c040"

        if self._fwhm_pts:
            fwhm_vals = [v for _, v in self._fwhm_pts]
            fwhm_min  = max(0.0, min(fwhm_vals) - 0.5)
            fwhm_max  = max(fwhm_vals) + 0.5
            fwhm_span = (fwhm_max - fwhm_min) or 1.0
            p.setPen(QColor(FWHM_COLOR))
            for frac in (0.0, 0.5, 1.0):
                v = fwhm_min + frac * fwhm_span
                y = pad_t + int(chart_h * (1.0 - frac))
                p.drawText(0, y - 6, pad_l - 6, 14, Qt.AlignmentFlag.AlignRight, f"{v:.1f}")
            p.drawText(2, pad_t, pad_l - 4, 14, Qt.AlignmentFlag.AlignLeft, 'FWHM"')
            pts = []
            for x_norm, v in self._fwhm_pts:
                px = pad_l + int(chart_w * x_norm)
                py = pad_t + int(chart_h * (1.0 - (v - fwhm_min) / fwhm_span))
                pts.append(QPointF(float(px), float(py)))
            p.setPen(QPen(QColor(FWHM_COLOR), 2))
            for i in range(1, len(pts)):
                p.drawLine(pts[i-1], pts[i])
            p.setBrush(QColor(FWHM_COLOR))
            p.setPen(QPen(QColor(FWHM_COLOR), 1))
            for pt in pts:
                p.drawEllipse(pt, 3.0, 3.0)
            p.setBrush(Qt.BrushStyle.NoBrush)

        if self._air_pts:
            air_vals = [v for _, v in self._air_pts]
            air_min  = max(1.0, min(air_vals) - 0.1)
            air_max  = max(air_vals) + 0.1
            air_span = (air_max - air_min) or 1.0
            p.setPen(QColor(AIR_COLOR))
            for frac in (0.0, 0.5, 1.0):
                v = air_min + frac * air_span
                y = pad_t + int(chart_h * (1.0 - frac))
                p.drawText(W - pad_r + 4, y - 6, pad_r - 4, 14, Qt.AlignmentFlag.AlignLeft, f"{v:.2f}")
            p.drawText(W - pad_r + 2, pad_t, pad_r - 4, 14, Qt.AlignmentFlag.AlignLeft, "AM")
            pts = []
            for x_norm, v in self._air_pts:
                px = pad_l + int(chart_w * x_norm)
                py = pad_t + int(chart_h * (1.0 - (v - air_min) / air_span))
                pts.append(QPointF(float(px), float(py)))
            p.setPen(QPen(QColor(AIR_COLOR), 2, Qt.PenStyle.DashLine))
            for i in range(1, len(pts)):
                p.drawLine(pts[i-1], pts[i])
            p.setBrush(QColor(AIR_COLOR))
            p.setPen(QPen(QColor(AIR_COLOR), 1))
            for pt in pts:
                p.drawEllipse(pt, 3.0, 3.0)
            p.setBrush(Qt.BrushStyle.NoBrush)

        p.setPen(QColor("#3a6080"))
        for x_norm, lbl in self._time_labels:
            x = pad_l + int(chart_w * x_norm)
            p.drawText(x - 20, H - pad_b + 4, 40, 16, Qt.AlignmentFlag.AlignCenter, lbl)
        p.setPen(QPen(QColor("#1a3060"), 1))
        p.drawRect(pad_l, pad_t, chart_w, chart_h)


class _SessionChartDialog(QDialog):
    """Shows FWHM and airmass over the course of one imaging session."""
    def __init__(self, session, sf_host, token, parent=None):
        super().__init__(parent)
        self._session = session
        self._sf_host = sf_host
        self._token   = token
        date    = session.get("date", "")
        targets = session.get("targets", session.get("scope", "unknown"))
        scope   = session.get("scope", "")
        self.setWindowTitle(f"Session — {date}  ·  {targets}")
        self.setMinimumSize(640, 400)
        self.setStyleSheet("QDialog{background:#050d18;color:#7ab0e0;} QLabel{color:#7ab0e0;font-size:10px;}")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(8)
        hdr = QLabel(
            f"<b>{targets}</b>  ·  {date}"
            + (f"  ·  <span style='color:#3a6080;'>via {scope}</span>" if scope else "")
        )
        hdr.setStyleSheet("color:#a0d0f0;font-size:11px;")
        lay.addWidget(hdr)
        legend = QLabel(
            '<span style="color:#40d0d0;">━━  FWHM (arcsec)</span>'
            '&nbsp;&nbsp;&nbsp;'
            '<span style="color:#f0c040;">╌╌  Airmass</span>'
        )
        legend.setStyleSheet("font-size:10px;")
        lay.addWidget(legend)
        self._chart = _LineChartWidget(self)
        lay.addWidget(self._chart, 1)
        self._status = QLabel("Loading frame data…")
        self._status.setStyleSheet("color:#3a6080;font-size:9px;")
        lay.addWidget(self._status)
        btn = QPushButton("Close")
        btn.clicked.connect(self.accept)
        lay.addWidget(btn)
        import threading
        threading.Thread(target=self._load, daemon=True).start()

    def _load(self):
        import http.client, json as _j
        from PyQt6.QtCore import QTimer
        session_id = self._session.get("session_id", "")
        if not session_id:
            self._set_status("No session ID — cannot load frame data.")
            return
        try:
            conn = http.client.HTTPConnection(self._sf_host, 8088, timeout=10)
            conn.request("GET", f"/session/{session_id}/frames",
                         headers={"Authorization": f"Bearer {self._token}"})
            r    = conn.getresponse()
            data = _j.loads(r.read())
            conn.close()
            frames      = data.get("frames", [])
            has_fwhm    = any(f.get("fwhm")    is not None for f in frames)
            has_airmass = any(f.get("airmass") is not None for f in frames)
            if not frames:
                msg = "No frame data recorded for this session."
            elif not has_fwhm and not has_airmass:
                msg = f"{len(frames)} frames — no FWHM or airmass data (upgrade your plugin)."
            else:
                parts = []
                if has_fwhm:    parts.append("FWHM")
                if has_airmass: parts.append("airmass")
                msg = f"{len(frames)} frames  ·  showing {' & '.join(parts)}"
            self._set_status(msg)
            self._pending_frames = frames
            QTimer.singleShot(0, self._apply_frames)
        except Exception as e:
            self._set_status(f"Error: {e}")

    def _apply_frames(self):
        frames = getattr(self, "_pending_frames", [])
        self._chart.set_data(frames)

    def _set_status(self, msg):
        from PyQt6.QtCore import QMetaObject, Q_ARG, Qt as _Qt
        QMetaObject.invokeMethod(
            self._status, "setText",
            _Qt.ConnectionType.QueuedConnection,
            Q_ARG(str, msg))


class UserProfileDialog(QDialog):
    """Profile popup — monthly exposure + per-target filter breakdown."""

    # Filter colours for the bar chart
    FILTER_COLORS = {
        "ha": "#ff4444", "h":  "#ff4444", "halpha": "#ff4444",
        "oiii": "#44aaff", "o": "#44aaff",
        "sii":  "#ffaa44", "s": "#ffaa44",
        "r":    "#ff6666", "red": "#ff6666",
        "g":    "#66ff66", "green": "#66ff66",
        "b":    "#6688ff", "blue": "#6688ff",
        "l":    "#aaccff", "lum": "#aaccff", "luminance": "#aaccff",
    }

    def __init__(self, username, sf_host, parent=None, token="", is_own=False):
        super().__init__(parent)
        self.setWindowTitle(f"Profile: {username}")
        self.setMinimumSize(560, 640)
        if parent:
            self.setStyleSheet(parent.styleSheet())
        self._username = username
        self._sf_host  = sf_host
        self._targets  = []
        self._token    = token
        self._is_own_profile = is_own

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(10)

        # Header
        lbl = QLabel(f"<b style='font-size:15px;color:#8ab8e8;'>&#128100; {username}</b>")
        lbl.setTextFormat(Qt.TextFormat.RichText)
        layout.addWidget(lbl)

        # Summary
        self.lbl_summary = QLabel("Loading...")
        self.lbl_summary.setStyleSheet(
            "background:rgba(10,20,50,180);color:#7ab0e0;font-size:10px;"
            "padding:6px 8px;border-radius:4px;border:1px solid #1a3060;")
        self.lbl_summary.setWordWrap(True)
        layout.addWidget(self.lbl_summary)

        # Tab bar: Monthly | Targets
        self.tab_bar = QTabWidget()
        self.tab_bar.setStyleSheet(
            "QTabBar::tab{background:#0a1828;color:#5080a0;padding:5px 14px;"
            "border:1px solid #1a3060;border-bottom:none;border-radius:3px 3px 0 0;}"
            "QTabBar::tab:selected{background:#0d2040;color:#8ab8e0;}"
            "QTabWidget::pane{border:1px solid #1a3060;background:#050d20;}")
        layout.addWidget(self.tab_bar)

        # ── Monthly tab ──────────────────────────────────────────────────────
        monthly_w = QWidget()
        monthly_l = QVBoxLayout(monthly_w)
        monthly_l.setContentsMargins(8, 8, 8, 8)
        monthly_l.addWidget(QLabel("Monthly Exposure (hours)"))
        self.monthly_chart = _BarChartWidget(self)
        self.monthly_chart.setMinimumHeight(180)
        monthly_l.addWidget(self.monthly_chart)
        self.tab_bar.addTab(monthly_w, "📅  Monthly")

        # ── Targets tab ──────────────────────────────────────────────────────
        targets_w = QWidget()
        targets_l = QHBoxLayout(targets_w)
        targets_l.setContentsMargins(8, 8, 8, 8)
        targets_l.setSpacing(8)

        # Left: target list
        left_w = QWidget(); left_l = QVBoxLayout(left_w)
        left_l.setContentsMargins(0,0,0,0); left_l.setSpacing(4)
        left_l.addWidget(QLabel("Objects"))
        self.target_list = QListWidget()
        self.target_list.setMaximumWidth(160)
        self.target_list.setStyleSheet(
            "QListWidget{background:#050d20;color:#7ab0e0;border:1px solid #1a3060;"
            "font-size:10px;font-family:'Courier New';}"
            "QListWidget::item:selected{background:#1a3060;color:#e0f0ff;}")
        self.target_list.currentRowChanged.connect(self._on_target_selected)
        left_l.addWidget(self.target_list)
        targets_l.addWidget(left_w)

        # Right: target detail
        right_w = QWidget(); right_l = QVBoxLayout(right_w)
        right_l.setContentsMargins(0,0,0,0); right_l.setSpacing(6)

        self.lbl_target_summary = QLabel("")
        self.lbl_target_summary.setStyleSheet(
            "background:rgba(10,20,50,180);color:#7ab0e0;font-size:10px;"
            "padding:5px 8px;border-radius:4px;border:1px solid #1a3060;")
        self.lbl_target_summary.setWordWrap(True)
        right_l.addWidget(self.lbl_target_summary)

        right_l.addWidget(QLabel("Exposure by Filter (hours)"))
        self.filter_chart = _BarChartWidget(self)
        self.filter_chart.setMinimumHeight(140)
        right_l.addWidget(self.filter_chart)

        right_l.addWidget(QLabel("By Scope"))
        self.scope_table = QTableWidget(0, 3)
        self.scope_table.setHorizontalHeaderLabels(["Scope", "Exposure", "Filters"])
        self.scope_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.scope_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        self.scope_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.scope_table.setColumnWidth(1, 64)
        self.scope_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.scope_table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        self.scope_table.setMaximumHeight(100)
        self.scope_table.setStyleSheet("QTableWidget{font-size:10px;}")
        right_l.addWidget(self.scope_table)

        right_l.addWidget(QLabel("Sessions  (double-click to view FWHM & airmass chart)"))
        self.session_table = QTableWidget(0, 4)
        self.session_table.setHorizontalHeaderLabels(["Date", "Exposure", "Frames", "Scope"])
        self.session_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        self.session_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        self.session_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
        self.session_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.session_table.setColumnWidth(0, 82)
        self.session_table.setColumnWidth(1, 62)
        self.session_table.setColumnWidth(2, 52)
        self.session_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.session_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.session_table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.session_table.verticalHeader().setVisible(False)
        self.session_table.setMaximumHeight(110)
        self.session_table.setStyleSheet(
            "QTableWidget{background:rgba(0,5,15,180);color:#8ab8e0;"
            "border:1px solid #1a2a40;border-radius:4px;font-size:10px;}"
            "QTableWidget::item:selected{background:#1a3060;color:#e0f0ff;}")
        self.session_table.itemDoubleClicked.connect(self._on_session_clicked)
        right_l.addWidget(self.session_table)
        targets_l.addWidget(right_w, 1)

        self.tab_bar.addTab(targets_w, "🔭  Targets")

        # ── Telescopes tab ───────────────────────────────────────────────
        tel_w = QWidget()
        tel_l = QVBoxLayout(tel_w)
        tel_l.setContentsMargins(8, 8, 8, 8)
        tel_l.setSpacing(8)
        self.tel_scroll = QScrollArea()
        self.tel_scroll.setWidgetResizable(True)
        self.tel_scroll.setStyleSheet(
            "QScrollArea{border:none;background:transparent;}")
        self.tel_container = QWidget()
        self.tel_container_l = QVBoxLayout(self.tel_container)
        self.tel_container_l.setSpacing(10)
        self.tel_container_l.addStretch()
        self.tel_scroll.setWidget(self.tel_container)
        tel_l.addWidget(self.tel_scroll)
        self.tab_bar.addTab(tel_w, "🛸  Telescopes")
        self._scope_note_editors = {}

        # Close button
        btn = QPushButton("Close")
        btn.clicked.connect(self.accept)
        layout.addWidget(btn)

        import threading
        threading.Thread(target=self._load, daemon=True).start()

    @staticmethod
    def _fmt(secs):
        secs = int(secs)
        h = secs // 3600; m = (secs % 3600) // 60
        return f"{h}h {m:02d}m" if h else f"{m}m"

    def _load(self):
        import http.client, json as _j
        try:
            conn = http.client.HTTPSConnection(self._sf_host, 443, timeout=8)
            import urllib.parse as _up
            conn.request("GET", f"/profile/{_up.quote(self._username)}")
            r = conn.getresponse()
            data = _j.loads(r.read())
            conn.close()
            self._pending_data = data
            from PyQt6.QtCore import QMetaObject, Qt as _Qt
            QMetaObject.invokeMethod(self, "_populate_slot",
                                     _Qt.ConnectionType.QueuedConnection)
        except Exception as e:
            self._pending_data = {"error": str(e)}
            from PyQt6.QtCore import QMetaObject, Qt as _Qt
            QMetaObject.invokeMethod(self, "_populate_slot",
                                     _Qt.ConnectionType.QueuedConnection)

    @pyqtSlot()
    def _populate_slot(self):
        data = getattr(self, "_pending_data", {})
        if "error" in data:
            self.lbl_summary.setText(f"Error: {data['error']}")
            return
        self._populate(data)

    def _populate(self, data):
        totals = data.get("totals", {})
        secs   = totals.get("total_secs", 0)
        frames = totals.get("total_frames") or totals.get("frames", 0)
        nights = totals.get("total_nights") or totals.get("nights", 0)
        self.lbl_summary.setText(
            f"⏱ {self._fmt(secs)} total  ·  "
            f"🌙 {nights} nights  ·  "
            f"📷 {frames} frames")

        # Monthly chart
        monthly = sorted(data.get("monthly", []), key=lambda x: x.get("month", ""))
        month_names = ["","Jan","Feb","Mar","Apr","May","Jun",
                       "Jul","Aug","Sep","Oct","Nov","Dec"]
        def mlbl(s):
            try: return month_names[int(s[5:7])]
            except: return s[2:]
        self.monthly_chart.set_data(
            [mlbl(m.get("month","")) for m in monthly],
            [m.get("total_secs", 0) / 3600.0 for m in monthly]
        )

        # Target list
        self._targets = data.get("targets", [])
        self.target_list.clear()
        for t in self._targets:
            exp = self._fmt(t.get("total_secs", 0))
            self.target_list.addItem(f"{t['target']}  ({exp})")
        if self._targets:
            self.target_list.setCurrentRow(0)

        # Telescopes tab
        scopes = data.get("scopes", [])
        self._populate_telescopes(scopes)

    def _populate_telescopes(self, scopes):
        # Clear existing
        while self.tel_container_l.count() > 1:
            item = self.tel_container_l.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._scope_note_editors = {}

        for s in scopes:
            sid   = s.get("id", "")
            name  = s.get("name", "Unknown")
            loc   = s.get("location", "")
            notes = s.get("notes", "")

            card = QWidget()
            card.setStyleSheet(
                "QWidget#scopeCard{background:rgba(10,20,50,180);"
                "border:1px solid #1a3060;border-radius:6px;}"
            )
            card.setObjectName("scopeCard")
            cl = QVBoxLayout(card)
            cl.setContentsMargins(10, 8, 10, 8)
            cl.setSpacing(4)

            # Scope name + location header
            hdr = QLabel(f"<b style='color:#8ab8e8;font-size:12px;'>🔭 {name}</b>"
                         + (f"  <span style='color:#3a6080;font-size:10px;'>📍 {loc}</span>" if loc else ""))
            hdr.setTextFormat(Qt.TextFormat.RichText)
            cl.addWidget(hdr)

            # Notes editor
            note_lbl = QLabel("Setup Notes:")
            note_lbl.setStyleSheet("color:#5080a0;font-size:10px;border:none;background:transparent;")
            cl.addWidget(note_lbl)

            editor = QTextEdit()
            editor.setPlainText(notes)
            editor.setMaximumHeight(120)
            editor.setMinimumHeight(60)
            editor.setStyleSheet(
                "QTextEdit{background:rgba(0,5,15,200);color:#a0c8e0;"
                "border:1px solid #1a2a40;border-radius:4px;font-size:10px;}"
            )
            if not self._is_own_profile:
                editor.setReadOnly(True)
                editor.setStyleSheet(
                    "QTextEdit{background:rgba(0,5,15,100);color:#7090a0;"
                    "border:1px solid #1a2040;border-radius:4px;font-size:10px;}"
                )
            cl.addWidget(editor)
            self._scope_note_editors[sid] = (editor, name)

            if self._is_own_profile:
                save_btn = QPushButton("💾  Save Notes")
                save_btn.setStyleSheet(
                    "background:#0d2040;color:#5090c0;border:1px solid #1a3060;"
                    "border-radius:3px;padding:3px 8px;font-size:10px;border:none;")
                save_btn.setFixedWidth(120)
                scope_id = sid
                def make_save(sid_, editor_):
                    def _save():
                        self._save_notes(sid_, editor_.toPlainText())
                    return _save
                save_btn.clicked.connect(make_save(sid, editor))
                cl.addWidget(save_btn)

            self.tel_container_l.insertWidget(self.tel_container_l.count() - 1, card)

    def _on_session_clicked(self, item):
        row = item.row()
        if not hasattr(self, '_current_sessions'): return
        if row < 0 or row >= len(self._current_sessions): return
        s = self._current_sessions[row]
        token = getattr(self, '_token', '')
        dlg = _SessionChartDialog(s, self._sf_host, token, self)
        dlg.exec()

    def _save_notes(self, scope_id, notes):
        import http.client, json as _j
        try:
            conn = http.client.HTTPSConnection(self._sf_host, 443, timeout=8)
            hdrs = {"Content-Type": "application/json"}
            # We need the auth token — passed from parent if available
            token = getattr(self, "_token", "")
            if token:
                hdrs["Authorization"] = f"Bearer {token}"
            body = _j.dumps({"notes": notes}).encode()
            conn.request("POST", f"/scopes/{scope_id}/notes", body, hdrs)
            r = conn.getresponse()
            r.read()
            conn.close()
        except Exception as e:
            print(f"[Notes] save error: {e}")

    def _on_target_selected(self, row):
        if row < 0 or row >= len(self._targets): return
        t = self._targets[row]
        total   = t.get("total_secs", 0)
        frames  = t.get("frames", 0)
        nights  = t.get("nights", 0)
        filters = t.get("filters", {})
        self.lbl_target_summary.setText(
            f"🔭 {t['target']}  ·  "
            f"⏱ {self._fmt(total)}  ·  "
            f"🌙 {nights} nights  ·  "
            f"📷 {frames} frames")

        # Filter bar chart
        if filters:
            items = sorted(filters.items(), key=lambda x: -x[1])
            labels = [f[0] for f in items]
            values = [f[1] / 3600.0 for f in items]
            # Pick colour from first filter
            color = self.FILTER_COLORS.get(labels[0].lower(), "#3a7fff")
            self.filter_chart.set_data(labels, values, color)
        else:
            self.filter_chart.set_data([], [])

        # Scope breakdown table
        self.scope_table.setRowCount(0)
        for sc in t.get("scopes", []):
            row = self.scope_table.rowCount()
            self.scope_table.insertRow(row)
            filts = ", ".join(sorted(sc.get("filters", {}).keys()))
            from PyQt6.QtCore import Qt as _Qt
            ni = QTableWidgetItem(sc["scope"])
            ei = QTableWidgetItem(self._fmt(sc["total_secs"]))
            fi = QTableWidgetItem(filts)
            ei.setTextAlignment(_Qt.AlignmentFlag.AlignCenter)
            self.scope_table.setItem(row, 0, ni)
            self.scope_table.setItem(row, 1, ei)
            self.scope_table.setItem(row, 2, fi)

        # Session table
        self.session_table.setRowCount(0)
        self._current_sessions = t.get("sessions", [])
        for s in self._current_sessions:
            r = self.session_table.rowCount()
            self.session_table.insertRow(r)
            from PyQt6.QtCore import Qt as _Qt
            di = QTableWidgetItem(str(s.get("date", "")))
            ei = QTableWidgetItem(self._fmt(s.get("total_secs", 0)))
            fi = QTableWidgetItem(str(s.get("frames", 0)))
            si = QTableWidgetItem(str(s.get("scope", "")))
            ei.setTextAlignment(_Qt.AlignmentFlag.AlignCenter)
            fi.setTextAlignment(_Qt.AlignmentFlag.AlignCenter)
            self.session_table.setItem(r, 0, di)
            self.session_table.setItem(r, 1, ei)
            self.session_table.setItem(r, 2, fi)
            self.session_table.setItem(r, 3, si)


def _compute_planet_positions():
    """Compute planet RA/Dec using proper Keplerian orbital elements (Meeus AA)."""
    import math, datetime
    jd = datetime.datetime.now(datetime.timezone.utc).timestamp() / 86400.0 + 2440587.5
    T  = (jd - 2451545.0) / 36525.0
    DEG = math.pi / 180.0

    def n(x): return x % 360.0
    def s(x): return math.sin(x * DEG)
    def c(x): return math.cos(x * DEG)

    # Earth heliocentric position
    M0e = n(357.5291092 + 35999.0502909*T)
    e0  = 0.016708634 - 0.000042037*T
    C0e = (1.9146-0.004817*T)*s(M0e) + (0.019993-0.000101*T)*s(2*M0e) + 0.00029*s(3*M0e)
    r0e = 1.000001018*(1-e0*e0)/(1+e0*c(M0e+C0e))
    O0e = n(100.4664568 + 35999.3728565*T + C0e)
    xe = r0e*c(O0e); ye = r0e*s(O0e)
    eps = (23.439291111 - 0.013004167*T) * DEG

    def planet_pos(L0, nL, a, e, i0, om0, Oa0, dnOa):
        L  = n(L0 + nL*T)
        i  = i0 * DEG
        om = n(om0) * DEG
        Oa = n(Oa0 + dnOa*T) * DEG
        M  = (L - om/DEG) % 360
        E  = M * DEG
        for _ in range(15):
            E -= (E - e*math.sin(E) - M*DEG) / (1 - e*math.cos(E))
        nu = 2*math.atan2(math.sqrt(1+e)*math.sin(E/2), math.sqrt(1-e)*math.cos(E/2))
        r  = a*(1-e*math.cos(E))
        xp = r*(math.cos(Oa)*math.cos(nu+om-Oa) - math.sin(Oa)*math.sin(nu+om-Oa)*math.cos(i))
        yp = r*(math.sin(Oa)*math.cos(nu+om-Oa) + math.cos(Oa)*math.sin(nu+om-Oa)*math.cos(i))
        zp = r*(math.sin(nu+om-Oa)*math.sin(i))
        xg = xp-xe; yg = yp-ye; zg = zp
        xeq = xg
        yeq = yg*math.cos(eps) - zg*math.sin(eps)
        zeq = yg*math.sin(eps) + zg*math.cos(eps)
        ra  = (math.atan2(yeq, xeq)/DEG + 360) % 360
        dec = math.atan2(zeq, math.sqrt(xeq**2+yeq**2)) / DEG
        return ra, dec

    # L0, nL(deg/century), a(AU), e, i(deg), om(lon peri), Oa(lon asc node), dnOa
    data = [
        ("Mercury","#b09070",3, 252.250906,149472.6746358,0.387098,0.205630,7.004979, 77.455863, 48.330893,1.1861368),
        ("Venus",  "#ffe8a0",5, 181.979801, 58517.8156760,0.723332,0.006772,3.394662,131.563703, 76.679920,0.9011190),
        ("Mars",   "#e05030",4, 355.433000, 19140.2993313,1.523679,0.093400,1.849691,336.060234, 49.558093,0.7720959),
        ("Jupiter","#e0c890",6,  34.351519,  3034.9056606,5.202603,0.048498,1.303267, 14.331168,100.464407,1.0209774),
        ("Saturn", "#d4b870",5,  50.077444,  1222.1138488,9.537070,0.055546,2.488879, 93.057237,113.665524,0.8770979),
        ("Uranus", "#80d0e0",4, 314.055005,   428.4669983,19.18916,0.046381,0.773196,173.005159, 74.005957,0.5211278),
        ("Neptune","#4060e0",4, 304.348665,   218.4862002,30.06992,0.009456,1.769952, 48.123691,131.784057,1.1022039),
    ]

    planets = []
    for name, color, size, L0, nL, a, e, i, om, Oa, dnOa in data:
        try:
            ra, dec = planet_pos(L0, nL, a, e, i, om, Oa, dnOa)
            planets.append({"name": name, "ra": ra, "dec": dec, "color": color, "size": size})
        except Exception:
            pass
    return planets



class MainWindow(QMainWindow):
    _ws_signal  = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"Rockwood Planetarium  |  {SITE_NAME}")
        self.resize(1400, 860)

        self._time_offset_sec = 0
        self._sf_token        = ""
        self._sf_host         = SF_SERVER
        self._sf_scopes       = {}
        self._sf_username     = ""
        self._scope_configs   = {}   # scope_id → {px_w, px_h, px_size_um, focal_mm, angle_deg}
        self._scope_images    = {}   # scope_id -> jpeg bytes
        self._sf_selected_id  = None
        self._target_ra       = None   # degrees
        self._target_dec      = None
        self._ws_running      = False
        self._ws_conn         = None

        self._ws_signal.connect(self._on_ws_state)
        self._build_ui()
        self.setStyleSheet(DARK_STYLE)
        self._load_saved_credentials()

        self._clock = QTimer(self)
        self._clock.timeout.connect(self._tick)
        self._clock.start(1000)
        self._tick()

        # Refresh scope alt/az readout every minute
        self._drift_timer = QTimer(self)
        self._drift_timer.timeout.connect(self._on_drift)
        self._drift_timer.start(60_000)

        # Re-push scope overlay every 2 seconds so moving scopes stay current
        self._scope_push_timer = QTimer(self)
        self._scope_push_timer.timeout.connect(self._push_scopes)
        self._scope_push_timer.start(2_000)

    def closeEvent(self, event):
        self._save_credentials()
        super().closeEvent(event)

    def _save_credentials(self):
        s = QSettings("RockwoodObservatory", "Planetarium")
        s.setValue("sf_username", self._sf_username)
        s.setValue("sf_token",    self._sf_token)
        # Save username field text (not password — never save passwords)
        s.setValue("sf_user_field", self.sf_user.text())

    def _load_saved_credentials(self):
        s = QSettings("RockwoodObservatory", "Planetarium")
        username  = s.value("sf_username",   "")
        token     = s.value("sf_token",      "")
        userfield = s.value("sf_user_field", "")
        if userfield:
            self.sf_user.setText(userfield)
        if username and token:
            # Validate the saved token is still valid
            self._sf_token    = token
            self._sf_username = username
            res, st = self._sf_api("GET", "/me/scopes")
            if st == 200:
                self.lbl_auth.setText(f"Logged in as {username}")
                self._sf_username = username
                self._load_nina_credentials()
                # Auto-connect to Starfront
                self._ws_connect()
            else:
                # Token expired — clear it, show username ready to re-login
                self._sf_token    = ""
                self._sf_username = ""
                self.lbl_auth.setText("Session expired — please log in again")

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(6)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        root.addWidget(splitter)

        # ── LEFT panel ────────────────────────────────────────────────────────
        left = QWidget()
        left.setMinimumWidth(260); left.setMaximumWidth(340)
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0,0,0,0); lv.setSpacing(8)
        splitter.addWidget(left)

        # --- site / time ---
        box_time = QGroupBox("SITE / TIME")
        bv = QVBoxLayout(box_time)
        lbl = QLabel(f"{SITE_NAME}  ·  {SITE_LAT}°N  {abs(SITE_LON):.1f}°W")
        lbl.setStyleSheet("color:#5070a0;font-size:10px;")
        bv.addWidget(lbl)
        self.lbl_time = QLabel("---- -- --  --:--:--")
        self.lbl_time.setStyleSheet("font-size:13px;color:#8ab0e0;letter-spacing:1px;")
        bv.addWidget(self.lbl_time)
        self.lbl_lst = QLabel("LST  --:--:--")
        self.lbl_lst.setStyleSheet("font-size:11px;color:#5070a0;")
        bv.addWidget(self.lbl_lst)

        sr = QHBoxLayout()
        sr.addWidget(QLabel("Step"))
        self.step_combo = QComboBox()
        self.step_combo.addItems(["1 min","5 min","15 min","1 hr",
                                  "3 hr","6 hr","12 hr","1 day","1 week"])
        self.step_combo.setCurrentIndex(3)
        sr.addWidget(self.step_combo)
        bv.addLayout(sr)

        br = QHBoxLayout()
        for txt, fn in [("◀◀", self._time_back), ("NOW", self._time_now), ("▶▶", self._time_fwd)]:
            b = QPushButton(txt); b.clicked.connect(fn); br.addWidget(b)
        bv.addLayout(br)
        self.lbl_offset = QLabel("")
        self.lbl_offset.setStyleSheet("color:#8060a0;font-size:10px;")
        bv.addWidget(self.lbl_offset)
        lv.addWidget(box_time)

        # --- view / survey ---
        box_view = QGroupBox("VIEW")
        vv = QVBoxLayout(box_view)

        svr = QHBoxLayout()
        svr.addWidget(QLabel("Survey"))
        self.survey_combo = QComboBox()
        self.survey_combo.addItems([
            "DSS2 Color", "DSS2 Red", "2MASS Color",
            "PanSTARRS DR1", "Fermi LAT", "WISE W1",
        ])
        self._survey_ids = [
            "CDS/P/DSS2/color",
            "CDS/P/DSS2/red",
            "CDS/P/2MASS/color",
            "CDS/P/PanSTARRS/DR1/color",
            "CDS/P/Fermi/color",
            "CDS/P/WISE/W1",
        ]
        self.survey_combo.currentIndexChanged.connect(self._on_survey_change)
        svr.addWidget(self.survey_combo)
        vv.addLayout(svr)

        self.btn_home = QPushButton("⌂  Rockwood Sky Now")
        self.btn_home.clicked.connect(self._goto_rockwood_now)
        vv.addWidget(self.btn_home)

        self.btn_goto_obj = QPushButton("Go to Selected Object")
        self.btn_goto_obj.setEnabled(False)
        self.btn_goto_obj.clicked.connect(self._goto_selected)
        vv.addWidget(self.btn_goto_obj)

        self.btn_reload = QPushButton("↺  Reload Aladin")
        self.btn_reload.setToolTip("Reload the sky view (use if image is black)")
        self.btn_reload.clicked.connect(self._reload_aladin)
        vv.addWidget(self.btn_reload)

        self.chk_meridian = QCheckBox("Show Meridian")
        self.chk_meridian.setChecked(False)
        self.chk_meridian.stateChanged.connect(self._on_meridian_change)
        vv.addWidget(self.chk_meridian)

        self.chk_grid = QCheckBox("Alt/Az Grid")
        self.chk_grid.setChecked(False)
        self.chk_grid.stateChanged.connect(self._on_grid_change)
        vv.addWidget(self.chk_grid)

        lv.addWidget(box_view)

        lv.addStretch()

        # ── CENTRE: Aladin WebView ─────────────────────────────────────────────
        # Create a dedicated profile so we can set cross-origin permissions
        # without affecting the default profile.
        from PyQt6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage
        self._web_profile = QWebEngineProfile("aladin", self)
        self._web_profile.setHttpCacheType(
            QWebEngineProfile.HttpCacheType.MemoryHttpCache)
        self._web_profile.setHttpCacheMaximumSize(128 * 1024 * 1024)

        # Enable the settings we need on the profile's default settings
        ps = self._web_profile.settings()
        ps.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
        ps.setAttribute(
            QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True)
        ps.setAttribute(
            QWebEngineSettings.WebAttribute.LocalStorageEnabled, True)
        ps.setAttribute(
            QWebEngineSettings.WebAttribute.AllowRunningInsecureContent, True)
        ps.setAttribute(
            QWebEngineSettings.WebAttribute.WebGLEnabled, True)

        # Build the page on our custom profile, then attach to the view
        self._web_page = QWebEnginePage(self._web_profile, self)
        self._web = QWebEngineView()
        self._web.setPage(self._web_page)
        self._web.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu)
        splitter.addWidget(self._web)
        self._cluster_zones = []
        self._chat_windows  = {}  # room_key -> QWidget panel
        self._zone_messages = {}  # zone_key -> list of (username, message, ts)

        # Pre-create 4 chat windows (one per possible hot zone)
        self._chat_wins = []
        for _i in range(4):
            _w = QWidget(self); _w.setObjectName("chatPanel")
            _w.setStyleSheet("QWidget#chatPanel{background:rgba(5,10,25,215);border:1px solid #1e3a6e;border-radius:8px;}")
            _w.resize(300,260); _w.move(300+_i*20, 100+_i*20); _w.setVisible(False)
            _wv = QVBoxLayout(_w); _wv.setContentsMargins(8,6,8,6); _wv.setSpacing(4)
            _wh = QHBoxLayout()
            _wl = QLabel(f"💬 Zone Chat"); _wl.setStyleSheet("color:#8ab0e0;font-size:11px;font-weight:bold;")
            _wx = QPushButton("✕"); _wx.setFixedSize(20,20)
            _wx.setStyleSheet("QPushButton{color:#a0b8d0;background:rgba(255,255,255,15);border:1px solid #2a4a6a;border-radius:4px;font-size:13px;font-weight:bold;}QPushButton:hover{color:#fff;background:rgba(180,60,60,180);border-color:#c44;}")
            _wx.clicked.connect(lambda chk=False, w=_w: w.setVisible(False))
            _wh.addWidget(_wl); _wh.addStretch(); _wh.addWidget(_wx)
            _wv.addLayout(_wh)
            _wlog = QTextEdit(); _wlog.setReadOnly(True)
            _wlog.setStyleSheet("QTextEdit{background:rgba(0,5,15,180);color:#c0d0e8;border:1px solid #1a2a40;border-radius:4px;font-size:11px;}")
            _wv.addWidget(_wlog)
            _wr = QHBoxLayout()
            _wi = QLineEdit(); _wi.setPlaceholderText("Message…")
            _wi.setStyleSheet("QLineEdit{background:rgba(10,20,40,200);color:#d0e0ff;border:1px solid #1e3a6e;border-radius:4px;padding:4px 6px;font-size:11px;}")
            _ws2 = QPushButton("Send"); _ws2.setStyleSheet("background:#1a3a6e;color:#8ab0e0;border:none;border-radius:4px;padding:4px 8px;font-size:11px;")
            _wr.addWidget(_wi); _wr.addWidget(_ws2)
            _wv.addLayout(_wr)
            _w._lbl = _wl; _w._log = _wlog; _w._inp = _wi
            _w._zone_ra = None; _w._zone_dec = None; _w._drag = [None]
            _w._idx = _i
            from functools import partial as _partial
            _wi.returnPressed.connect(_partial(self._send_chat_win, _i))
            _ws2.clicked.connect(lambda chk=False, _ii=_i: self._send_chat_win(_ii))
            _w.mousePressEvent = lambda e, w=_w: w._drag.__setitem__(0, e.globalPosition().toPoint()-w.frameGeometry().topLeft()) if e.button()==Qt.MouseButton.LeftButton else None
            _w.mouseMoveEvent = lambda e, w=_w: w.move(e.globalPosition().toPoint()-w._drag[0]) if w._drag[0] and e.buttons()==Qt.MouseButton.LeftButton else None
            _w.mouseReleaseEvent = lambda e, w=_w: w._drag.__setitem__(0, None)
            self._chat_wins.append(_w)
        self._chat_panel = None
        self._chat_windows = {}  # room_key -> win index

        # QWebChannel bridge
        self._bridge  = AladinBridge(self)
        self._channel = QWebChannel(self._web.page())
        self._channel.registerObject("pyBridge", self._bridge)
        self._web.page().setWebChannel(self._channel)
        self._bridge.object_clicked.connect(self._on_aladin_click)
        self._web.loadFinished.connect(self._on_load_finished)
        # Pipe JS console messages to Python stdout for debugging
        self._web.page().javaScriptConsoleMessage = self._js_console

        # Show spinner while Aladin CDN loads
        self._web.setHtml(_loading_html(), QUrl("about:blank"))

        # Write HTML to a temp file and load via file:// URL.
        # This is the most reliable approach on Windows — setHtml() with a
        # remote base URL has same-origin issues that block the CDN script.
        # The file:// URL lets the page load https:// scripts freely.
        now_utc = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
        ra_deg, dec_deg = rockwood_default_ra_dec(now_utc)
        self._aladin_url = _write_aladin_tmp(build_aladin_html(ra_deg, dec_deg))
        # Small delay so QWebChannel transport finishes handshake first
        QTimer.singleShot(400, lambda: self._web.load(QUrl(self._aladin_url)))

        # ── RIGHT panel ───────────────────────────────────────────────────────
        right_scroll = QScrollArea()
        right_scroll.setWidgetResizable(True)
        right_scroll.setMinimumWidth(220)
        right_scroll.setMaximumWidth(290)
        right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        right_scroll.setStyleSheet("QScrollArea { border:none; background:transparent; }")
        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(4,4,4,4); rv.setSpacing(8)
        right_scroll.setWidget(right)
        splitter.addWidget(right_scroll)

        # --- Compact account status + settings button ---
        acct_row = QHBoxLayout()
        acct_row.setSpacing(6)
        self.lbl_auth = QLabel("Not logged in")
        self.lbl_auth.setStyleSheet(
            "font-size:10px; color:#5070a0; padding:4px 6px;"
            "background:#050d20; border:1px solid #1a2a40; border-radius:3px;")
        self.lbl_auth.setWordWrap(False)
        acct_row.addWidget(self.lbl_auth, 1)
        _btn_style = (
            "QPushButton { background:#0d1e3a; color:#7ab0e0;"
            "border:1px solid #1a3060; border-radius:3px;"
            "font-size:11px; padding:4px 6px; }"
            "QPushButton:hover { background:#1a2e50; }"
            "QPushButton:pressed { background:#07111f; }")
        btn_settings = QPushButton("⚙")
        btn_settings.setFixedWidth(28)
        btn_settings.setToolTip("Settings")
        btn_settings.setStyleSheet(_btn_style)
        btn_settings.clicked.connect(self._open_settings)
        acct_row.addWidget(btn_settings)
        btn_my_profile_hdr = QPushButton("👤")
        btn_my_profile_hdr.setFixedWidth(28)
        btn_my_profile_hdr.setToolTip("My Profile")
        btn_my_profile_hdr.setStyleSheet(_btn_style)
        btn_my_profile_hdr.clicked.connect(self._open_my_profile)
        acct_row.addWidget(btn_my_profile_hdr)
        rv.addLayout(acct_row)

        # Hidden widgets kept for compatibility with rest of codebase
        self.sf_user    = QLineEdit(); self.sf_user.setVisible(False)
        self.sf_pass    = QLineEdit(); self.sf_pass.setVisible(False)
        self.sf_invite  = QLineEdit(); self.sf_invite.setVisible(False)
        self.box_nina   = QWidget();   self.box_nina.setVisible(False)
        self.my_scopes_table = QTableWidget(0, 2); self.my_scopes_table.setVisible(False)
        self.my_scopes_table.itemSelectionChanged.connect(self._my_scope_selection_changed)
        self.btn_rename_scope = QPushButton(); self.btn_rename_scope.setEnabled(False)
        self.btn_rename_scope.clicked.connect(self._rename_my_selected_scope)
        self.btn_del_my_scope = QPushButton(); self.btn_del_my_scope.setEnabled(False)
        self.btn_del_my_scope.clicked.connect(self._delete_my_selected_scope)
        self.nina_server    = QLineEdit(SF_SERVER); self.nina_server.setVisible(False)
        self.nina_apikey    = QLineEdit(); self.nina_apikey.setVisible(False)
        self.nina_scopeid   = QLineEdit(); self.nina_scopeid.setVisible(False)
        self._nina_scopes   = []
        self.nina_scope_combo = QComboBox()
        rv.addWidget(self.box_nina)

        # --- online scopes ---
        box_scopes = QGroupBox("ONLINE SCOPES")
        sv2 = QVBoxLayout(box_scopes)
        # Filter toggle
        filter_row = QHBoxLayout()
        self.chk_my_scopes = QCheckBox("My scopes only")
        self.chk_my_scopes.setChecked(False)
        self.chk_my_scopes.stateChanged.connect(self._rebuild_scopes_table)
        filter_row.addWidget(self.chk_my_scopes)
        filter_row.addStretch()
        sv2.addLayout(filter_row)

        self.scopes_table = QTableWidget(0, 2)
        self.scopes_table.setHorizontalHeaderLabels(["User / Scope", "Status"])
        self.scopes_table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeMode.Stretch)
        self.scopes_table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.ResizeMode.ResizeToContents)
        self.scopes_table.horizontalHeader().setStretchLastSection(False)
        self.scopes_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.scopes_table.setSelectionBehavior(
            QTableWidget.SelectionBehavior.SelectRows)
        self.scopes_table.setSelectionMode(
            QTableWidget.SelectionMode.SingleSelection)
        self.scopes_table.setShowGrid(False)
        self.scopes_table.setMinimumHeight(120)
        self.scopes_table.verticalHeader().setVisible(False)
        self.scopes_table.setWordWrap(False)
        self.scopes_table.itemClicked.connect(self._scope_item_clicked)
        self.scopes_table.itemDoubleClicked.connect(self._scope_item_double_clicked)

        self.scopes_table.setStyleSheet("""
            QTableWidget { background:#0d1520; alternate-background-color:#111d2e; }
            QTableWidget::item { padding:5px 8px; border-bottom:1px solid #1a2a40; }
            QTableWidget::item:selected { background:#1e3a6e; color:#e0eaff; border-left:3px solid #4a8af0; }
        """)
        self.scopes_table.setAlternatingRowColors(True)
        sv2.addWidget(self.scopes_table)

        self.btn_delete_scope = QPushButton()  # kept for compatibility, hidden
        self.btn_delete_scope.setVisible(False)

        # ── Scope action buttons ──────────────────────────────────────────────
        scope_btn_row = QHBoxLayout()
        scope_btn_row.setSpacing(6)

        self.btn_view_profile = QPushButton("👤  View Profile")
        self.btn_view_profile.setEnabled(False)
        self.btn_view_profile.setToolTip("View this user's imaging profile")
        self.btn_view_profile.setStyleSheet(
            "QPushButton { background:#0d1e3a; color:#7ab0e0; border:1px solid #1a3060;"
            "border-radius:3px; font-size:11px; padding:5px 8px; }"
            "QPushButton:hover:enabled { background:#1a2e50; }"
            "QPushButton:disabled { color:#2a4060; border-color:#0d1a30; }")
        self.btn_view_profile.clicked.connect(self._open_selected_profile)
        scope_btn_row.addWidget(self.btn_view_profile)

        self.btn_view_guiding = QPushButton("📈  Scope Status")
        self.btn_view_guiding.setEnabled(False)
        self.btn_view_guiding.setVisible(False)
        self.btn_view_guiding.setToolTip("View guiding graph and session stats")
        self.btn_view_guiding.setStyleSheet(
            "QPushButton { background:#0a1e10; color:#50e090; border:1px solid #1a5030;"
            "border-radius:3px; font-size:11px; padding:5px 8px; }"
            "QPushButton:hover:enabled { background:#0d2a18; }"
            "QPushButton:disabled { color:#1a4020; border-color:#0a2010; }")
        self.btn_view_guiding.clicked.connect(self._open_selected_guiding)
        scope_btn_row.addWidget(self.btn_view_guiding)

        sv2.addLayout(scope_btn_row)

        # Connect row: button + status dot
        nr = QHBoxLayout()
        self.btn_connect = QPushButton("Connect to Starfront")
        self.btn_connect.clicked.connect(self._ws_toggle)
        nr.addWidget(self.btn_connect)
        self.dot = QLabel()
        self.dot.setObjectName("dot")
        self.dot.setStyleSheet(
            "background:#c0392b;border-radius:5px;"
            "min-width:10px;max-width:10px;min-height:10px;max-height:10px;")
        nr.addWidget(self.dot)
        sv2.addLayout(nr)

        self.lbl_online = QLabel("● 0 online")
        self.lbl_online.setStyleSheet("font-size:10px; color:#2a4060; padding:2px 0;")
        self.lbl_online.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sv2.addWidget(self.lbl_online)

        # FOV button removed
        self.btn_cfg_fov = QPushButton("⚙ Configure Scope FOV")
        self.btn_cfg_fov.setVisible(False)
        self.btn_cfg_fov.setToolTip("")
        self.btn_cfg_fov.clicked.connect(self._configure_scope_fov)
        sv2.addWidget(self.btn_cfg_fov)
        rv.addWidget(box_scopes)

        # --- selected scope detail ---
        box_sd = QGroupBox("SELECTED SCOPE")
        sd = QVBoxLayout(box_sd)
        self.lbl_scope_ra     = QLabel("RA  —")
        self.lbl_scope_dec    = QLabel("Dec —")
        self.lbl_scope_altaz  = QLabel("Alt —   Az —")
        self.lbl_scope_status = QLabel("—")
        self.lbl_scope_ra.setStyleSheet("font-size:12px;color:#8ab0e0;")
        self.lbl_scope_dec.setStyleSheet("font-size:12px;color:#8ab0e0;")
        self.lbl_scope_altaz.setStyleSheet("font-size:10px;color:#5070a0;")
        self.lbl_scope_status.setStyleSheet("font-size:10px;color:#6040a0;")
        for w in (self.lbl_scope_ra, self.lbl_scope_dec,
                  self.lbl_scope_altaz, self.lbl_scope_status):
            sd.addWidget(w)
        self.lbl_last_frame = QLabel("No image")
        self.lbl_last_frame.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_last_frame.setStyleSheet(
            "color:#304060;font-size:10px;background:#050810;"
            "border:1px solid #1a2840;border-radius:3px;min-height:160px;")
        sd.addWidget(self.lbl_last_frame)
        rv.addWidget(box_sd)




        # ── Community / Stats tab ─────────────────────────────────────────────
        # ── Community section — activity feed + leaderboard button ─────────────
        box_community = QGroupBox("COMMUNITY")
        cv = QVBoxLayout(box_community)

        # My stats card
        self.lbl_my_stats = QLabel("Log in to see your stats")
        self.lbl_my_stats.setStyleSheet(
            "background:rgba(10,20,50,180);color:#7ab0e0;font-size:10px;"
            "padding:6px 8px;border-radius:4px;border:1px solid #1a3060;")
        self.lbl_my_stats.setWordWrap(True)
        cv.addWidget(self.lbl_my_stats)

        # Leaderboard button
        btn_lb = QPushButton("🏆  Leaderboard")
        btn_lb.setStyleSheet(
            "QPushButton { background:#1a1400; color:#f0c040;"
            "border:1px solid #504010; border-radius:4px;"
            "font-size:12px; font-weight:bold; padding:7px 12px; }"
            "QPushButton:hover { background:#2a2000; border-color:#806020; }"
            "QPushButton:pressed { background:#0a0800; }")
        btn_lb.clicked.connect(self._open_leaderboard)
        cv.addWidget(btn_lb)

        # Activity feed
        cv.addWidget(QLabel("📡  Recent Activity"))
        self.feed_log = QTextEdit()
        self.feed_log.setReadOnly(True)
        self.feed_log.setMaximumHeight(200)
        self.feed_log.setMinimumHeight(100)
        self.feed_log.setStyleSheet(
            "QTextEdit{background:rgba(0,5,15,180);color:#8ab8e0;"
            "border:1px solid #1a2a40;border-radius:4px;font-size:10px;}")
        cv.addWidget(self.feed_log)

        # Hidden stubs so existing leaderboard signal handlers still work
        self._lb_period   = "alltime"
        self._lb_category = "exposure"
        self._lb_cat_btns = {}
        self.community_table = QTableWidget(0, 3)
        self.community_table.setVisible(False)
        self.btn_lb_alltime = QPushButton(); self.btn_lb_alltime.setVisible(False)
        self.btn_lb_month   = QPushButton(); self.btn_lb_month.setVisible(False)

        lv.addWidget(box_community)
        self._community_timer = QTimer(self)
        self._community_timer.timeout.connect(self._load_community_stats)
        self._community_timer.start(60_000)
        # Planet/comet update timer
        self._planet_timer = QTimer(self)
        self._planet_timer.timeout.connect(self._push_planets)
        self._planet_timer.start(60_000)
        QTimer.singleShot(2000, self._push_planets)
        # ── Observatory Live Button ───────────────────────────────────────────
        btn_obs = QPushButton("📡  Observatory Live Now")
        btn_obs.setStyleSheet(
            "QPushButton { background:#0a1e10; color:#50e090;"
            "border:1px solid #1a5030; border-radius:4px;"
            "font-size:12px; font-weight:bold; padding:8px 12px; }"
            "QPushButton:hover { background:#0d2a18; border-color:#2a7050; }"
            "QPushButton:pressed { background:#061208; }")
        btn_obs.clicked.connect(self._open_observatory)
        rv.addWidget(btn_obs)

        # Hidden stubs kept for compatibility with camera fetch methods
        self.lbl_cam_allsky  = QLabel(); self.lbl_cam_allsky.setVisible(False)
        self.lbl_cam_bldg    = QLabel(); self.lbl_cam_bldg.setVisible(False)
        self.lbl_cam_updated = QLabel(); self.lbl_cam_updated.setVisible(False)
        self.cam_bldg_combo  = QComboBox()
        for name in CAM_BUILDINGS:
            self.cam_bldg_combo.addItem(name)
        self.cam_bldg_combo.setVisible(False)

        # Camera refresh timer — keep running so window gets fresh data when opened
        self._cam_timer = QTimer(self)
        self._cam_timer.timeout.connect(self._refresh_cameras)
        self._cam_timer.start(CAM_REFRESH_SECS * 1000)

        # ── General Chat ──────────────────────────────────────────────────────
        box_chat = QGroupBox("GENERAL CHAT")
        box_chat.setStyleSheet(
            "QGroupBox { font-size:10px; color:#5a8ab0; border:1px solid #1a3060;"
            "border-radius:4px; margin-top:6px; padding-top:4px; }"
            "QGroupBox::title { subcontrol-origin:margin; left:8px; padding:0 4px; }")
        chat_v = QVBoxLayout(box_chat)
        chat_v.setSpacing(4)
        chat_v.setContentsMargins(6, 6, 6, 6)

        self.general_chat_log = QTextEdit()
        self.general_chat_log.setReadOnly(True)
        self.general_chat_log.setMinimumHeight(120)
        self.general_chat_log.setMaximumHeight(200)
        self.general_chat_log.setStyleSheet(
            "QTextEdit { background:#020810; color:#8ab8e0;"
            "border:1px solid #1a2a40; border-radius:3px; font-size:10px;"
            "font-family:'Courier New'; }")
        chat_v.addWidget(self.general_chat_log)

        chat_input_row = QHBoxLayout()
        chat_input_row.setSpacing(4)
        self.general_chat_input = QLineEdit()
        self.general_chat_input.setPlaceholderText("Message everyone…")
        self.general_chat_input.setMaxLength(500)
        self.general_chat_input.setStyleSheet(
            "QLineEdit { background:#050d20; color:#c0d8f0;"
            "border:1px solid #1a3060; border-radius:3px;"
            "padding:4px 8px; font-size:11px; font-family:'Courier New'; }"
            "QLineEdit:focus { border:1px solid #3a7fff; }")
        self.general_chat_input.returnPressed.connect(self._send_general_chat)
        chat_input_row.addWidget(self.general_chat_input, 1)

        btn_chat_send = QPushButton("Send")
        btn_chat_send.setFixedWidth(52)
        btn_chat_send.setStyleSheet(
            "QPushButton { background:#1a3a7a; color:#8ab8ff;"
            "border:1px solid #2a5abf; border-radius:3px;"
            "font-size:11px; padding:4px 8px; }"
            "QPushButton:hover { background:#2a4a9a; }"
            "QPushButton:pressed { background:#0d2050; }")
        btn_chat_send.clicked.connect(self._send_general_chat)
        chat_input_row.addWidget(btn_chat_send)
        chat_v.addLayout(chat_input_row)

        rv.addWidget(box_chat)
        rv.addStretch()

        splitter.setSizes([240, 900, 280])

        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage(
            f"Rockwood Planetarium  |  {SITE_NAME}  "
            f"|  lat {SITE_LAT}°N  lon {abs(SITE_LON):.1f}°W  "
            f"|  Aladin Lite v3 / CDS Strasbourg")

    # ── clock ─────────────────────────────────────────────────────────────────

    def _now_sim(self) -> datetime.datetime:
        return (datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
                + datetime.timedelta(seconds=self._time_offset_sec))

    def _tick(self):
        now_utc = self._now_sim()
        now_cdt = now_utc + datetime.timedelta(hours=-5)
        lst = lst_deg(now_utc, SITE_LON)
        lh = int(lst/15); lm = int((lst/15-lh)*60)
        ls = int(((lst/15-lh)*60-lm)*60)
        lst_str = f"{lh:02d}:{lm:02d}:{ls:02d}"
        self.lbl_time.setText(now_cdt.strftime("%Y-%m-%d  %H:%M:%S CDT"))
        self.lbl_lst.setText(f"LST  {lst_str}")
        # Wrap everything in a try/catch so errors during page transitions are silent
        self._js(
            f"try{{"
            f"  if(typeof updateHUD==='function') updateHUD('{lst_str}');"
            f"  if(typeof setLST==='function')    setLST({lst:.6f});"
            f"}} catch(e) {{}}"
        )

    def _on_drift(self):
        if self._sf_selected_id:
            self._refresh_scope_detail(self._sf_selected_id)

    def _step_secs(self) -> int:
        return {"1 min":60,"5 min":300,"15 min":900,"1 hr":3600,
                "3 hr":10800,"6 hr":21600,"12 hr":43200,
                "1 day":86400,"1 week":604800}.get(
            self.step_combo.currentText(), 3600)

    def _time_fwd(self):
        self._time_offset_sec += self._step_secs()
        self._update_offset_label(); self._tick()

    def _time_back(self):
        self._time_offset_sec -= self._step_secs()
        self._update_offset_label(); self._tick()

    def _time_now(self):
        self._time_offset_sec = 0
        self._update_offset_label(); self._tick()

    def _update_offset_label(self):
        off = self._time_offset_sec
        if off == 0: self.lbl_offset.setText(""); return
        sg = "+" if off > 0 else "-"; off = abs(off)
        if   off < 3600:  t = f"{sg}{off//60}m offset"
        elif off < 86400: t = f"{sg}{off//3600}h{(off%3600)//60:02d}m offset"
        else:             t = f"{sg}{off//86400}d{(off%86400)//3600:02d}h offset"
        self.lbl_offset.setText(t)

    # ── Aladin helpers ────────────────────────────────────────────────────────

    def _js(self, script: str):
        self._web.page().runJavaScript(script)

    def _js_console(self, level, msg, line, source):
        """Forward JS console messages to Python stdout."""
        lvl = {0: "DBG", 1: "INF", 2: "WRN", 3: "ERR"}.get(level, "???")
        print(f"[JS {lvl} {source}:{line}] {msg}")

    def _on_load_finished(self, ok: bool):
        """Called when the WebEngine finishes loading the Aladin page."""
        if ok:
            # Page loaded — push current scope state in case WS already connected
            self._push_scopes()
            self.status_bar.showMessage(
                f"Rockwood Planetarium  |  {SITE_NAME}  "
                f"|  Aladin Lite ready — lat {SITE_LAT}°N  lon {abs(SITE_LON):.1f}°W")
        else:
            # Load failed — show error message in the web view
            self._web.setHtml(
                "<body style='background:#0a0c18;color:#e05050;"
                "font:14px Courier New;padding:40px'>"
                "<b>Aladin failed to load.</b><br><br>"
                "Check your internet connection — the app needs to reach "
                "<code>aladin.cds.unistra.fr</code> for the sky imagery.<br><br>"
                "<small style='color:#506080'>Tip: try the Reload button.</small>"
                "</body>",
                QUrl("about:blank"))
            self.status_bar.showMessage("⚠ Aladin load failed — check internet connection")

    def _reload_aladin(self):
        """Regenerate and reload the Aladin page."""
        global _local_html_content
        now_utc = self._now_sim()
        ra_deg, dec_deg = rockwood_default_ra_dec(now_utc)
        html = build_aladin_html(ra_deg, dec_deg)
        # Update what the local HTTP server serves, then trigger a reload
        _local_html_content = html.encode("utf-8")
        if hasattr(self, '_aladin_url') and self._aladin_url:
            self._web.reload()
        else:
            self._aladin_url = _write_aladin_tmp(html)
            self._web.load(QUrl(self._aladin_url))

    def _on_meridian_change(self, state):
        v = 'true' if state else 'false'
        self._js(f"if(typeof setShowMeridian!='undefined') setShowMeridian({v})")

    def _on_grid_change(self, state):
        v = 'true' if state else 'false'
        self._js(f"if(typeof setShowGrid!='undefined') setShowGrid({v})")

    def _goto_rockwood_now(self):
        ra, dec = rockwood_default_ra_dec(self._now_sim())
        self._js(f"if(aladin) gotoTarget({ra:.4f}, {dec:.4f}, 120)")

    def _goto_selected(self):
        if self._target_ra is not None:
            self._js(f"if(aladin) gotoTarget({self._target_ra:.4f}, "
                     f"{self._target_dec:.4f}, 1)")

    def _on_survey_change(self, idx: int):
        sid = self._survey_ids[idx]
        self._js(f"if(aladin) setSurvey('{sid}')")

    def _on_aladin_click(self, name: str, ra: float, dec: float):
        self._target_ra  = ra
        self._target_dec = dec
        ra_h = ra / 15.0
        lst  = lst_deg(self._now_sim(), SITE_LON)
        alt, az = ra_dec_to_alt_az(ra_h, dec, lst, SITE_LAT)
        self.btn_goto_obj.setEnabled(True)
        self.status_bar.showMessage(
            f"{name}  |  RA {ra_h:.3f}h  Dec {dec:+.2f}°  "
            f"|  Alt {alt:.1f}°  Az {az:.1f}°")

    def _comet_clicked(self, row, _col):
        c = COMET_CATALOG[row]
        ra_deg = ra_h_to_deg(c.ra_h)
        self._js(f"if(aladin) gotoTarget({ra_deg:.4f}, {c.dec_deg:.4f}, 5)")
        self._on_aladin_click(f"☄ {c.designation}  ({c.name})", ra_deg, c.dec_deg)

    # ── scope overlay ─────────────────────────────────────────────────────────

    def _push_scopes(self):
        payload = {}
        for sid, s in self._sf_scopes.items():
            ra_raw  = s.get("ra")
            dec_raw = s.get("dec")
            # Skip if no position
            if ra_raw is None or dec_raw is None:
                continue
            # Skip if explicitly marked offline
            if s.get("online") is False:
                continue
            # Coerce to float — server may send strings or None
            try:
                ra_deg = float(ra_raw)
                dec    = float(dec_raw)
            except (TypeError, ValueError):
                print(f"[Push] skipping {sid}: non-numeric ra={ra_raw!r} dec={dec_raw!r}")
                continue
            is_sel = (sid == self._sf_selected_id)
            # Build label: "username / scope_name"
            username   = s.get("username") or ""
            scope_name = s.get("name")     or ""
            if username and scope_name and username.lower() != scope_name.lower():
                label = f"{username} / {scope_name}"
            elif username:
                label = username
            elif scope_name:
                label = scope_name
            else:
                label = sid[:8]
            # Server sends RA in HOURS — Aladin world2pix needs degrees
            entry = {
                "ra":       ra_deg * 15.0,
                "dec":      dec,
                "name":     label,
                "username": username,
                "color":    "#ff5050" if is_sel else _scope_color(sid),
                "mine":     is_sel,
            }
            # Compute FOV from local config if available
            cfg = self._scope_configs.get(sid)
            if cfg:
                try:
                    fw = cfg["px_w"] * cfg["px_um"] / 1000.0   # sensor width mm
                    fh = cfg["px_h"] * cfg["px_um"] / 1000.0   # sensor height mm
                    fl = cfg["focal"]
                    entry["fov_w"] = math.degrees(2 * math.atan(fw / (2 * fl)))
                    entry["fov_h"] = math.degrees(2 * math.atan(fh / (2 * fl)))
                    entry["rotation"] = cfg["angle"]
                except Exception:
                    pass
            payload[sid] = entry
        if payload and self.__dict__.get("_push_count", 0) % 30 == 0:
            print(f"[Push] {len(payload)} scopes")
        self._push_count = self.__dict__.get("_push_count", 0) + 1
        js_payload = json.dumps(json.dumps(payload))
        self._js(f"if(typeof updateScopes!='undefined') updateScopes({js_payload})")

    def _receive_scope_image(self, sid, jpeg_b64):
        import base64
        try:
            data = base64.b64decode(jpeg_b64)
            self._scope_images[sid] = data
            if sid == self._sf_selected_id:
                self._show_scope_image(sid)
            # Push to open scope detail window if it exists for this scope
            wins = getattr(self, "_scope_detail_wins", {})
            if sid in wins and wins[sid].isVisible():
                wins[sid].update_image(data)
        except Exception as e:
            print(f'[Image] decode error: {e}')

    def _show_scope_image(self, sid):
        data = self._scope_images.get(sid)
        if not data:
            self.lbl_last_frame.setPixmap(QPixmap())
            self.lbl_last_frame.setText('No image')
            return
        pm = QPixmap()
        pm.loadFromData(data)
        if pm.isNull():
            self.lbl_last_frame.setText('Invalid image'); return
        w = self.lbl_last_frame.width() or 230
        h = self.lbl_last_frame.height() or 160
        scaled = pm.scaled(w, h,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation)
        self.lbl_last_frame.setPixmap(scaled)
        self.lbl_last_frame.setText('')

    def _refresh_scope_detail(self, sid: str):

        s = self._sf_scopes.get(sid, {})
        ra_raw = s.get("ra"); dec_raw = s.get("dec")
        if ra_raw is None or dec_raw is None:
            return

        # Guard: coerce to float (server may send strings)
        try:
            ra_raw  = float(ra_raw)
            dec_raw = float(dec_raw)
        except (TypeError, ValueError):
            print(f"[Scope] non-numeric ra/dec: ra={ra_raw!r} dec={dec_raw!r}")
            return


        # Server sends RA in HOURS — use directly for display and alt/az calc
        ra_h = ra_raw
        dec  = dec_raw

        lst = lst_deg(self._now_sim(), SITE_LON)
        alt, az = ra_dec_to_alt_az(ra_h, dec, lst, SITE_LAT)

        rh = int(ra_h); rm = int((ra_h-rh)*60); rs = (ra_h-rh-rm/60)*3600
        ds = "+" if dec >= 0 else "-"; ad = abs(dec)
        dd = int(ad); dm = int((ad-dd)*60); dsc = (ad-dd-dm/60)*3600

        self.lbl_scope_ra.setText(f"RA  {rh:02d}h {rm:02d}m {rs:04.1f}s")
        self.lbl_scope_dec.setText(f"Dec {ds}{dd:02d}° {dm:02d}′ {dsc:04.1f}″")
        self.lbl_scope_altaz.setText(f"Alt {alt:+.2f}°   Az {az:.2f}°")
        self.lbl_scope_status.setText(
            "Slewing…" if s.get("slewing") else
            "Tracking" if s.get("tracking") else
            "Parked"   if s.get("parked")   else "Idle")

    def _update_scopes_table_status(self):
        """Update only the status column in place — no row rebuild, no selection disruption."""
        for row in range(self.scopes_table.rowCount()):
            name_item = self.scopes_table.item(row, 0)
            if not name_item: continue
            sid = name_item.data(32)
            if not sid: continue
            s = self._sf_scopes.get(sid, {})
            status_str = ("Slewing"  if s.get("slewing")  else
                          "Tracking" if s.get("tracking") else
                          "Parked"   if s.get("parked")   else "Idle")
            status_item = self.scopes_table.item(row, 1)
            if status_item:
                status_item.setText(status_str)
        self._push_scopes()

    def _update_online_count(self):
        scopes = self._sf_scopes
        n_scopes = len(scopes)
        n_users  = len(set(s.get("username","") for s in scopes.values() if s.get("username")))
        if n_scopes == 0:
            self.lbl_online.setText("● 0 online")
            self.lbl_online.setStyleSheet("font-size:10px; color:#2a4060; padding:2px 0;")
        else:
            scope_str = f"{n_scopes} scope{'s' if n_scopes != 1 else ''}"
            user_str  = f"{n_users} user{'s' if n_users != 1 else ''}"
            self.lbl_online.setText(f"● {user_str}  ·  {scope_str} online")
            self.lbl_online.setStyleSheet("font-size:10px; color:#50e090; padding:2px 0;")

    def _rebuild_scopes_table(self):
        self.scopes_table.setRowCount(0)
        my_only = self.chk_my_scopes.isChecked()
        for sid, s in self._sf_scopes.items():
            if my_only and s.get("username","").lower() != self._sf_username.lower():
                continue
            # Show scope if explicitly online, OR if it has a position
            # (servers vary on whether they send an "online" flag)
            has_pos = s.get("ra") is not None and s.get("dec") is not None
            if s.get("online") is False and not has_pos:
                continue
            r = self.scopes_table.rowCount()
            self.scopes_table.insertRow(r)
            username   = s.get("username") or ""
            scope_name = s.get("name")     or ""
            if username and scope_name and username.lower() != scope_name.lower():
                display_name = f"{username} / {scope_name}"
            elif username:
                display_name = username
            else:
                display_name = scope_name or sid[:8]
            from PyQt6.QtGui import QBrush
            item = QTableWidgetItem(display_name)
            item.setData(32, sid)   # store scope ID for click handler
            item.setToolTip(display_name)  # show full name on hover
            item.setForeground(QBrush(QColor(_scope_color(sid))))
            self.scopes_table.setItem(r, 0, item)
            status_str = ("Slewing"  if s.get("slewing")  else
                          "Tracking" if s.get("tracking") else
                          "Parked"   if s.get("parked")   else "Idle")
            status_item = QTableWidgetItem(status_str)
            status_item.setData(32, sid)  # also store on status cell
            self.scopes_table.setItem(r, 1, status_item)
        # Re-select previously selected row and highlight it
        for row in range(self.scopes_table.rowCount()):
            item = self.scopes_table.item(row, 0)
            if item and item.data(32) == self._sf_selected_id:
                self.scopes_table.selectRow(row)
                break

        self._push_scopes()

        self._update_online_count()
    def _delete_selected_scope(self):
        sid = self._sf_selected_id
        if not sid:
            return
        if not self._sf_token:
            QMessageBox.warning(self, "Not logged in", "Log in first to delete scopes.")
            return
        s = self._sf_scopes.get(sid, {})
        name = s.get("name") or s.get("username") or sid[:8]
        reply = QMessageBox.question(self, "Remove Scope",
            f"Remove '{name}' from the server?\nThis deletes it permanently.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return
        import http.client as _hc, json as _json
        conn = _hc.HTTPConnection(self._sf_host, 8088, timeout=8)
        hdrs = {"Content-Type": "application/json",
                "Authorization": f"Bearer {self._sf_token}"}
        try:
            conn.request("DELETE", f"/scopes/{sid}", b"", hdrs)
            r = conn.getresponse()
            res = _json.loads(r.read())
            if r.status == 200:
                self._sf_selected_id = None
                self.btn_delete_scope.setEnabled(False)
                self._sf_scopes.pop(sid, None)
                self._rebuild_scopes_table()
                self._load_nina_credentials()
                QMessageBox.information(self, "Deleted", f"'{name}' removed.")
            else:
                QMessageBox.warning(self, "Error", res.get("error", f"Server returned {r.status}"))
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))
        finally:
            conn.close()

    def _configure_scope_fov(self):
        """Open FOV config window for the selected scope."""
        sid = self._sf_selected_id
        if not sid:
            QMessageBox.information(self, "No scope selected",
                                    "Select a scope from the table first.")
            return
        s    = self._sf_scopes.get(sid, {})
        name = s.get("name") or s.get("username") or sid
        cfg  = self._scope_configs.get(sid, {})
        win  = ScopeFOVWindow(name, cfg, self)
        win.saved.connect(lambda c: self._on_fov_saved(sid, c))
        win.show()

    def _on_fov_saved(self, sid, cfg):
        self._scope_configs[sid] = cfg
        self._push_scopes()


    def _open_selected_profile(self):
        sid = getattr(self, "_sf_selected_id", None)
        if not sid: return
        s = self._sf_scopes.get(sid, {})
        username = s.get("username", "")
        if not username: return
        if getattr(self, "_profile_open", False): return
        self._profile_open = True
        dlg = UserProfileDialog(username, self._sf_host, self, token=self._sf_token)
        dlg.finished.connect(lambda: setattr(self, "_profile_open", False))
        dlg.show()

    def _open_selected_guiding(self):
        sid = getattr(self, "_sf_selected_id", None)
        if not sid: return
        s = self._sf_scopes.get(sid, {})
        existing = getattr(self, "_scope_detail_wins", {})
        if sid in existing and existing[sid].isVisible():
            existing[sid].raise_()
            existing[sid].activateWindow()
            return
        # Find most recent session for this scope
        session = None
        sessions = getattr(self, "_my_sessions", [])
        for sess in reversed(sessions):
            if sess.get("scope_id") == sid or sess.get("scope_name") == s.get("scope_name"):
                session = sess
                break
        # Pass last image bytes if available
        last_image = self._scope_images.get(sid)
        win = _ScopeDetailWindow(s, session, self._sf_host, self._sf_token, self,
                                 last_image=last_image)
        if not hasattr(self, "_scope_detail_wins"):
            self._scope_detail_wins = {}
        self._scope_detail_wins[sid] = win
        # Keep window updated when new images arrive for this scope
        self._scope_detail_wins[sid]._sid = sid
        win.show()

    def _scope_context_menu(self, pos):
        from PyQt6.QtWidgets import QMenu
        item = self.scopes_table.itemAt(pos)
        if not item: return
        sid = item.data(32)
        if not sid: return
        s = self._sf_scopes.get(sid, {})
        username = s.get("username", "")
        scope_username = username
        is_my_scope = (scope_username.lower() == self._sf_username.lower()) if self._sf_username else False

        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu { background:#0d1520; color:#7ab0e0; border:1px solid #1a3060; font-size:11px; }"
            "QMenu::item:selected { background:#1a3060; }")

        act_profile = menu.addAction("👤  View Profile")
        act_guiding = None
        if is_my_scope:
            act_guiding = menu.addAction("📈  View Guiding & Stats")

        action = menu.exec(self.scopes_table.viewport().mapToGlobal(pos))
        if action == act_profile:
            if not username: return
            if getattr(self, "_profile_open", False): return
            self._profile_open = True
            dlg = UserProfileDialog(username, self._sf_host, self, token=self._sf_token)
            dlg.finished.connect(lambda: setattr(self, "_profile_open", False))
            dlg.show()
        elif act_guiding and action == act_guiding:
            existing = getattr(self, "_scope_detail_wins", {})
            if sid in existing and existing[sid].isVisible():
                existing[sid].raise_()
                existing[sid].activateWindow()
                return
            session = None
            sessions = getattr(self, "_my_sessions", [])
            for sess in reversed(sessions):
                if sess.get("scope_id") == sid or sess.get("scope_name") == s.get("scope_name"):
                    session = sess
                    break
            win = _ScopeDetailWindow(s, session, self._sf_host, self._sf_token, self)
            if not hasattr(self, "_scope_detail_wins"):
                self._scope_detail_wins = {}
            self._scope_detail_wins[sid] = win
            win.show()

    def _scope_item_double_clicked(self, item):
        # Double-click now handled by context menu — just slew to scope
        pass

    def _scope_item_clicked(self, item):
        if not item: return
        sid = item.data(32)
        if not sid: return
        self._sf_selected_id = sid
        self.btn_delete_scope.setEnabled(True)
        self.btn_view_profile.setEnabled(True)
        s_for_btn = self._sf_scopes.get(sid, {})
        self.btn_view_guiding.setVisible(True)
        self.btn_view_guiding.setEnabled(True)
        self._refresh_scope_detail(sid)
        self._push_scopes()
        self._js(f"if(typeof flashScope!='undefined') flashScope('{sid}')")
        self._show_scope_image(sid)
        s = self._sf_scopes.get(sid, {})
        if s.get("ra") is not None:
            ra_deg = float(s["ra"]) * 15.0
            self._js(f"if(aladin) gotoTarget({ra_deg:.4f}, {float(s['dec']):.4f}, 2)")



    # ── Starfront HTTP ────────────────────────────────────────────────────────

    def _sf_api(self, method, path, body=None, token=""):
        conn = http.client.HTTPSConnection(self._sf_host, 443, timeout=8)
        hdrs = {"Content-Type":"application/json"}
        t = token or self._sf_token
        if t: hdrs["Authorization"] = f"Bearer {t}"
        data = json.dumps(body).encode() if body else b""
        try:
            conn.request(method, path, data, hdrs)
            r = conn.getresponse()
            return json.loads(r.read()), r.status
        except Exception as e:
            return {"error": str(e)}, 0
        finally:
            conn.close()

    def _sf_register(self):
        u      = self.sf_user.text().strip()
        pw     = self.sf_pass.text().strip()
        invite = self.sf_invite.text().strip()
        if not u or not pw:
            self.lbl_auth.setText("Enter username and password"); return
        if not invite:
            self.lbl_auth.setText("Enter your invite code"); return
        res, st = self._sf_api("POST", "/register",
                               {"username": u, "password": pw, "invite_code": invite})
        if st == 201:
            self.lbl_auth.setText("Account created — log in")
            self.sf_invite.clear()
        else:
            self.lbl_auth.setText(res.get("error", "Registration failed"))



    def _join_general_chat_room(self):
        import json as _j, asyncio
        loop = getattr(self, "_ws_event_loop", None)
        conn = self._ws_conn
        if loop and loop.is_running() and conn:
            try:
                payload = _j.dumps({"_event": "join_room", "room_id": "general"})
                asyncio.run_coroutine_threadsafe(conn.send(payload), loop)
                print("[Chat] joined general room")
            except Exception as e:
                print(f"[Chat] general room join error: {e}")

    def _rejoin_chat_rooms(self):
        """Re-send join_room for all visible chat windows after reconnect."""
        import json as _j, asyncio as _aio, threading as _th
        loop = getattr(self, "_ws_event_loop", None)
        conn = self._ws_conn
        if not (loop and loop.is_running() and conn): return
        for wi in self._chat_windows.values():
            win = self._chat_wins[wi]
            if not win.isVisible(): continue
            room_id = getattr(win, "_room_id", "")
            if not room_id: continue
            pay = _j.dumps({"_event": "join_room", "room_id": room_id})
            print(f"[Chat] re-joining room {room_id} after reconnect")
            def _send(p=pay): _aio.run_coroutine_threadsafe(conn.send(p), loop)
            _th.Thread(target=_send, daemon=True).start()

    def _on_join_chat(self, zone_idx=0):
        try:
            self._on_join_chat_impl(zone_idx)
        except Exception as e:
            import traceback; traceback.print_exc()

    def _on_join_chat_impl(self, zone_idx=0):
        if not self._cluster_zones or zone_idx >= len(self._cluster_zones): return
        if zone_idx >= len(self._chat_wins): return
        z = self._cluster_zones[zone_idx]
        room_key = f"zone_{round(z.get('ra',0))}_{round(z.get('dec',0))}"
        if room_key not in self._chat_windows:
            used = set(self._chat_windows.values())
            for i in range(len(self._chat_wins)):
                if i not in used:
                    self._chat_windows[room_key] = i; break
            else:
                self._chat_windows[room_key] = zone_idx % len(self._chat_wins)
        wi = self._chat_windows[room_key]
        win = self._chat_wins[wi]
        win._zone_ra = z.get("ra"); win._zone_dec = z.get("dec")
        ra_h = z.get("ra",0)/15.0
        rah = int(ra_h); ram = int((ra_h-rah)*60); ras = int(((ra_h-rah)*60-ram)*60)
        dec = z.get("dec",0); dsign = "+" if dec >= 0 else "-"; adec = abs(dec)
        dd = int(adec); dm = int((adec-dd)*60); ds = int(((adec-dd)*60-dm)*60)
        win._lbl.setText(f"💬 {rah:02d}:{ram:02d}:{ras:02d} {dsign}{dd:02d}:{dm:02d}:{ds:02d}")
        tl = self._web.mapTo(self, self._web.rect().topLeft())
        px = max(10, min(int(tl.x()+z.get("cx",400)-150), self.width()-310))
        py = max(10, min(int(tl.y()+z.get("cy",300)+z.get("R",20)+36), self.height()-270))
        win.move(px, py); win.setVisible(True); win.raise_()
        self._active_zone_idx = zone_idx
        # Build room_id snapped to 2-degree grid so all users get same ID
        # Snap to 2-degree grid using integer math to avoid float mismatch
        snapped_ra  = int(round(z.get("ra",  0) / 2.0)) * 2
        snapped_dec = int(round(z.get("dec", 0) / 2.0)) * 2
        room_id = f"zone_{snapped_ra}_{snapped_dec}"
        win._room_id = room_id
        import json as _jj, asyncio as _aio, threading as _th
        _loop = getattr(self, "_ws_event_loop", None)
        _conn = self._ws_conn
        print(f"[Chat] join_room={room_id} conn={_conn is not None} loop={_loop is not None and _loop.is_running()}")
        if _loop and _loop.is_running() and _conn:
            _pay = _jj.dumps({"_event": "join_room", "room_id": room_id})
            def _join(): _aio.run_coroutine_threadsafe(_conn.send(_pay), _loop)
            _th.Thread(target=_join, daemon=True).start()
            print(f"[Chat] join_room sent OK")
        else:
            print(f"[Chat] join_room FAILED - not connected")

    def _send_chat(self): pass

    def _send_chat_win(self, win_idx):
        if win_idx >= len(self._chat_wins): return
        win = self._chat_wins[win_idx]
        msg = win._inp.text().strip()
        if not msg or not self._ws_conn: return
        win._inp.clear()
        import json as _j, asyncio
        room_id = getattr(win, "_room_id", "")
        payload = _j.dumps({"_event":"chat","message":msg,"room_id":room_id})
        loop = getattr(self, "_ws_event_loop", None)
        conn = self._ws_conn
        if loop and loop.is_running() and conn:
            try:
                asyncio.run_coroutine_threadsafe(conn.send(payload), loop)
            except Exception as e:
                print(f"[Chat] send error: {e}")

    def _on_building_cam_changed(self, name):
        """Immediately fetch the newly selected building camera in background."""
        import threading
        self.lbl_cam_bldg.setText(f"Loading {name}…")
        self.lbl_cam_bldg.setPixmap(__import__("PyQt6.QtGui", fromlist=["QPixmap"]).QPixmap())
        threading.Thread(target=self._fetch_building_cam, args=(name,), daemon=True).start()

    def _refresh_cameras(self):
        """Fetch allsky only on timer; building cam fetches on dropdown change."""
        import threading
        try:
            print(f"[Cam] timer refresh — allsky only")
            threading.Thread(target=self._fetch_allsky_only, daemon=True).start()
        except Exception as e:
            print(f"[Cam] refresh error: {e}")

    def _fetch_allsky_only(self):
        import datetime
        try:
            raw = self._fetch_jpeg(CAM_ALLSKY)
            data = self._scale_jpeg(raw, 220)
            print(f"[Cam] allsky OK {len(raw)} -> {len(data) if data else 0} scaled")
        except Exception as e:
            data = None
            print(f"[Cam] allsky FAIL: {e}")
        updated = datetime.datetime.now().strftime("%H:%M:%S")
        self._cam_pending = (data, "", None, "", updated)
        self._ws_signal.emit({"_event": "_cam_ready"})

    def _fetch_jpeg(self, url):
        import urllib.request, time
        ts = int(time.time() * 1000)
        req = urllib.request.Request(
            f"{url}?{ts}",
            headers={"User-Agent": "RockwoodPlanetarium/1.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.read()

    def _scale_jpeg(self, data, max_h):
        """Decode and scale a JPEG on the background thread using PIL to avoid Qt main thread load."""
        if not data or len(data) < 64:
            return None
        try:
            from PIL import Image
            import io
            img = Image.open(io.BytesIO(data))
            img = img.convert("RGB")
            w, h = img.size
            new_h = max_h
            new_w = int(w * new_h / h)
            img = img.resize((new_w, new_h), Image.LANCZOS)
            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=85)
            return buf.getvalue()
        except Exception as e:
            print(f"[Cam] PIL scale error: {e} — falling back to raw")
            return data  # return raw, let Qt handle it

    def _apply_jpeg(self, lbl, data, max_h, err=None):
        from PyQt6.QtGui import QImage, QPixmap
        from PyQt6.QtCore import Qt as _Qt
        if not data or len(data) < 64:
            print(f"[Cam] no data, err={err}")
            lbl.setText("Unavailable" if not err else f"Error: {err[:60]}")
            return
        print(f"[Cam] applying {len(data)} bytes")
        try:
            img = QImage.fromData(bytes(data))
            if img.isNull():
                lbl.setText("Bad image data")
                return
            px = QPixmap.fromImage(img)
            lbl.setPixmap(px)
            print(f"[Cam] displayed {px.width()}x{px.height()}")
        except Exception as e:
            print(f"[Cam] display error: {e}")
            lbl.setText(f"Display error: {e}")

    def _fetch_all_cameras(self, bldg_name):
        print(f"[Cam] _fetch_all_cameras started bldg={bldg_name!r}")
        from PyQt6.QtCore import QTimer
        import datetime
        allsky_data = allsky_err = bldg_data = bldg_err = None
        try:
            raw = self._fetch_jpeg(CAM_ALLSKY)
            allsky_data = self._scale_jpeg(raw, 220)
            print(f"[Cam] allsky OK {len(raw)} bytes -> {len(allsky_data) if allsky_data else 0} scaled")
        except Exception as e:
            allsky_err = str(e)
            print(f"[Cam] allsky FAIL: {e}")
        bldg_url = CAM_BUILDINGS.get(bldg_name)
        if bldg_url:
            try:
                raw = self._fetch_jpeg(bldg_url)
                bldg_data = self._scale_jpeg(raw, 180)
                print(f"[Cam] bldg OK {len(raw)} bytes -> {len(bldg_data) if bldg_data else 0} scaled")
            except Exception as e:
                bldg_err = str(e)
                print(f"[Cam] bldg FAIL: {e}")
        updated = datetime.datetime.now().strftime("%H:%M:%S")
        self._cam_pending = (allsky_data, allsky_err, bldg_data, bldg_err, updated)
        self._ws_signal.emit({"_event": "_cam_ready"})

    def _on_cam_data(self, allsky_data, allsky_err, bldg_data, bldg_err, updated):
        print(f"[Cam] _on_cam_data allsky={len(allsky_data) if allsky_data else 0} bldg={len(bldg_data) if bldg_data else 0}")
        if allsky_data:
            self._apply_jpeg(self.lbl_cam_allsky, allsky_data, 220, allsky_err or None)
        if bldg_data is not None:
            self._apply_jpeg(self.lbl_cam_bldg, bldg_data, 180, bldg_err or None)
        elif bldg_err:
            self.lbl_cam_bldg.setText(f"Error: {bldg_err[:60]}")
        if updated:
            self.lbl_cam_updated.setText(f"Updated {updated}  ·  auto-refreshes every {CAM_REFRESH_SECS}s")

    def _fetch_building_cam(self, bldg_name):
        bldg_url = CAM_BUILDINGS.get(bldg_name)
        if not bldg_url:
            self._cam_pending = (None, "", None, f"No URL for {bldg_name}", "")
            self._ws_signal.emit({"_event": "_cam_ready"})
            return
        print(f"[Cam] fetching {bldg_name} from {bldg_url}")
        try:
            raw  = self._fetch_jpeg(bldg_url)
            data = self._scale_jpeg(raw, 180)
            err  = ""
            print(f"[Cam] {bldg_name} OK {len(raw)} bytes -> {len(data) if data else 0} scaled")
        except Exception as e:
            data = None
            err  = str(e)
            print(f"[Cam] {bldg_name} FAIL: {e}")
        self._cam_pending = (None, "", data, err, "")
        self._ws_signal.emit({"_event": "_cam_ready"})

    def _send_general_chat(self):
        msg = self.general_chat_input.text().strip()
        if not msg or not self._ws_conn: return
        self.general_chat_input.clear()
        import json as _j, asyncio
        payload = _j.dumps({"_event": "chat", "message": msg, "room_id": "general"})
        loop = getattr(self, "_ws_event_loop", None)
        conn = self._ws_conn
        if loop and loop.is_running() and conn:
            try:
                asyncio.run_coroutine_threadsafe(conn.send(payload), loop)
            except Exception as e:
                print(f"[GeneralChat] send error: {e}")

    def _receive_chat(self, username: str, message: str, zone_ra=None, zone_dec=None, room_id=None):
        from PyQt6.QtGui import QTextCursor
        import datetime, math
        ts = datetime.datetime.now().strftime("%H:%M")
        color = "#8ab0e0"
        for sid,s in self._sf_scopes.items():
            if s.get("username","").lower()==username.lower():
                color=_scope_color(sid); break
        if username.lower()=="astrofalls": color="hotpink"
        html = (f'<span style="color:#3a5a80;font-size:10px;">{ts}</span> '
                f'<b style="color:{color};">{username}</b>: '
                f'<span style="color:#b0c8e8;">{message}</span><br>')
        # Match by room_id, fallback to all visible if no match
        targets = []
        for wi in self._chat_windows.values():
            win = self._chat_wins[wi]
            if not win.isVisible(): continue
            if room_id and getattr(win, "_room_id", None) == room_id:
                targets.append(win)
        if not targets:
            targets = [self._chat_wins[wi] for wi in self._chat_windows.values()
                       if self._chat_wins[wi].isVisible()]
        for win in targets:
            win._log.moveCursor(QTextCursor.MoveOperation.End)
            win._log.insertHtml(html)
            win._log.moveCursor(QTextCursor.MoveOperation.End)

        # Also route to general chat panel if room is general or unspecified
        if room_id in ("general", "", None) or not targets:
            log = getattr(self, "general_chat_log", None)
            if log is not None:
                log.moveCursor(QTextCursor.MoveOperation.End)
                log.insertHtml(html)
                log.moveCursor(QTextCursor.MoveOperation.End)




    def _push_planets(self):
        import json
        try:
            planets = _compute_planet_positions()
            comets  = getattr(self, "_comet_data", [])
            data    = json.dumps({"planets": planets, "comets": comets})
            self._js(f"if(typeof updatePlanets!=='undefined') updatePlanets({data})")
            print(f"[Planets] pushed {len(planets)} planets")
        except Exception as e:
            import traceback; traceback.print_exc()

    def _open_leaderboard(self):
        if hasattr(self, "_lb_win") and self._lb_win and self._lb_win.isVisible():
            self._lb_win.raise_()
            self._lb_win.activateWindow()
            return
        self._lb_win = _LeaderboardWindow(self, self)
        self._lb_win.show()

    def _open_observatory(self):
        if hasattr(self, "_obs_win") and self._obs_win and self._obs_win.isVisible():
            self._obs_win.raise_()
            self._obs_win.activateWindow()
            return
        self._obs_win = _ObservatoryWindow(self, self)
        self._obs_win.show()

    def _open_settings(self):
        dlg = _SettingsDialog(self, self)
        dlg.exec()

    def _open_my_profile(self):
        if not self._sf_username: return
        if getattr(self, "_profile_open", False): return
        self._profile_open = True
        dlg = UserProfileDialog(self._sf_username, self._sf_host, self,
                                token=self._sf_token, is_own=True)
        dlg.finished.connect(lambda: setattr(self, "_profile_open", False))
        dlg.show()

    def _community_user_clicked(self, index):
        if getattr(self, "_profile_open", False): return
        item = self.community_table.item(index.row(), 0)
        if not item: return
        import re
        # Strip leading medal emoji or #N rank prefix, then extract username
        # e.g. "🥇 Frank" -> "Frank", "#5 Frank" -> "Frank", "5 Frank" -> "Frank"
        text = item.text().strip()
        text = re.sub(r"^[^\w]*#?\d+\s+", "", text).strip()  # strip rank like "#5 " or "5 "
        text = re.sub(r"^[^\w\s]+\s+", "", text).strip()     # strip medal emoji like "🥇 "
        self._profile_open = True
        dlg = UserProfileDialog(text, self._sf_host, self, token=self._sf_token)
        dlg.finished.connect(lambda: setattr(self, "_profile_open", False))
        dlg.show()

    def _load_community_stats(self):
        """Fetch leaderboard, feed, and personal stats from server."""
        import threading
        def _fetch():
            try:
                print("[Community] fetching...")
                self._fetch_leaderboard()
                self._fetch_feed()
                if self._sf_token:
                    self._fetch_my_stats()
                print("[Community] done")
            except Exception as e:
                print(f"[Community] ERROR: {e}")
                import traceback; traceback.print_exc()
        threading.Thread(target=_fetch, daemon=True).start()

    def _fmt_exposure(self, secs: float) -> str:
        """Format seconds as Xh Ym or Xm."""
        secs = int(secs)
        h = secs // 3600; m = (secs % 3600) // 60
        if h: return f"{h}h {m:02d}m"
        return f"{m}m"

    def _set_lb_period(self, period):
        self._lb_period = period
        self.btn_lb_alltime.setChecked(period == "alltime")
        self.btn_lb_month.setChecked(period == "month")
        import threading
        threading.Thread(target=self._fetch_leaderboard, daemon=True).start()

    def _set_lb_category(self, category):
        self._lb_category = category
        for cat_id, btn in self._lb_cat_btns.items():
            btn.setChecked(cat_id == category)
        import threading
        threading.Thread(target=self._fetch_leaderboard, daemon=True).start()

    def _fetch_leaderboard(self):
        period   = getattr(self, "_lb_period",   "alltime")
        category = getattr(self, "_lb_category", "exposure")
        res, st = self._sf_api("GET", f"/stats?period={period}&category={category}")
        if st != 200:
            print(f"[Community] leaderboard HTTP {st}  res={res}")
            return
        rows     = res.get("leaderboard", [])
        category = res.get("category", category)
        print(f"[Community] leaderboard {period}/{category} rows: {len(rows)}")
        from PyQt6.QtCore import Qt
        medals = ["🥇", "🥈", "🥉"]
        self._ws_signal.emit({"_event": "_community_leaderboard",
                              "rows": rows, "medals": medals,
                              "category": category})

    def _fetch_feed(self):
        res, st = self._sf_api("GET", "/feed")
        if st != 200:
            print(f"[Community] feed HTTP {st}")
            return
        sessions = res.get("sessions", [])
        print(f"[Community] feed sessions: {len(sessions)}")
        self._ws_signal.emit({"_event": "_community_feed", "sessions": sessions})

    def _fetch_my_stats(self):
        res, st = self._sf_api("GET", "/me/stats")
        if st != 200: return
        totals = res.get("totals", {})
        secs   = totals.get("total_secs", 0)
        frames = totals.get("total_frames", 0)
        nights = totals.get("total_nights", 0)
        targets= totals.get("total_targets", 0)
        exp_str = self._fmt_exposure(secs)
        text = (f"⏱ {exp_str} total exposure  ·  🌙 {nights} nights  ·  "
                f"🔭 {targets} targets  ·  📷 {frames} frames")
        self._ws_signal.emit({"_event": "_community_mystats", "text": text})

    def _sf_login(self):
        u = self.sf_user.text().strip(); pw = self.sf_pass.text().strip()
        if not u or not pw:
            self.lbl_auth.setText("Enter username and password"); return
        res, st = self._sf_api("POST", "/login", {"username":u,"password":pw})
        if st == 200:
            self._sf_token    = res["token"]
            self._sf_username = res["username"]
            self.lbl_auth.setText(f"Logged in as {res['username']}")
            self._load_nina_credentials()
            self._save_credentials()
            self._load_community_stats()
        else:
            self.lbl_auth.setText(res.get("error","Login failed"))

    def _sf_logout(self):
        if self._sf_token:
            self._sf_api("POST", "/logout")
        self._sf_token    = ""
        self._sf_username = ""
        self._save_credentials()
        self.lbl_auth.setText("Logged out")
        self.box_nina.setVisible(False)
        self._ws_disconnect()

    def _load_nina_credentials(self):
        """Fetch scopes+api_keys and populate the My Scopes panel."""
        self.box_nina.setVisible(True)
        res, st = self._sf_api("GET", "/me/scopes")
        if st != 200:
            self.nina_apikey.setPlaceholderText(f"Error (HTTP {st}) — is server updated?")
            return
        # Normalize: server uses "id", UI expects "scope_id"
        raw = res.get("scopes", [])
        self._nina_scopes = [{**s, "scope_id": s.get("scope_id", s.get("id",""))} for s in raw]
        # Populate table
        self.my_scopes_table.setRowCount(0)
        for s in self._nina_scopes:
            r = self.my_scopes_table.rowCount()
            self.my_scopes_table.insertRow(r)
            name_item = QTableWidgetItem(s["name"])
            name_item.setData(32, s["scope_id"])
            self.my_scopes_table.setItem(r, 0, name_item)
            del_item = QTableWidgetItem("✕")
            del_item.setData(32, s["scope_id"])
            del_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            del_item.setForeground(QColor("#c05050"))
            self.my_scopes_table.setItem(r, 1, del_item)
        if self._nina_scopes:
            self.my_scopes_table.selectRow(0)
            self._nina_scope_selected(0)
        else:
            self.nina_apikey.setPlaceholderText("No scopes — register one below")
            self.nina_scopeid.setPlaceholderText("")

    def _nina_scope_selected(self, idx):
        if 0 <= idx < len(self._nina_scopes):
            s = self._nina_scopes[idx]
            self.nina_apikey.setText(s["api_key"])
            self.nina_scopeid.setText(s["scope_id"])

    def _my_scope_selection_changed(self):
        rows = self.my_scopes_table.selectedItems()
        if rows:
            idx = self.my_scopes_table.currentRow()
            self._nina_scope_selected(idx)
            self.btn_del_my_scope.setEnabled(True)
            self.btn_rename_scope.setEnabled(True)
        else:
            self.btn_del_my_scope.setEnabled(False)
            self.btn_rename_scope.setEnabled(False)


    def _set_scope_key(self):
        idx = self.my_scopes_table.currentRow()
        if idx < 0 or idx >= len(self._nina_scopes):
            QMessageBox.information(self, "No scope selected", "Select a scope first.")
            return
        s = self._nina_scopes[idx]
        new_key, ok = QInputDialog.getText(
            self, "Set API Key",
            f"Enter new API key for '{s['name']}':\n"
            "(min 8 chars — use any string you want, e.g. your old key):"
        )
        if not ok or not new_key.strip(): return
        new_key = new_key.strip()
        if len(new_key) < 8:
            QMessageBox.warning(self, "Too short", "API key must be at least 8 characters.")
            return
        import http.client as _hc, json as _json
        conn = _hc.HTTPConnection(self._sf_host, 8088, timeout=8)
        hdrs = {"Content-Type":"application/json","Authorization":f"Bearer {self._sf_token}"}
        body = _json.dumps({"scope_id": s["scope_id"], "api_key": new_key}).encode()
        try:
            conn.request("POST", "/scopes/set-key", body, hdrs)
            r = conn.getresponse()
            res = _json.loads(r.read())
            if r.status == 200:
                QMessageBox.information(self, "Key Updated",
                    f"API key for '{s['name']}' updated.\n\n"
                    f"New key: {new_key}\n\n"
                    "Update your NINA plugin settings with this key.")
                self._load_nina_credentials()
            else:
                QMessageBox.warning(self, "Error", res.get("error", "Failed"))
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))
        finally:
            conn.close()

    def _nina_register_scope(self):
        name, ok = QInputDialog.getText(self, "Register Scope", "Scope name (e.g. 'Rockwood 14-inch C14'):")
        if not ok or not name.strip():
            return
        loc, ok2 = QInputDialog.getText(self, "Register Scope", "Location (e.g. 'Rockwood, TX'):")
        if not ok2:
            return
        res, st = self._sf_api("POST", "/scopes/register",
                               {"name": name.strip(), "location": loc.strip(),
                                "lat": SITE_LAT, "lon": SITE_LON})
        if st == 201:
            QMessageBox.information(self, "Scope Registered",
                f"Scope '{name}' registered!\nScope ID: {res['scope_id']}\nAPI Key: {res['api_key']}")
            self._load_nina_credentials()
        else:
            QMessageBox.warning(self, "Error", res.get("error", "Failed to register scope"))


    def _rename_my_selected_scope(self):
        idx = self.my_scopes_table.currentRow()
        if idx < 0 or idx >= len(self._nina_scopes): return
        s = self._nina_scopes[idx]
        new_name, ok = QInputDialog.getText(self, "Rename Scope",
                                            "New name:", text=s["name"])
        if not ok or not new_name.strip(): return
        new_name = new_name.strip()
        path = f"/scopes/{s['scope_id']}/rename"
        print(f"[Rename] POST {path} name={new_name} host={self._sf_host}")
        res, st = self._sf_api("POST", path, {"name": new_name})
        print(f"[Rename] response: {st} {res}")
        if st == 200:
            self._load_nina_credentials()
            QMessageBox.information(self, "Renamed",
                f"Scope renamed to '{new_name}'.\nAll imaging history updated.")
        else:
            QMessageBox.warning(self, "Error",
                res.get("error", f"Failed (HTTP {st})"))

    def _delete_my_selected_scope(self):
        idx = self.my_scopes_table.currentRow()
        if idx < 0 or idx >= len(self._nina_scopes):
            return
        s = self._nina_scopes[idx]
        if not self._sf_token:
            QMessageBox.warning(self, "Not logged in", "Log in first.")
            return
        reply = QMessageBox.question(self, "Delete Scope",
            f"Delete '{s['name']}'? This cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return
        import http.client as _hc, json as _json
        conn = _hc.HTTPConnection(self._sf_host, 8088, timeout=8)
        hdrs = {"Content-Type":"application/json","Authorization":f"Bearer {self._sf_token}"}
        try:
            conn.request("DELETE", f"/scopes/{s['scope_id']}", b"", hdrs)
            r = conn.getresponse()
            body = r.read()
            try: res = _json.loads(body) if body else {}
            except Exception: res = {}
            if r.status == 200:
                self._sf_scopes.pop(s["scope_id"], None)
                self._rebuild_scopes_table()
                self._load_nina_credentials()
            else:
                QMessageBox.warning(self, "Error", res.get("error", f"HTTP {r.status}"))
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))
        finally:
            conn.close()

    def _nina_delete_scope(self):
        idx = self.nina_scope_combo.currentIndex()
        if idx < 0 or idx >= len(self._nina_scopes):
            QMessageBox.information(self, "No scope", "No scope selected.")
            return
        s = self._nina_scopes[idx]
        reply = QMessageBox.question(self, "Delete Scope",
            f"Delete scope '{s['name']}'?\nThis cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return
        conn = __import__('http.client', fromlist=['HTTPConnection']).HTTPConnection(self._sf_host, 8088, timeout=8)
        hdrs = {"Content-Type": "application/json", "Authorization": f"Bearer {self._sf_token}"}
        try:
            conn.request("DELETE", f"/scopes/{s['scope_id']}", b"", hdrs)
            r = conn.getresponse()
            res = __import__('json').loads(r.read())
            if r.status == 200:
                QMessageBox.information(self, "Deleted", f"Scope '{s['name']}' deleted.")
                self._load_nina_credentials()
            else:
                QMessageBox.warning(self, "Error", res.get("error", "Failed"))
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))
        finally:
            conn.close()

    # ── WebSocket ─────────────────────────────────────────────────────────────

    def _ws_toggle(self):
        if self._ws_running: self._ws_disconnect()
        else:                self._ws_connect()

    def _ws_connect(self):
        if not self._sf_token:
            QMessageBox.information(self,"Login required",
                                    "Please log in to Starfront first.")
            return
        url = f"wss://{self._sf_host}:443/ws/view?token={self._sf_token}"
        self._ws_running = True
        self.btn_connect.setText("Disconnect")
        self.lbl_scope_status.setText("Connecting…")
        threading.Thread(target=self._ws_loop, args=(url,), daemon=True).start()

    def _ws_disconnect(self):
        self._ws_running = False; self._ws_conn = None
        self.btn_connect.setText("Connect to Starfront")
        self.dot.setStyleSheet(
            "background:#c0392b;border-radius:5px;"
            "min-width:10px;max-width:10px;min-height:10px;max-height:10px;")
        self.lbl_scope_status.setText("Disconnected")
        self._sf_scopes = {}
        self._rebuild_scopes_table()

    def _view_ra(self): return getattr(self, "__view_ra", 0)
    def _view_dec(self): return getattr(self, "__view_dec", 0)
    def _view_fov(self): return getattr(self, "__view_fov", 180)

    def _ws_loop(self, url: str):
        import asyncio
        loop = asyncio.SelectorEventLoop()
        asyncio.set_event_loop(loop)
        self._ws_event_loop = loop

        async def _run():
            import websockets
            while self._ws_running:
                try:
                    async with websockets.connect(
                            url, open_timeout=8,
                            ping_interval=30, ping_timeout=30) as ws:
                        self._ws_conn = ws
                        self._ws_signal.emit({"_connected": True})
                        while self._ws_running:
                            try:
                                raw = await asyncio.wait_for(ws.recv(), timeout=30)
                                self._ws_signal.emit(json.loads(raw))
                            except asyncio.TimeoutError:
                                pass
                            except Exception:
                                break
                except Exception as e:
                    self._ws_conn = None
                    if self._ws_running:
                        self._ws_signal.emit({"_error": str(e)})
                        await asyncio.sleep(3)

        try:
            loop.run_until_complete(_run())
        finally:
            loop.close(); self._ws_conn = None

    def _on_ws_state(self, state: dict):
        ev = state.get("_event", "")

        if "_connected" in state:
            self.dot.setStyleSheet(
                "background:#27ae60;border-radius:5px;"
                "min-width:10px;max-width:10px;min-height:10px;max-height:10px;")
            self.lbl_scope_status.setText("Connected to Starfront")
            self._load_community_stats()
            # Re-join all active chat rooms after reconnect (delay to let server register connection)
            QTimer.singleShot(1000, self._rejoin_chat_rooms)
            QTimer.singleShot(1200, self._join_general_chat_room)
            return

        if "_error" in state:
            self.dot.setStyleSheet(
                "background:#e67e22;border-radius:5px;"
                "min-width:10px;max-width:10px;min-height:10px;max-height:10px;")
            self.lbl_scope_status.setText(f"Retrying… ({state['_error'][:28]})")
            return

        ev = state.get("_event")

        if ev == "_community_leaderboard":
            from PyQt6.QtCore import Qt
            rows     = state.get("rows", [])
            category = state.get("category", "exposure")
            medals   = ["🥇","🥈","🥉"]

            # Update column headers based on category
            headers = {
                "exposure":    ("User",        "Exposure", "Nights"),
                "deep_diver":  ("User",        "Exposure", "Target"),
                "marathon":    ("User",        "Streak",   "Nights"),
                "sii":         ("User",        "SII Time", ""),
                "guiding_rms": ("User",        'RMS"',    "Frames"),
            }
            h = headers.get(category, ("User", "Value", ""))
            self.community_table.setHorizontalHeaderLabels(list(h))

            self.community_table.setRowCount(0)
            for i, r in enumerate(rows):
                row = self.community_table.rowCount()
                self.community_table.insertRow(row)
                medal = medals[i] if i < 3 else f"#{i+1}"
                ni = QTableWidgetItem(f"{medal} {r['username']}")

                if category == "exposure":
                    ei = QTableWidgetItem(self._fmt_exposure(r.get("total_secs", 0)))
                    di = QTableWidgetItem(str(r.get("nights", 0)))
                elif category == "deep_diver":
                    ei = QTableWidgetItem(self._fmt_exposure(r.get("total_secs", 0)))
                    di = QTableWidgetItem(r.get("target", "")[:20])
                elif category == "marathon":
                    ei = QTableWidgetItem(f"{r.get('streak', 0)} nights")
                    di = QTableWidgetItem("")
                elif category == "sii":
                    ei = QTableWidgetItem(self._fmt_exposure(r.get("total_secs", 0)))
                    di = QTableWidgetItem("")
                elif category == "guiding_rms":
                    ei = QTableWidgetItem(f"{r.get('rms', 0):.3f}\"")
                    di = QTableWidgetItem(str(r.get("guide_frames", 0)))
                else:
                    ei = QTableWidgetItem("")
                    di = QTableWidgetItem("")

                ei.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                di.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                is_me = r.get("username","").lower() == self._sf_username.lower()
                color = QColor("#ffcc44") if is_me else QColor("#7ab0e0")
                for item in (ni, ei, di): item.setForeground(color)
                self.community_table.setItem(row, 0, ni)
                self.community_table.setItem(row, 1, ei)
                self.community_table.setItem(row, 2, di)
            return

        if ev == "_community_feed":
            import datetime
            from PyQt6.QtGui import QTextCursor
            self.feed_log.clear()
            # Reverse so oldest is at top, newest at bottom
            sessions = list(reversed(state.get("sessions", [])[:20]))
            for s in sessions:
                uname  = s.get("username","?")
                target = s.get("targets","").split(",")[0].strip() or "unknown target"
                filt   = s.get("filters","")
                secs   = s.get("total_secs", 0)
                frames = s.get("frame_count", 0)
                ts     = s.get("last_image_at", 0)
                exp_str  = self._fmt_exposure(secs)
                filt_str = f" · {filt}" if filt else ""
                try:
                    age = datetime.datetime.utcnow() - datetime.datetime.utcfromtimestamp(ts)
                    when = f"{age.days}d ago" if age.days > 0 else (f"{age.seconds//3600}h ago" if age.seconds>3600 else f"{age.seconds//60}m ago")
                except Exception: when = ""
                color = "#ffcc44" if uname.lower()==self._sf_username.lower() else "#5090c0"
                self.feed_log.append(
                    f'<b style="color:{color};">{uname}</b> '
                    f'<span style="color:#a0c8e0;">imaged <b>{target}</b>{filt_str} — {exp_str} ({frames} frames)</span> '
                    f'<span style="color:#3a6080;">{when}</span>')
            # Scroll to bottom so newest entry is visible
            self.feed_log.moveCursor(QTextCursor.MoveOperation.End)
            return

        if ev == "_community_mystats":
            self.lbl_my_stats.setText(state.get("text",""))
            return

        if ev == "chat":
            _rid = state.get("room_id")
            _wins = {wi: getattr(self._chat_wins[wi], "_room_id", None) for wi in self._chat_windows.values()}
            print(f"[Chat recv] room_id={_rid} windows={_wins}")
            self._receive_chat(state.get("username","?"), state.get("message",""),
                               room_id=_rid)
            return

        if ev == "image":
            sid  = state.get("scope_id", "")
            data = state.get("data", "")
            if sid and data:
                self._receive_scope_image(sid, data)
            return
        if ev in ("full_state", "state_update"):
            new_scopes = state.get("scopes", {})
            # Only do full rebuild if the set of scopes changed
            if set(new_scopes.keys()) != set(self._sf_scopes.keys()):
                self._sf_scopes = new_scopes
                self._rebuild_scopes_table()
            else:
                self._sf_scopes = new_scopes
                self._update_online_count()
                # Just update data in place without touching the table widget
                self._sf_scopes = new_scopes
                self._update_scopes_table_status()
            if self._sf_selected_id:
                self._refresh_scope_detail(self._sf_selected_id)
            return

        if ev == "scope_online":
            s = state.get("scope", {})
            self._sf_scopes[s["scope_id"]] = s
            self._rebuild_scopes_table()
            return

        if ev == "scope_offline":
            self._sf_scopes.pop(state.get("scope_id",""), None)
            self._rebuild_scopes_table()
            return

        if ev == "user_event":
            kind     = state.get("kind", "")
            username = state.get("username", "?")
            import datetime
            now = datetime.datetime.now().strftime("%H:%M")
            is_me = (username.lower() == self._sf_username.lower()) if self._sf_username else False
            if not is_me:  # don't announce yourself to yourself
                if kind == "joined":
                    icon, color, verb = "🟢", "#50e090", "joined"
                else:
                    icon, color, verb = "🔴", "#e05050", "left"
                name_color = "#ffcc44" if is_me else "#5090c0"
                self.feed_log.append(
                    f'<span style="color:#2a4060;">{now}</span>  '
                    f'{icon} <b style="color:{name_color};">{username}</b> '
                    f'<span style="color:{color};">{verb}</span>')
                from PyQt6.QtGui import QTextCursor
                self.feed_log.moveCursor(QTextCursor.MoveOperation.End)
            return

        if ev == "_cam_ready":
            pending = getattr(self, "_cam_pending", None)
            if pending:
                allsky_data, allsky_err, bldg_data, bldg_err, updated = pending
                self._on_cam_data(allsky_data, allsky_err, bldg_data, bldg_err, updated)
            return

        if "error" in state:
            self.lbl_scope_status.setText(state["error"][:50])
            return

        # Legacy bare position update
        ra = state.get("ra"); dec = state.get("dec")
        if ra is None or dec is None: return
        if self._sf_scopes:
            first = next(iter(self._sf_scopes))
            self._sf_scopes[first].update(state)
            self._rebuild_scopes_table()
            if not self._sf_selected_id:
                self._sf_selected_id = first
            self._refresh_scope_detail(self._sf_selected_id)

    # ── mount commands ────────────────────────────────────────────────────────

    def _send_ws_cmd(self, cmd: dict):
        if not self._ws_running or self._ws_conn is None: return
        raw = json.dumps(cmd)
        def _go():
            try:
                import asyncio
                asyncio.run_coroutine_threadsafe(
                    self._ws_conn.send(raw), asyncio.get_event_loop())
            except Exception as e:
                self._ws_signal.emit({"_error": f"send: {e}"})
        threading.Thread(target=_go, daemon=True).start()

    def _ascom_goto(self):
        if self._target_ra is None: return
        self._send_ws_cmd({"action":"goto",
                           "ra": self._target_ra, "dec": self._target_dec})
        self.lbl_scope_status.setText("Slewing…")

    def _ascom_stop(self):
        self._send_ws_cmd({"action": "stop"})


# ─────────────────────────────────────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def main():
    import os

    # ── Windows / Chromium environment setup ─────────────────────────────────
    # These must be set BEFORE QApplication is created.
    #
    # We let Chromium use whatever GPU path works (no --disable-gpu, no ANGLE
    # override).  The only flags we force are sandbox/shm fixes that help on
    # typical Windows Python installs.  The GLES3 "fallback to GLES2" messages
    # in the console are harmless — rendering still works fine.
    os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = (
        "--no-sandbox "
        "--disable-dev-shm-usage"
    )
    os.environ.setdefault("QTWEBENGINE_DISABLE_SANDBOX", "1")

    # Remove any leftover QT_OPENGL overrides that could break WebGL
    for _k in ("QT_OPENGL", "QT_ANGLE_PLATFORM"):
        os.environ.pop(_k, None)

    app = QApplication(sys.argv)
    app.setApplicationName("Rockwood Planetarium")
    app.setOrganizationName("Rockwood Observatory")

    # Prevent WebEngine from corrupting the Windows desktop compositor on exit
    app.setQuitOnLastWindowClosed(True)
    os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = (
        os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "") +
        " --disable-gpu-sandbox --in-process-gpu"
    )

    # Per-view profile with WebGL + cross-origin is set up in MainWindow._build_ui()
    # Just initialise the default profile with a sensible cache
    from PyQt6.QtWebEngineCore import QWebEngineProfile
    QWebEngineProfile.defaultProfile().setHttpCacheType(
        QWebEngineProfile.HttpCacheType.MemoryHttpCache)

    win = MainWindow()
    win.show()

    ret = app.exec()

    # Force WebEngine to shut down cleanly before Python exits —
    # prevents the Windows desktop compositor crash that blanks the desktop
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    del win
    app.processEvents()

    sys.exit(ret)


if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    try:
        main()
    except Exception as e:
        import traceback, os
        log = os.path.join(os.path.expanduser("~"), "rp_crash.txt")
        with open(log, "w") as f:
            traceback.print_exc(file=f)
        raise
