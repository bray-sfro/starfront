using System.IO;
using System.Text;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Starfront.PierWatch.Services;
using Starfront.PierWatch.Vision;
using Xunit;

namespace Starfront.PierWatch.Tests {

    /// <summary>Made-up pictures: a dark frame with a bright block somewhere in it, the "telescope".</summary>
    internal static class Pictures {
        public static byte[] Gray(int width, int height, int blockX, int blockY, int block = 12, byte floor = 30, byte bright = 220) {
            var gray = new byte[width * height];
            for (var y = 0; y < height; y++) {
                for (var x = 0; x < width; x++) {
                    // A gentle gradient so the frame is not flat outside the block.
                    var value = floor + (x * 20 / Math.Max(1, width - 1));
                    if (x >= blockX && x < blockX + block && y >= blockY && y < blockY + block) value = bright;
                    gray[y * width + x] = (byte)Math.Clamp(value, 0, 255);
                }
            }
            return gray;
        }

        public static Fingerprint Print(int blockX, int blockY, int width = 64, int height = 48) =>
            new(width, height, Gray(width, height, blockX, blockY));

        public static byte[] Png(byte[] gray, int width, int height) {
            var bitmap = BitmapSource.Create(width, height, 96, 96, PixelFormats.Gray8, null, gray, width);
            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(bitmap));
            using var stream = new MemoryStream();
            encoder.Save(stream);
            return stream.ToArray();
        }
    }

    public class SkyGeometryTests {
        [Theory]
        [InlineData(0, 0)]
        [InlineData(13, -11)]
        [InlineData(-13, 11)]
        [InlineData(25, 1)]
        [InlineData(12, -12)]
        public void HoursAreFoldedIntoHalfADay(double hours, double expected) =>
            Assert.Equal(expected, SkyGeometry.NormaliseHours(hours), 6);

        [Fact]
        public void TheZenithIsOnTheMeridianAtTheLatitude() {
            var (alt, _) = SkyGeometry.AltAz(0, 31.3, 31.3);
            Assert.Equal(90.0, alt, 3);
        }

        [Fact]
        public void SixHoursFromTheMeridianOnTheEquatorIsTheHorizon() {
            var (alt, az) = SkyGeometry.AltAz(6, 0, 0);
            Assert.Equal(0.0, alt, 3);
            Assert.Equal(270.0, az, 1);      // west
        }

        [Fact]
        public void BelowThePoleIsBelowTheHorizonForAMidLatitude() {
            var (alt, _) = SkyGeometry.AltAz(12, -60, 31.3);
            Assert.True(alt < -30, $"altitude {alt}");
        }

        [Fact]
        public void SeparationIsZeroForTheSamePoseAndNinetyForAQuarterTurnOnTheEquator() {
            Assert.Equal(0.0, SkyGeometry.Separation(1.5, 20, 1.5, 20), 6);
            Assert.Equal(90.0, SkyGeometry.Separation(0, 0, 6, 0), 3);
        }

        [Fact]
        public void HourAngleIsSiderealTimeLessRightAscension() {
            Assert.Equal(-2.0, SkyGeometry.HourAngle(1.0, 3.0), 6);
            Assert.Equal(1.0, SkyGeometry.HourAngle(0.5, 23.5), 6);
        }
    }

    public class FingerprintTests {
        [Fact]
        public void TheSamePictureCorrelatesPerfectly() {
            var a = Pictures.Print(10, 10);
            var b = Pictures.Print(10, 10);
            Assert.Equal(1.0, a.Correlate(b), 3);
        }

        [Fact]
        public void BrightnessAndContrastDoNotMatter() {
            var gray = Pictures.Gray(64, 48, 10, 10);
            var dimmer = gray.Select(v => (byte)(v / 2 + 15)).ToArray();
            var a = new Fingerprint(64, 48, gray);
            var b = new Fingerprint(64, 48, dimmer);
            Assert.True(a.Correlate(b) > 0.99, $"correlation {a.Correlate(b)}");
        }

        [Fact]
        public void ATelescopeSomewhereElseIsADifferentPicture() {
            var a = Pictures.Print(10, 10);
            var b = Pictures.Print(44, 30);
            Assert.True(a.Correlate(b) < 0.3, $"correlation {a.Correlate(b)}");
        }

        [Fact]
        public void AFlatPictureMatchesNothingNotEvenItself() {
            var flat = new Fingerprint(64, 48, Enumerable.Repeat((byte)100, 64 * 48).ToArray());
            Assert.Equal(0.0, flat.Correlate(flat), 6);
            Assert.Equal(0.0, flat.Correlate(Pictures.Print(10, 10)), 6);
        }

        [Fact]
        public void DifferentSizesNeverMatch() {
            var a = Pictures.Print(10, 10);
            var b = Pictures.Print(10, 10, 32, 24);
            Assert.Equal(-1.0, a.Correlate(b));
        }
    }

    public class ThumbnailTests {
        [Fact]
        public void ReductionAveragesAndCropsAsAsked() {
            var width = 200;
            var height = 100;
            var gray = new byte[width * height];
            for (var y = 0; y < height; y++)
                for (var x = 0; x < width; x++) gray[y * width + x] = (byte)(x < 100 ? 0 : 200);

            var whole = Thumbnails.Reduce(gray, width, height, Crop.Whole, 4, 2);
            Assert.Equal(new byte[] { 0, 0, 200, 200, 0, 0, 200, 200 }, whole.Gray);

            var right = Thumbnails.Reduce(gray, width, height, new Crop(0.5, 0, 0.5, 1), 2, 1);
            Assert.Equal(new byte[] { 200, 200 }, right.Gray);
        }

        [Fact]
        public void ACropOutsideTheFrameIsBroughtBackIn() {
            var crop = new Crop(1.5, -2, 9, 0).Sane();
            Assert.True(crop.Left <= 0.95 && crop.Top >= 0 && crop.Left + crop.Width <= 1.0 && crop.Height >= 0.05, crop.ToString());
        }

        [Fact]
        public void APngRoundTripsThroughTheDecoder() {
            var gray = Pictures.Gray(128, 96, 20, 20);
            var png = Pictures.Png(gray, 128, 96);
            var print = Thumbnails.FromImageBytes(png, Crop.Whole, 64, 48);
            var direct = Thumbnails.Reduce(gray, 128, 96, Crop.Whole, 64, 48);
            Assert.True(print.Correlate(direct) > 0.999, $"correlation {print.Correlate(direct)}");
        }
    }

    public class PositionMapTests {
        private static PoseSample Sample(double ha, double dec, Side side, int blockX, int blockY) => new() {
            HourAngle = ha, Declination = dec, PierSide = side, TakenUtc = DateTime.UtcNow,
            Gray = Pictures.Gray(64, 48, blockX, blockY),
        };

        [Fact]
        public void TheNearestPictureNamesThePose() {
            var map = new PositionMap(64, 48);
            map.Add(Sample(-2, 40, Side.West, 10, 10));
            map.Add(Sample(1, 10, Side.West, 40, 30));
            map.Add(Sample(3, 60, Side.East, 25, 5));
            var match = map.Find(Pictures.Print(40, 30));
            Assert.Equal(new Pose(1, 10, Side.West), match.Best.Pose);
            Assert.True(match.Score > 0.99, $"score {match.Score}");
            Assert.True(match.Rival < 0.5, $"rival {match.Rival}");
        }

        [Fact]
        public void TheSamePictureAtTheSamePlaceReplacesRatherThanJoins() {
            var map = new PositionMap(64, 48);
            map.Add(Sample(1, 10, Side.West, 40, 30));
            map.Add(Sample(1.01, 10.2, Side.West, 40, 30));
            Assert.Equal(1, map.Count);
            // A different picture of the same place is kept beside it.
            map.Add(Sample(1, 10, Side.West, 42, 31));
            Assert.Equal(2, map.Count);
            // The same picture on the other side of the pier is another pose.
            map.Add(Sample(1, 10, Side.East, 40, 30));
            Assert.Equal(3, map.Count);
        }

        [Fact]
        public void AnEmptyMapHasNoOpinion() => Assert.Null(new PositionMap(64, 48).Find(Pictures.Print(1, 1)));

        [Fact]
        public void TheMapSurvivesTheDisk() {
            var path = Path.Combine(Path.GetTempPath(), "pierwatch-test-" + Guid.NewGuid().ToString("N") + ".json");
            try {
                var map = new PositionMap(64, 48);
                map.Add(Sample(-2, 40, Side.West, 10, 10));
                map.Add(Sample(1, 10, Side.East, 40, 30));
                map.Save(path);
                var back = PositionMap.Load(path);
                Assert.Equal(2, back.Count);
                Assert.Equal(64, back.Width);
                var match = back.Find(Pictures.Print(10, 10));
                Assert.Equal(new Pose(-2, 40, Side.West), match.Best.Pose);
            } finally {
                File.Delete(path);
            }
        }

        [Fact]
        public void AWrongSizedSampleIsRefused() =>
            Assert.Throws<ArgumentException>(() => new PositionMap(64, 48).Add(new PoseSample { Gray = new byte[10] }));
    }

    public class JudgeTests {
        private static readonly Limits Limits = new(HorizonDegrees: 5, PastMeridianHours: 1.0, TrustScore: 0.9,
                                                    TrustMargin: 0.03, DisagreeDegrees: 20, StopWhenUnrecognised: false,
                                                    LatitudeDegrees: 31.3);

        private static Estimate Sure(double ha, double dec, Side side) => new(new Pose(ha, dec, side), 0.97, 0.4, true);
        private static Claim Says(double ha, double dec, Side side) => new(new Pose(ha, dec, side), true);

        [Fact]
        public void AgreementHighUpIsSafe() {
            var j = Judge.Decide(Sure(-1, 40, Side.West), Says(-1.1, 40.5, Side.West), Limits);
            Assert.Equal(Verdict.Safe, j.Verdict);
            Assert.True(j.CameraTrusted);
            Assert.Contains("agree", j.Reason);
        }

        [Fact]
        public void TheMountReportingBelowTheHorizonIsStoppedWithoutTheCamera() {
            var j = Judge.Decide(Estimate.None, Says(5.5, -40, Side.West), Limits);
            Assert.Equal(Verdict.Violation, j.Verdict);
            Assert.Contains("mount reports", j.Reason);
            Assert.Contains("horizon", j.Reason);
        }

        [Fact]
        public void TheCameraSeeingBelowTheHorizonIsStoppedWhateverTheMountSays() {
            var j = Judge.Decide(Sure(5.5, -40, Side.West), Says(-1, 40, Side.West), Limits);
            Assert.Equal(Verdict.Violation, j.Verdict);
            Assert.Contains("camera sees", j.Reason);
        }

        [Fact]
        public void WestSidePastTheMeridianLimitIsAPierCrash() {
            var j = Judge.Decide(Sure(1.4, 40, Side.West), Says(1.4, 40, Side.West), Limits);
            Assert.Equal(Verdict.Violation, j.Verdict);
            Assert.Contains("pier", j.Reason);
        }

        [Fact]
        public void EastSideShortOfTheMeridianLimitIsAPierCrash() {
            var j = Judge.Decide(Sure(-1.4, 40, Side.East), Says(-0.2, 40, Side.East), Limits);
            Assert.Equal(Verdict.Violation, j.Verdict);
            Assert.Contains("east side", j.Reason);
        }

        [Fact]
        public void WestSideBeforeTheMeridianIsFine() {
            var j = Judge.Decide(Sure(-3, 40, Side.West), Says(-3, 40, Side.West), Limits);
            Assert.Equal(Verdict.Safe, j.Verdict);
        }

        [Fact]
        public void ASureCameraFarFromTheDriverMeansTheDriverIsLost() {
            // The driver's own report is within every limit; only the camera says otherwise.
            var j = Judge.Decide(Sure(-1, 40, Side.West), Says(-3, 10, Side.West), Limits);
            Assert.Equal(Verdict.Violation, j.Verdict);
            Assert.Contains("lost its place", j.Reason);
        }

        [Fact]
        public void TheOtherSideOfThePierIsADisagreementHoweverCloseTheSky() {
            var j = Judge.Decide(Sure(-0.2, 40, Side.East), Says(-0.2, 40, Side.West), Limits);
            Assert.Equal(Verdict.Violation, j.Verdict);
            Assert.Contains("other side", j.Reason);
        }

        [Fact]
        public void AWeakMatchIsUnsureNotAFault() {
            var weak = new Estimate(new Pose(5.5, -40, Side.West), 0.6, 0.5, true);
            var j = Judge.Decide(weak, Says(-1, 40, Side.West), Limits);
            Assert.Equal(Verdict.Unsure, j.Verdict);
            Assert.False(j.CameraTrusted);
        }

        [Fact]
        public void AnAmbiguousMatchIsUnsure() {
            var ambiguous = new Estimate(new Pose(-1, 40, Side.West), 0.95, 0.94, true);
            var j = Judge.Decide(ambiguous, Says(-1, 40, Side.West), Limits);
            Assert.Equal(Verdict.Unsure, j.Verdict);
            Assert.Contains("more than one place", j.Reason);
        }

        [Fact]
        public void UnrecognisedStopsOnlyWhenAsked() {
            var weak = new Estimate(new Pose(-1, 40, Side.West), 0.6, 0.5, true);
            var strict = Limits with { StopWhenUnrecognised = true };
            Assert.Equal(Verdict.Violation, Judge.Decide(weak, Says(-1, 40, Side.West), strict).Verdict);
            // An empty map is never a fault: there is nothing to not recognise.
            Assert.Equal(Verdict.Unsure, Judge.Decide(Estimate.None, Says(-1, 40, Side.West), strict).Verdict);
        }

        [Fact]
        public void NoMountAndASureCameraStillChecksTheCamera() {
            Assert.Equal(Verdict.Safe, Judge.Decide(Sure(-1, 40, Side.West), Claim.None, Limits).Verdict);
            Assert.Equal(Verdict.Violation, Judge.Decide(Sure(5.5, -40, Side.West), Claim.None, Limits).Verdict);
        }

        [Fact]
        public void ThePierRuleCanBeSwitchedOff() {
            var off = Limits with { PastMeridianHours = 0 };
            Assert.Equal(Verdict.Safe, Judge.Decide(Sure(3, 40, Side.West), Says(3, 40, Side.West), off).Verdict);
        }
    }

    public class SurveyorTests {
        [Fact]
        public void TheGridStaysAboveTheHorizonAndWithinTheMeridianLimit() {
            var grid = Surveyor.Grid(31.3, 5, 1.0, 15);
            Assert.NotEmpty(grid);
            foreach (var pose in grid) {
                var (alt, _) = SkyGeometry.AltAz(pose.HourAngle, pose.Declination, 31.3);
                Assert.True(alt >= 5 + Surveyor.HorizonMargin - 1e-6, $"{pose} at {alt}°");
                Assert.True(Math.Abs(pose.HourAngle) <= 1.0 + 1e-6, $"{pose} outside the meridian limit");
            }
        }

        [Fact]
        public void NoLimitReachesSixHoursEitherWay() {
            var grid = Surveyor.Grid(31.3, 0, 0, 15);
            Assert.Contains(grid, p => p.HourAngle < -5.9);
            Assert.Contains(grid, p => p.HourAngle > 5.9);
        }

        [Fact]
        public void RowsAlternateDirectionSoSlewsStayShort() {
            var grid = Surveyor.Grid(31.3, 0, 0, 30);
            // Successive poses never jump more than a row and a step apart.
            for (var i = 1; i < grid.Count; i++) {
                var sep = grid[i - 1].SeparationFrom(grid[i]);
                Assert.True(sep <= 95, $"jump of {sep}° between {grid[i - 1]} and {grid[i]}");
            }
        }
    }

    public class FrameSourceTests {
        [Fact]
        public async Task OneJpegIsCutOutOfAnMjpegStream() {
            var jpeg = new byte[] { 0xFF, 0xD8, 0x01, 0x02, 0x03, 0xFF, 0xD9 };
            var body = Encoding.ASCII.GetBytes("--boundary\r\nContent-Type: image/jpeg\r\nContent-Length: 7\r\n\r\n")
                .Concat(jpeg)
                .Concat(Encoding.ASCII.GetBytes("\r\n--boundary\r\nContent-Type: image/jpeg\r\n\r\n"))
                .Concat(jpeg).ToArray();
            using var stream = new MemoryStream(body);
            var got = await FrameSource.OneJpegFromStream(stream, CancellationToken.None);
            Assert.Equal(jpeg, got);
        }

        [Fact]
        public async Task AStreamWithNoPictureIsRefused() {
            using var stream = new MemoryStream(Encoding.ASCII.GetBytes("--boundary\r\nnothing here\r\n"));
            await Assert.ThrowsAsync<InvalidOperationException>(() => FrameSource.OneJpegFromStream(stream, CancellationToken.None));
        }

        [Fact]
        public async Task ABadAddressIsRefusedBeforeAnyRequest() {
            using var source = new FrameSource();
            await Assert.ThrowsAsync<InvalidOperationException>(() => source.FetchAsync("ftp://camera/x.jpg", CancellationToken.None));
            await Assert.ThrowsAsync<InvalidOperationException>(() => source.FetchAsync("", CancellationToken.None));
        }
    }
}
