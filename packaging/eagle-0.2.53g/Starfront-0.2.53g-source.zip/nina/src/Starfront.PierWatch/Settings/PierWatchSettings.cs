using System.IO;
using System.Runtime.InteropServices;
using NINA.Core.Utility;
using NINA.Profile;
using NINA.Profile.Interfaces;
using Starfront.PierWatch.Services;
using Starfront.PierWatch.Vision;

namespace Starfront.PierWatch.Settings {

    /// <summary>
    /// Everything the plugin remembers, per N.I.N.A. profile.
    ///
    /// All of it belongs to the equipment - which camera watches the mount,
    /// where the telescope is in its picture, how far the mount may go - so
    /// all of it lives in the host's own per-profile plugin store, and a
    /// second profile for a second rig keeps its own. The learned map is
    /// too big for that store and goes in a file beside the plugin's data,
    /// one per profile.
    /// </summary>
    public sealed class PierWatchSettings : BaseINPC {
        private readonly IProfileService profiles;
        private readonly PluginOptionsAccessor options;

        public PierWatchSettings(IProfileService profiles) {
            this.profiles = profiles;
            var id = typeof(PierWatchSettings).Assembly.GetCustomAttributes(typeof(GuidAttribute), false)
                .OfType<GuidAttribute>().First().Value;
            PluginId = Guid.Parse(id);
            options = new PluginOptionsAccessor(profiles, PluginId);
            DataFolder = Path.Combine(CoreUtil.APPLICATIONTEMPPATH, "PluginSettings", PluginId.ToString("D").ToUpperInvariant());
            profiles.ProfileChanged += (_, _) => RaiseAllPropertiesChanged();
        }

        public Guid PluginId { get; }
        public string DataFolder { get; }

        /// <summary>The learned map for the active profile.</summary>
        public string MapPath => Path.Combine(DataFolder, $"map-{profiles.ActiveProfile.Id:D}.json");

        public double Latitude => profiles.ActiveProfile.AstrometrySettings.Latitude;
        public double Longitude => profiles.ActiveProfile.AstrometrySettings.Longitude;

        // -- the camera --------------------------------------------------------

        /// <summary>A snapshot or MJPEG address; user:password@ in it is sent as basic authentication.</summary>
        public string CameraUrl {
            get => options.GetValueString(nameof(CameraUrl), "");
            set { options.SetValueString(nameof(CameraUrl), (value ?? "").Trim()); RaisePropertyChanged(); }
        }

        public double PollSeconds {
            get => options.GetValueDouble(nameof(PollSeconds), 1.0);
            set { options.SetValueDouble(nameof(PollSeconds), Math.Clamp(value, 0.25, 60)); RaisePropertyChanged(); }
        }

        public double CropLeft {
            get => options.GetValueDouble(nameof(CropLeft), 0);
            set { options.SetValueDouble(nameof(CropLeft), Math.Clamp(value, 0, 0.95)); RaisePropertyChanged(); RaisePropertyChanged(nameof(Crop)); }
        }

        public double CropTop {
            get => options.GetValueDouble(nameof(CropTop), 0);
            set { options.SetValueDouble(nameof(CropTop), Math.Clamp(value, 0, 0.95)); RaisePropertyChanged(); RaisePropertyChanged(nameof(Crop)); }
        }

        public double CropWidth {
            get => options.GetValueDouble(nameof(CropWidth), 1);
            set { options.SetValueDouble(nameof(CropWidth), Math.Clamp(value, 0.05, 1)); RaisePropertyChanged(); RaisePropertyChanged(nameof(Crop)); }
        }

        public double CropHeight {
            get => options.GetValueDouble(nameof(CropHeight), 1);
            set { options.SetValueDouble(nameof(CropHeight), Math.Clamp(value, 0.05, 1)); RaisePropertyChanged(); RaisePropertyChanged(nameof(Crop)); }
        }

        public Crop Crop => new Crop(CropLeft, CropTop, CropWidth, CropHeight).Sane();

        /// <summary>The thumbnail's size. Changing it starts the map again, because old samples are the old size.</summary>
        public int ThumbWidth {
            get => options.GetValueInt32(nameof(ThumbWidth), 64);
            set { options.SetValueInt32(nameof(ThumbWidth), Math.Clamp(value, 16, 256)); RaisePropertyChanged(); }
        }

        public int ThumbHeight {
            get => options.GetValueInt32(nameof(ThumbHeight), 48);
            set { options.SetValueInt32(nameof(ThumbHeight), Math.Clamp(value, 12, 256)); RaisePropertyChanged(); }
        }

        // -- the lines ---------------------------------------------------------

        /// <summary>Altitude in degrees the telescope must stay above.</summary>
        public double HorizonLimit {
            get => options.GetValueDouble(nameof(HorizonLimit), 0);
            set { options.SetValueDouble(nameof(HorizonLimit), Math.Clamp(value, -30, 60)); RaisePropertyChanged(); }
        }

        /// <summary>Hours past the meridian a tube may track on the side it is on; 0 switches the rule off.</summary>
        public double PastMeridianHours {
            get => options.GetValueDouble(nameof(PastMeridianHours), 1.0);
            set { options.SetValueDouble(nameof(PastMeridianHours), Math.Clamp(value, 0, 6)); RaisePropertyChanged(); }
        }

        /// <summary>How well a picture must match before the camera's opinion counts.</summary>
        public double TrustScore {
            get => options.GetValueDouble(nameof(TrustScore), 0.90);
            set { options.SetValueDouble(nameof(TrustScore), Math.Clamp(value, 0.5, 0.999)); RaisePropertyChanged(); }
        }

        /// <summary>How much better the match must be than the best match elsewhere on the sky.</summary>
        public double TrustMargin {
            get => options.GetValueDouble(nameof(TrustMargin), 0.03);
            set { options.SetValueDouble(nameof(TrustMargin), Math.Clamp(value, 0, 0.5)); RaisePropertyChanged(); }
        }

        /// <summary>How far apart the camera's and the driver's positions may be before the driver is judged lost.</summary>
        public double DisagreeDegrees {
            get => options.GetValueDouble(nameof(DisagreeDegrees), 20);
            set { options.SetValueDouble(nameof(DisagreeDegrees), Math.Clamp(value, 3, 90)); RaisePropertyChanged(); }
        }

        /// <summary>Treat a picture the map does not recognise as a fault, not a shrug.</summary>
        public bool StopWhenUnrecognised {
            get => options.GetValueBoolean(nameof(StopWhenUnrecognised), false);
            set { options.SetValueBoolean(nameof(StopWhenUnrecognised), value); RaisePropertyChanged(); }
        }

        /// <summary>Pictures in a row that must break a rule before anything is done about it.</summary>
        public int ConfirmPictures {
            get => options.GetValueInt32(nameof(ConfirmPictures), 2);
            set { options.SetValueInt32(nameof(ConfirmPictures), Math.Clamp(value, 1, 10)); RaisePropertyChanged(); }
        }

        // -- what is done ------------------------------------------------------

        public bool StopSlew {
            get => options.GetValueBoolean(nameof(StopSlew), true);
            set { options.SetValueBoolean(nameof(StopSlew), value); RaisePropertyChanged(); }
        }

        public bool StopTracking {
            get => options.GetValueBoolean(nameof(StopTracking), true);
            set { options.SetValueBoolean(nameof(StopTracking), value); RaisePropertyChanged(); }
        }

        /// <summary>File a picture whenever the mount sits still at a known pose.</summary>
        public bool LearnAutomatically {
            get => options.GetValueBoolean(nameof(LearnAutomatically), true);
            set { options.SetValueBoolean(nameof(LearnAutomatically), value); RaisePropertyChanged(); }
        }

        /// <summary>Start watching when N.I.N.A. starts, with no button pressed.</summary>
        public bool WatchAtStart {
            get => options.GetValueBoolean(nameof(WatchAtStart), true);
            set { options.SetValueBoolean(nameof(WatchAtStart), value); RaisePropertyChanged(); }
        }

        public Limits ToLimits() => new(HorizonLimit, PastMeridianHours, TrustScore, TrustMargin,
                                        DisagreeDegrees, StopWhenUnrecognised, Latitude);
    }
}
