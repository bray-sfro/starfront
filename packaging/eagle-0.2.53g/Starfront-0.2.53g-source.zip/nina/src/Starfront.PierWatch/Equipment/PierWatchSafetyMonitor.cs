using System.ComponentModel;
using System.ComponentModel.Composition;
using NINA.Core.Utility;
using NINA.Equipment.Interfaces;
using NINA.Equipment.Interfaces.Mediator;
using NINA.Equipment.Interfaces.ViewModel;
using NINA.Profile.Interfaces;
using Starfront.PierWatch.Services;

namespace Starfront.PierWatch.Equipment {

    /// <summary>
    /// Offers the watch to N.I.N.A. as a safety monitor, so the host's own
    /// machinery - <i>Loop while safe</i>, the safety triggers, the
    /// equipment page - can act on it with nothing new to learn.
    /// </summary>
    [Export(typeof(IEquipmentProvider))]
    public class PierWatchSafetyProvider : IEquipmentProvider<ISafetyMonitor> {
        [ImportingConstructor]
        public PierWatchSafetyProvider(IProfileService profileService, ITelescopeMediator telescopeMediator) {
            Runtime.Ensure(profileService, telescopeMediator);
        }

        public string Name => "Starfront Pier Watch";

        public IList<ISafetyMonitor> GetEquipment() => new List<ISafetyMonitor> { new PierWatchSafetyMonitor() };
    }

    /// <summary>
    /// Safe while the watch has not tripped and the last picture broke no
    /// rule. A watch that is switched off vouches for nothing and says safe,
    /// the way an observatory with no monitor is not one that is always
    /// unsafe; switch it on, or set it to start with N.I.N.A., for the
    /// monitor to mean anything.
    /// </summary>
    public class PierWatchSafetyMonitor : BaseINPC, ISafetyMonitor {
        private bool connected;
        private PropertyChangedEventHandler forward;

        public string Id => "Starfront.PierWatch.SafetyMonitor";
        public string Name => "Pier Watch";
        public string DisplayName => "Pier Watch (Starfront)";
        public string Category => "Starfront";
        public string Description => "The pier camera's opinion of where the mount is, against the horizon and the pier.";
        public string DriverInfo => "Starfront Pier Watch plugin";
        public string DriverVersion => typeof(PierWatchSafetyMonitor).Assembly.GetName().Version?.ToString() ?? "";
        public IList<string> SupportedActions => new List<string>();
        public bool HasSetupDialog => false;

        public bool Connected {
            get => connected;
            private set { connected = value; RaisePropertyChanged(); }
        }

        public bool IsSafe {
            get {
                var watcher = Runtime.Watcher;
                if (watcher == null || !watcher.Watching) return true;
                if (watcher.Tripped) return false;
                return watcher.LastJudgement?.Verdict != Verdict.Violation;
            }
        }

        public Task<bool> Connect(CancellationToken token) {
            var watcher = Runtime.Watcher;
            if (watcher == null) return Task.FromResult(false);
            if (forward == null) {
                forward = (_, e) => {
                    if (e.PropertyName is nameof(PierWatcher.Tripped) or nameof(PierWatcher.LastJudgement)
                        or nameof(PierWatcher.Watching) or null) {
                        RaisePropertyChanged(nameof(IsSafe));
                    }
                };
                watcher.PropertyChanged += forward;
            }
            try {
                if (!watcher.Watching && !string.IsNullOrWhiteSpace(Runtime.Settings.CameraUrl)) watcher.Start();
            } catch (Exception ex) {
                Logger.Error("Pier Watch could not start watching for the safety monitor", ex);
            }
            Connected = true;
            RaisePropertyChanged(nameof(IsSafe));
            return Task.FromResult(true);
        }

        public void Disconnect() {
            var watcher = Runtime.Watcher;
            if (watcher != null && forward != null) watcher.PropertyChanged -= forward;
            forward = null;
            Connected = false;
        }

        public void SetupDialog() { }

        public string Action(string actionName, string actionParameters) => "";
        public string SendCommandString(string command, bool raw = true) => "";
        public bool SendCommandBool(string command, bool raw = true) => false;
        public void SendCommandBlind(string command, bool raw = true) { }
    }
}
