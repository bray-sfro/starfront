using System.ComponentModel.Composition;
using Newtonsoft.Json;
using NINA.Core.Model;
using NINA.Core.Utility;
using NINA.Equipment.Interfaces.Mediator;
using NINA.Profile.Interfaces;
using NINA.Sequencer.SequenceItem;
using NINA.Sequencer.Validations;
using Starfront.PierWatch.Services;

namespace Starfront.PierWatch.Sequencer {

    /// <summary>
    /// Builds the map: walks the mount through a grid of poses above the
    /// horizon and within the meridian limit, filing a picture at each.
    /// Fifteen-degree steps are about a hundred poses and ten minutes;
    /// the watch keeps learning afterwards, so coarse is fine.
    /// </summary>
    [ExportMetadata("Name", "Survey the pier camera")]
    [ExportMetadata("Description", "Slews through a grid of positions and files what the pier camera sees at each, so Pier Watch can recognise the mount anywhere.")]
    [ExportMetadata("Icon", "Starfront_PierWatchSVG")]
    [ExportMetadata("Category", "Starfront")]
    [Export(typeof(ISequenceItem))]
    [JsonObject(MemberSerialization.OptIn)]
    public class SurveyPierCamera : SequenceItem, IValidatable {
        private readonly IProfileService profileService;
        private readonly ITelescopeMediator telescopeMediator;
        private double stepDegrees = 15;
        private double settleSeconds = 3;
        private string detail = "";
        private IList<string> issues = new List<string>();

        [ImportingConstructor]
        public SurveyPierCamera(IProfileService profileService, ITelescopeMediator telescopeMediator) {
            this.profileService = profileService;
            this.telescopeMediator = telescopeMediator;
            Runtime.Ensure(profileService, telescopeMediator);
        }

        private SurveyPierCamera(SurveyPierCamera cloneMe) : this(cloneMe.profileService, cloneMe.telescopeMediator) {
            CopyMetaData(cloneMe);
            StepDegrees = cloneMe.StepDegrees;
            SettleSeconds = cloneMe.SettleSeconds;
        }

        public override object Clone() => new SurveyPierCamera(this);

        [JsonProperty]
        public double StepDegrees {
            get => stepDegrees;
            set { stepDegrees = Math.Clamp(value, 5, 45); RaisePropertyChanged(); RaisePropertyChanged(nameof(PoseCount)); }
        }

        [JsonProperty]
        public double SettleSeconds {
            get => settleSeconds;
            set { settleSeconds = Math.Clamp(value, 0.5, 30); RaisePropertyChanged(); }
        }

        public int PoseCount => Runtime.Settings == null ? 0 : Surveyor.Grid(
            Runtime.Settings.Latitude, Runtime.Settings.HorizonLimit, Runtime.Settings.PastMeridianHours, StepDegrees).Count;

        public string Detail {
            get => detail;
            private set { detail = value ?? ""; RaisePropertyChanged(); }
        }

        public IList<string> Issues {
            get => issues;
            private set { issues = value; RaisePropertyChanged(); }
        }

        public override async Task Execute(IProgress<ApplicationStatus> progress, CancellationToken token) {
            var watcher = Runtime.Watcher ?? throw new SequenceEntityFailedException("Pier Watch is not loaded");
            var settings = Runtime.Settings;
            if (string.IsNullOrWhiteSpace(settings.CameraUrl)) throw new SequenceEntityFailedException("no pier camera address is set");
            var grid = Surveyor.Grid(settings.Latitude, settings.HorizonLimit, settings.PastMeridianHours, StepDegrees);
            Detail = $"surveying {grid.Count} poses";
            var learned = await Surveyor.RunAsync(watcher, telescopeMediator, settings.Longitude, grid, SettleSeconds, progress, token);
            Detail = $"{learned} of {grid.Count} poses filed; the map holds {watcher.SampleCount}";
            Logger.Info("Pier Watch: " + Detail);
        }

        public override TimeSpan GetEstimatedDuration() => TimeSpan.FromSeconds(PoseCount * (SettleSeconds + 6));

        public bool Validate() {
            var list = new List<string>();
            if (Runtime.Watcher == null) list.Add("Pier Watch is not loaded");
            else if (string.IsNullOrWhiteSpace(Runtime.Settings?.CameraUrl)) list.Add("No pier camera address is set in Options > Plugins > Starfront Pier Watch");
            try {
                if (telescopeMediator?.GetInfo()?.Connected != true) list.Add("The mount is not connected");
            } catch (Exception) {
                list.Add("The mount is not connected");
            }
            Issues = list;
            return list.Count == 0;
        }

        public override void AfterParentChanged() => Validate();

        public override string ToString() => $"Category: {Category}, Item: {nameof(SurveyPierCamera)}, step {StepDegrees}°";
    }
}
