using System.ComponentModel.Composition;
using Newtonsoft.Json;
using NINA.Core.Model;
using NINA.Core.Utility;
using NINA.Core.Utility.Notification;
using NINA.Equipment.Interfaces.Mediator;
using NINA.Profile.Interfaces;
using NINA.Sequencer.Container;
using NINA.Sequencer.Interfaces.Mediator;
using NINA.Sequencer.SequenceItem;
using NINA.Sequencer.Trigger;
using NINA.Sequencer.Validations;
using Starfront.PierWatch.Services;

namespace Starfront.PierWatch.Sequencer {

    /// <summary>
    /// Ends the advanced sequence when the watch trips.
    ///
    /// The mount is already stopped by then - the watcher does that the
    /// moment a rule is confirmed, sequence or no sequence. What is left is
    /// the sequence itself, which would otherwise go on taking exposures of
    /// a telescope that is not tracking and then try to slew it somewhere
    /// else. Triggers run between instructions, so an exposure in progress
    /// finishes first; it is lost anyway.
    /// </summary>
    [ExportMetadata("Name", "Pier Watch guard")]
    [ExportMetadata("Description", "Ends the sequence when the pier camera says the mount is heading below the horizon, past the pier, or somewhere the driver does not think it is.")]
    [ExportMetadata("Icon", "Starfront_PierWatchSVG")]
    [ExportMetadata("Category", "Starfront")]
    [Export(typeof(ISequenceTrigger))]
    [JsonObject(MemberSerialization.OptIn)]
    public class PierWatchTrigger : SequenceTrigger, IValidatable {
        private readonly IProfileService profileService;
        private readonly ITelescopeMediator telescopeMediator;
        private readonly ISequenceMediator sequenceMediator;
        private DateTime? handledTrip;
        private IList<string> issues = new List<string>();

        [ImportingConstructor]
        public PierWatchTrigger(IProfileService profileService, ITelescopeMediator telescopeMediator, ISequenceMediator sequenceMediator) {
            this.profileService = profileService;
            this.telescopeMediator = telescopeMediator;
            this.sequenceMediator = sequenceMediator;
            Runtime.Ensure(profileService, telescopeMediator);
        }

        private PierWatchTrigger(PierWatchTrigger cloneMe) : this(cloneMe.profileService, cloneMe.telescopeMediator, cloneMe.sequenceMediator) {
            CopyMetaData(cloneMe);
        }

        public override object Clone() => new PierWatchTrigger(this);

        public IList<string> Issues {
            get => issues;
            private set { issues = value; RaisePropertyChanged(); }
        }

        public string Detail => Runtime.Watcher == null ? "" : Runtime.Watcher.Watching
            ? (Runtime.Watcher.Tripped ? "tripped: " + Runtime.Watcher.TripReason : "watching")
            : "not watching - switch the watch on in Options or the Pier Watch panel";

        public override bool ShouldTrigger(ISequenceItem previousItem, ISequenceItem nextItem) {
            var watcher = Runtime.Watcher;
            if (watcher == null || !watcher.Tripped) return false;
            // One trip, one end of the sequence: the operator who clears the
            // trip and starts again is not stopped for the same reason twice.
            return handledTrip != watcher.TrippedUtc;
        }

        public override Task Execute(ISequenceContainer context, IProgress<ApplicationStatus> progress, CancellationToken token) {
            var watcher = Runtime.Watcher;
            handledTrip = watcher?.TrippedUtc;
            var reason = watcher?.TripReason ?? "the watch tripped";
            Logger.Error("Pier Watch guard: ending the sequence - " + reason);
            try { Notification.ShowError("Pier Watch guard ended the sequence: " + reason); } catch (Exception) { }
            progress?.Report(new ApplicationStatus { Status = "Pier Watch: " + reason });
            try {
                sequenceMediator.CancelAdvancedSequence();
            } catch (Exception ex) {
                Logger.Error("Pier Watch guard could not cancel the sequence", ex);
            }
            return Task.CompletedTask;
        }

        public bool Validate() {
            var list = new List<string>();
            if (Runtime.Watcher == null) list.Add("Pier Watch is not loaded");
            else if (string.IsNullOrWhiteSpace(Runtime.Settings?.CameraUrl)) list.Add("No pier camera address is set in Options > Plugins > Starfront Pier Watch");
            Issues = list;
            RaisePropertyChanged(nameof(Detail));
            return list.Count == 0;
        }

        public override void AfterParentChanged() => Validate();

        public override string ToString() => $"Category: {Category}, Item: {nameof(PierWatchTrigger)}";
    }
}
