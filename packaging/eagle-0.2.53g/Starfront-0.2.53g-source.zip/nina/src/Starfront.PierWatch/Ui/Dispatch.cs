using System.Windows;

namespace Starfront.PierWatch.Ui {

    /// <summary>WPF objects belong to their dispatcher; the watcher's loop and the mediators run on any thread.</summary>
    internal static class Dispatch {
        public static void OnUi(Action action) {
            var dispatcher = Application.Current?.Dispatcher;
            if (dispatcher == null || dispatcher.CheckAccess()) action();
            else dispatcher.BeginInvoke(action);
        }
    }
}
