using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace Starfront.PierWatch.Ui {

    /// <summary>True shows, false collapses.</summary>
    public sealed class ShowWhenTrue : IValueConverter {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture) =>
            value is true ? Visibility.Visible : Visibility.Collapsed;
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotSupportedException();
    }

    /// <summary>False shows, true collapses.</summary>
    public sealed class ShowWhenFalse : IValueConverter {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture) =>
            value is true ? Visibility.Collapsed : Visibility.Visible;
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotSupportedException();
    }

    /// <summary>A non-empty string or something non-null shows; nothing collapses.</summary>
    public sealed class ShowWhenSomething : IValueConverter {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
            if (value == null) return Visibility.Collapsed;
            if (value is string text) return text.Trim().Length > 0 ? Visibility.Visible : Visibility.Collapsed;
            return Visibility.Visible;
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotSupportedException();
    }

    /// <summary>A boolean as the text to put on a button that toggles it: the parameter is "when true|when false".</summary>
    public sealed class ToggleLabel : IValueConverter {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
            var parts = (parameter as string ?? "On|Off").Split('|');
            return value is true ? parts[0] : (parts.Length > 1 ? parts[1] : parts[0]);
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotSupportedException();
    }
}
