using System.ComponentModel.Composition;
using System.Windows;
using System.Windows.Media;
using CommunityToolkit.Mvvm.Input;
using RelayCommand = CommunityToolkit.Mvvm.Input.RelayCommand;
using NINA.Core.Model;
using NINA.Core.Utility;
using NINA.Core.Utility.Notification;
using NINA.Equipment.Interfaces.Mediator;
using NINA.Equipment.Interfaces.ViewModel;
using NINA.Profile.Interfaces;
using NINA.WPF.Base.ViewModel;
using Starfront.PierWatch.Services;
using Starfront.PierWatch.Settings;

namespace Starfront.PierWatch.Ui {

    /// <summary>
    /// The panel on the Imaging tab: the live picture, what the camera makes
    /// of it, what the mount claims, and the buttons - watch on and off,
    /// file this pose, survey, clear a trip.
    /// </summary>
    [Export(typeof(IDockableVM))]
    public class PierWatchDockVM : DockableVM {
        private readonly ITelescopeMediator telescopeMediator;
        private CancellationTokenSource survey;
        private string surveyText = "";
        private string message = "";

        [ImportingConstructor]
        public PierWatchDockVM(IProfileService profileService, ITelescopeMediator telescopeMediator) : base(profileService) {
            this.telescopeMediator = telescopeMediator;
            Runtime.Ensure(profileService, telescopeMediator);
            Title = "Pier Watch";
            try {
                if (Application.Current?.Resources["Starfront_PierWatchSVG"] is GeometryGroup geometry) ImageGeometry = geometry;
            } catch (Exception) { }

            WatchCommand = new RelayCommand(() => {
                if (Watcher == null) return;
                if (string.IsNullOrWhiteSpace(Settings.CameraUrl)) {
                    Message = "Set the pier camera's address in Options > Plugins > Starfront Pier Watch first.";
                    return;
                }
                if (Watcher.Watching) Watcher.Stop(); else Watcher.Start();
                Message = "";
            });
            LearnCommand = new AsyncRelayCommand(LearnAsync);
            ClearTripCommand = new RelayCommand(() => Watcher?.ClearTrip());
            ClearMapCommand = new RelayCommand(() => {
                Watcher?.ClearMap();
                Message = "The map was cleared; the watch will learn again from here.";
            });
            SurveyCommand = new AsyncRelayCommand(SurveyAsync, () => survey == null);
            CancelSurveyCommand = new RelayCommand(() => survey?.Cancel(), () => survey != null);
        }

        public PierWatchSettings Settings => Runtime.Settings;
        public PierWatcher Watcher => Runtime.Watcher;

        public RelayCommand WatchCommand { get; }
        public AsyncRelayCommand LearnCommand { get; }
        public RelayCommand ClearTripCommand { get; }
        public RelayCommand ClearMapCommand { get; }
        public AsyncRelayCommand SurveyCommand { get; }
        public RelayCommand CancelSurveyCommand { get; }

        public string Message { get => message; private set { message = value ?? ""; RaisePropertyChanged(); } }
        public string SurveyText { get => surveyText; private set { surveyText = value ?? ""; RaisePropertyChanged(); } }
        public bool Surveying => survey != null;

        private async Task LearnAsync() {
            if (Watcher == null) return;
            try {
                var filed = await Watcher.LearnNowAsync(CancellationToken.None);
                Message = filed
                    ? $"Filed this picture under {Watcher.LastClaim.Pose}; the map holds {Watcher.SampleCount}."
                    : "Nothing filed: the mount is not connected, so there is no pose to file it under.";
            } catch (Exception ex) {
                Message = "Could not file the picture: " + ex.Message;
            }
        }

        private async Task SurveyAsync() {
            if (Watcher == null || survey != null) return;
            var settings = Settings;
            if (string.IsNullOrWhiteSpace(settings.CameraUrl)) {
                Message = "Set the pier camera's address in Options first.";
                return;
            }
            survey = new CancellationTokenSource();
            RaisePropertyChanged(nameof(Surveying));
            SurveyCommand.NotifyCanExecuteChanged();
            CancelSurveyCommand.NotifyCanExecuteChanged();
            var progress = new Progress<ApplicationStatus>(status => SurveyText = status?.Status ?? "");
            try {
                var grid = Surveyor.Grid(settings.Latitude, settings.HorizonLimit, settings.PastMeridianHours, 15);
                SurveyText = $"surveying {grid.Count} poses…";
                var learned = await Surveyor.RunAsync(Watcher, telescopeMediator, settings.Longitude, grid, 3, progress, survey.Token);
                SurveyText = $"survey done: {learned} of {grid.Count} poses filed; the map holds {Watcher.SampleCount}";
                Notification.ShowSuccess("Pier Watch: " + SurveyText);
            } catch (OperationCanceledException) {
                SurveyText = "survey cancelled";
            } catch (Exception ex) {
                SurveyText = "survey failed: " + ex.Message;
                Logger.Error("Pier Watch survey failed", ex);
            } finally {
                survey.Dispose();
                survey = null;
                RaisePropertyChanged(nameof(Surveying));
                SurveyCommand.NotifyCanExecuteChanged();
                CancelSurveyCommand.NotifyCanExecuteChanged();
            }
        }
    }
}
