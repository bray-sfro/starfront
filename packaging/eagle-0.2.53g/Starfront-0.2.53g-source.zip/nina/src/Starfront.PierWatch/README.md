# Starfront Pier Watch

A N.I.N.A. plugin that reads the camera watching your telescope as a second,
independent position encoder, and stops the mount when the picture says it is
heading below the horizon, past the pier, or somewhere the driver does not
think it is.

## Why

A mount knows where it is only by counting from wherever it was told it
started. Lose a sync, miss a flip, nudge it by hand, and it will drive the
telescope into the pier or below the horizon while reporting a perfectly good
position. A camera pointed at the rig sees the truth.

## How it works

Every second the plugin takes a picture from the pier camera and reduces it to
a small grey thumbnail, then to a vector that ignores brightness and contrast
(each pixel less its neighbourhood's mean, zero mean, unit length). Two
pictures are compared by the dot product of their vectors: their correlation.

While the driver reports the mount sitting still, the picture is filed under
the mount's *pose* - hour angle, declination and side of pier - so the plugin
builds a map of what the telescope looks like everywhere it has been. Hour
angle, not right ascension, because the camera sees the mount's axes, and a
pose learned at midnight means the same thing at dawn. Each new picture is
matched against the map; the best match is the camera's estimate, with a score
and the score of the best rival elsewhere on the sky.

The *Survey the pier camera* instruction, or the panel's *Survey the sky*
button, builds the map in one go: a grid of poses above the horizon limit and
within the meridian limit, about a hundred positions and ten minutes at the
default 15° step. After that it keeps learning on its own.

## The rules

On every picture, the estimate and the driver's own report are checked:

1. **Horizon.** The telescope must be above the altitude limit.
2. **Pier.** A tube on the west side of the pier may not track more than the
   limit past the meridian; one on the east side may not sit more than the
   limit short of it. Set this a little over the limit in the mount's own
   driver, so the plugin steps in only when the driver has not.
3. **Disagreement.** When the camera is sure (match above the trust score and
   clearly better than any rival) and puts the mount further from the driver's
   position than the limit, or on the other side of the pier, the driver has
   lost its place.

A rule broken on two pictures in a row (configurable) stops the slew, switches
tracking off, raises a N.I.N.A. notification, and *trips*. The trip stays
until you clear it on the panel, after looking at the telescope; while tripped,
every confirmed violation stops the mount again. A picture the map does not
recognise is reported as unsure and nothing is done, unless the option to stop
on unrecognised pictures is on.

## Where it plugs in

- **Imaging tab panel** - the live picture, the verdict, the camera's and the
  driver's positions, the map's size, and the buttons.
- **Options > Plugins > Starfront Pier Watch** - the camera address, the crop,
  the limits, what to do, and when to learn.
- **Safety monitor** - *Pier Watch (Starfront)* appears among the safety
  monitors; it is unsafe while tripped or while the last picture broke a rule,
  so *Loop while safe* and the safety triggers act on it. A watch that is
  switched off reports safe: it vouches for nothing.
- **Sequencer** - the *Pier Watch guard* trigger ends the advanced sequence
  when the watch trips (the mount is already stopped); *Survey the pier camera*
  builds the map.

## The camera

Any HTTP snapshot URL (`http://user:password@camera/snapshot.jpg`) or MJPEG
stream will do; the plugin takes one picture at a time and keeps no connection
open. Starfront's own pier camera answers at
`http://<starfront pc>:<port>/api/piercam/frame.png`.

## Building

```
dotnet build src/Starfront.PierWatch/Starfront.PierWatch.csproj -c Release -t:DeployPlugin
dotnet test  src/Starfront.PierWatch.Tests/Starfront.PierWatch.Tests.csproj -c Release
dotnet msbuild src/Starfront.PierWatch/Starfront.PierWatch.csproj -t:PackagePlugin -p:Configuration=Release "-p:PluginInstallerUrl=https://collab.starfront.space/nina/download/Starfront.PierWatch.<version>.zip"
```

Identity and manifest metadata come from `PierWatch.props`; the shared build
scripts in `build/` take the props file from the project's `PluginPropsFile`.
