using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace Starfront.PierWatch.Vision {

    /// <summary>
    /// One picture from the pier camera, over HTTP.
    ///
    /// Two kinds of camera answer a URL: one that hands back a still (a
    /// snapshot URL, which nearly every IP camera has, and Starfront's own
    /// feed), and one that streams MJPEG - a never-ending multipart body of
    /// JPEGs. The second is read just far enough to take one whole JPEG out
    /// of it and then dropped, so a stream is just a slow way of asking for
    /// a still. Nothing here keeps a connection open between pictures.
    /// </summary>
    public sealed class FrameSource : IDisposable {
        /// <summary>A still larger than this is not a pier camera picture.</summary>
        public const int MaxBytes = 24 * 1024 * 1024;

        private readonly HttpClient http;

        public FrameSource(TimeSpan? timeout = null) {
            http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = true }) {
                Timeout = timeout ?? TimeSpan.FromSeconds(10),
            };
            http.DefaultRequestHeaders.UserAgent.ParseAdd("StarfrontPierWatch/1.0");
        }

        /// <summary>The bytes of one picture, as the camera encoded it.</summary>
        public async Task<byte[]> FetchAsync(string url, CancellationToken token) {
            if (string.IsNullOrWhiteSpace(url)) throw new InvalidOperationException("no camera address is set");
            if (!Uri.TryCreate(url.Trim(), UriKind.Absolute, out var uri)
                    || (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps)) {
                throw new InvalidOperationException("the camera address must be an http or https URL");
            }
            using var request = new HttpRequestMessage(HttpMethod.Get, Strip(uri));
            // user:password@host in the address, the way IP cameras are
            // usually written down, becomes the authorisation header.
            if (!string.IsNullOrEmpty(uri.UserInfo)) {
                var raw = Uri.UnescapeDataString(uri.UserInfo);
                request.Headers.Authorization = new AuthenticationHeaderValue(
                    "Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes(raw)));
            }
            using var response = await http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, token).ConfigureAwait(false);
            if (!response.IsSuccessStatusCode) {
                throw new InvalidOperationException($"the camera answered {(int)response.StatusCode} {response.ReasonPhrase}");
            }
            var mediaType = response.Content.Headers.ContentType?.MediaType ?? "";
            using var stream = await response.Content.ReadAsStreamAsync(token).ConfigureAwait(false);
            if (mediaType.StartsWith("multipart/", StringComparison.OrdinalIgnoreCase)) {
                return await OneJpegFromStream(stream, token).ConfigureAwait(false);
            }
            using var buffer = new MemoryStream();
            var chunk = new byte[64 * 1024];
            int read;
            while ((read = await stream.ReadAsync(chunk, token).ConfigureAwait(false)) > 0) {
                buffer.Write(chunk, 0, read);
                if (buffer.Length > MaxBytes) throw new InvalidOperationException("the camera's picture is too large");
            }
            if (buffer.Length == 0) throw new InvalidOperationException("the camera sent an empty picture");
            return buffer.ToArray();
        }

        /// <summary>
        /// The first complete JPEG in a stream: from its start marker (FF D8)
        /// to its end marker (FF D9). The multipart headers around it are
        /// skipped by looking for the markers rather than parsing boundaries,
        /// which cameras get wrong more often than they get JPEG wrong.
        /// </summary>
        public static async Task<byte[]> OneJpegFromStream(Stream stream, CancellationToken token) {
            using var buffer = new MemoryStream();
            var chunk = new byte[16 * 1024];
            var start = -1;
            while (true) {
                var read = await stream.ReadAsync(chunk, token).ConfigureAwait(false);
                if (read <= 0) throw new InvalidOperationException("the stream ended before a whole picture arrived");
                buffer.Write(chunk, 0, read);
                var data = buffer.GetBuffer();
                var length = (int)buffer.Length;
                if (start < 0) start = IndexOf(data, length, 0, 0xFF, 0xD8);
                if (start >= 0) {
                    var end = IndexOf(data, length, start + 2, 0xFF, 0xD9);
                    if (end >= 0) {
                        var jpeg = new byte[end + 2 - start];
                        Array.Copy(data, start, jpeg, 0, jpeg.Length);
                        return jpeg;
                    }
                }
                if (length > MaxBytes) throw new InvalidOperationException("no picture found in the stream");
            }
        }

        private static int IndexOf(byte[] data, int length, int from, byte a, byte b) {
            for (var i = Math.Max(0, from); i + 1 < length; i++) {
                if (data[i] == a && data[i + 1] == b) return i;
            }
            return -1;
        }

        private static Uri Strip(Uri uri) {
            if (string.IsNullOrEmpty(uri.UserInfo)) return uri;
            var builder = new UriBuilder(uri) { UserName = "", Password = "" };
            return builder.Uri;
        }

        public void Dispose() => http.Dispose();
    }
}
