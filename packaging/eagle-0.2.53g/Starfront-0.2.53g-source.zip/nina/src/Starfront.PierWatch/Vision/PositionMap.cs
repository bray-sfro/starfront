using System.IO;
using Newtonsoft.Json;

namespace Starfront.PierWatch.Vision {

    /// <summary>Which side of the pier the tube hangs on, as the mount reports it.</summary>
    public enum Side { Unknown = -1, East = 0, West = 1 }

    /// <summary>A physical pose of the mount: the two axes and the side of pier.</summary>
    public readonly record struct Pose(double HourAngle, double Declination, Side PierSide) {
        public double SeparationFrom(Pose other) =>
            SkyGeometry.Separation(HourAngle, Declination, other.HourAngle, other.Declination);

        public override string ToString() {
            var side = PierSide switch { Side.East => "east", Side.West => "west", _ => "unknown side" };
            return $"HA {HourAngle:+0.00;-0.00}h  Dec {Declination:+0.0;-0.0}°  {side}";
        }
    }

    /// <summary>One picture filed under the pose the mount was at when it was taken.</summary>
    public sealed class PoseSample {
        public double HourAngle { get; set; }
        public double Declination { get; set; }
        public Side PierSide { get; set; } = Side.Unknown;
        public DateTime TakenUtc { get; set; }
        public byte[] Gray { get; set; } = Array.Empty<byte>();

        [JsonIgnore]
        public Pose Pose => new(HourAngle, Declination, PierSide);

        private Fingerprint fingerprint;

        public Fingerprint Fingerprint(int width, int height) =>
            fingerprint ??= new Fingerprint(width, height, Gray);
    }

    /// <summary>What a picture was matched to, and how surely.</summary>
    public sealed record Match(PoseSample Best, double Score, double Rival) {
        /// <summary>The best score among samples far from the best one: a high rival means the picture could be either.</summary>
        public double Margin => Score - Rival;
    }

    /// <summary>
    /// Every picture the plugin has filed, keyed by pose - the encoder's
    /// calibration table.
    ///
    /// Kept deliberately simple: a flat list searched in full on every
    /// picture. A few thousand thumbnails of three thousand pixels is ten
    /// million multiplications, which is nothing once a second, and a flat
    /// list has no index to get out of step with its contents.
    /// </summary>
    public sealed class PositionMap {
        /// <summary>Poses this close on the sky, on the same side, are the same place.</summary>
        public const double SamePlaceDegrees = 1.5;

        /// <summary>A picture this alike to one already filed at the same place replaces it.</summary>
        public const double SamePictureScore = 0.97;

        /// <summary>Samples at least this far from the best match count as rivals for the margin.</summary>
        public const double RivalDegrees = 8.0;

        /// <summary>Beyond this the oldest samples go, so the map tracks a rig that changes over years.</summary>
        public const int MaxSamples = 4000;

        private readonly object gate = new();
        private readonly List<PoseSample> samples = new();

        public PositionMap(int width, int height) {
            Width = width;
            Height = height;
        }

        public int Width { get; }
        public int Height { get; }

        public int Count { get { lock (gate) return samples.Count; } }

        public IReadOnlyList<PoseSample> Snapshot() { lock (gate) return samples.ToList(); }

        /// <summary>
        /// File a picture under a pose. A near-identical picture already filed
        /// at the same place is replaced rather than joined, so sitting on a
        /// target all night adds one sample, not a thousand; a different
        /// picture at the same place (the Moon up, a lamp on) is kept beside
        /// it, because both are what that pose can look like.
        /// </summary>
        public void Add(PoseSample sample) {
            if (sample.Gray == null || sample.Gray.Length != Width * Height) {
                throw new ArgumentException("the sample's thumbnail is not the map's size");
            }
            lock (gate) {
                var print = sample.Fingerprint(Width, Height);
                for (var i = 0; i < samples.Count; i++) {
                    var existing = samples[i];
                    if (existing.PierSide != sample.PierSide) continue;
                    if (existing.Pose.SeparationFrom(sample.Pose) > SamePlaceDegrees) continue;
                    if (existing.Fingerprint(Width, Height).Correlate(print) >= SamePictureScore) {
                        samples[i] = sample;
                        return;
                    }
                }
                samples.Add(sample);
                while (samples.Count > MaxSamples) samples.RemoveAt(0);
            }
        }

        /// <summary>The filed picture most like this one, or null for an empty map.</summary>
        public Match Find(Fingerprint print) {
            lock (gate) {
                if (samples.Count == 0) return null;
                PoseSample best = null;
                var bestScore = double.NegativeInfinity;
                var scores = new double[samples.Count];
                for (var i = 0; i < samples.Count; i++) {
                    scores[i] = samples[i].Fingerprint(Width, Height).Correlate(print);
                    if (scores[i] > bestScore) {
                        bestScore = scores[i];
                        best = samples[i];
                    }
                }
                var rival = double.NegativeInfinity;
                for (var i = 0; i < samples.Count; i++) {
                    var sample = samples[i];
                    var elsewhere = sample.PierSide != best.PierSide
                                    || sample.Pose.SeparationFrom(best.Pose) >= RivalDegrees;
                    if (elsewhere && scores[i] > rival) rival = scores[i];
                }
                if (double.IsNegativeInfinity(rival)) rival = -1.0;
                return new Match(best, bestScore, rival);
            }
        }

        public void Clear() { lock (gate) samples.Clear(); }

        // -- on disk ---------------------------------------------------------

        private sealed class MapFile {
            public int Version { get; set; } = 1;
            public int Width { get; set; }
            public int Height { get; set; }
            public List<PoseSample> Samples { get; set; } = new();
        }

        public void Save(string path) {
            MapFile file;
            lock (gate) {
                file = new MapFile { Width = Width, Height = Height, Samples = samples.ToList() };
            }
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            var temporary = path + ".tmp";
            File.WriteAllText(temporary, JsonConvert.SerializeObject(file));
            File.Move(temporary, path, true);
        }

        /// <summary>
        /// A map read back from disk, sized as the file says. Null when there
        /// is no file, and when the file cannot be read - which is logged by
        /// the caller, not fatal: the plugin starts with an empty map and
        /// learns again.
        /// </summary>
        public static PositionMap Load(string path) {
            if (!File.Exists(path)) return null;
            var file = JsonConvert.DeserializeObject<MapFile>(File.ReadAllText(path));
            if (file == null || file.Width <= 0 || file.Height <= 0) return null;
            var map = new PositionMap(file.Width, file.Height);
            foreach (var sample in file.Samples ?? new List<PoseSample>()) {
                if (sample.Gray != null && sample.Gray.Length == map.Width * map.Height) map.samples.Add(sample);
            }
            return map;
        }
    }
}
