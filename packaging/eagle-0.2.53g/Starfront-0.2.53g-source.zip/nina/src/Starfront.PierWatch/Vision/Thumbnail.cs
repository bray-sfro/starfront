using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Starfront.PierWatch.Vision {

    /// <summary>The part of the picture that has the telescope in it, as fractions of the frame.</summary>
    public readonly record struct Crop(double Left, double Top, double Width, double Height) {
        public static readonly Crop Whole = new(0, 0, 1, 1);

        /// <summary>A crop kept inside the frame and at least a few pixels across.</summary>
        public Crop Sane() {
            var left = Math.Clamp(double.IsFinite(Left) ? Left : 0, 0, 0.95);
            var top = Math.Clamp(double.IsFinite(Top) ? Top : 0, 0, 0.95);
            var width = Math.Clamp(double.IsFinite(Width) ? Width : 1, 0.05, 1 - left);
            var height = Math.Clamp(double.IsFinite(Height) ? Height : 1, 0.05, 1 - top);
            return new Crop(left, top, width, height);
        }
    }

    /// <summary>
    /// A picture reduced to what matters for recognising a pose: a small
    /// grey thumbnail, and from it a vector that ignores how bright the
    /// scene is.
    ///
    /// The thumbnail is what gets stored, as bytes. The vector is worked
    /// out from it: each pixel less the mean of its neighbourhood, so a
    /// lamp coming on or the Moon rising - which lift whole regions of the
    /// picture together - change it far less than the telescope moving,
    /// which moves edges; then zero mean and unit length, so the dot product
    /// of two vectors is their correlation, 1 for the same picture and
    /// about 0 for unrelated ones.
    /// </summary>
    public sealed class Fingerprint {
        /// <summary>Half-width of the neighbourhood whose mean is taken off each pixel.</summary>
        public const int LocalRadius = 3;

        private float[] vector;

        public Fingerprint(int width, int height, byte[] gray) {
            if (width <= 0 || height <= 0) throw new ArgumentException("a fingerprint needs a size");
            if (gray == null || gray.Length != width * height) throw new ArgumentException("the thumbnail does not match its size");
            Width = width;
            Height = height;
            Gray = gray;
        }

        public int Width { get; }
        public int Height { get; }

        /// <summary>The thumbnail itself, row by row, 0 black to 255 white.</summary>
        public byte[] Gray { get; }

        /// <summary>The comparable form: local contrast, zero mean, unit length. All zero for a featureless picture.</summary>
        public float[] Vector => vector ??= Build(Width, Height, Gray);

        /// <summary>How alike two pictures are, -1..1; -1 as well for pictures of different sizes.</summary>
        public double Correlate(Fingerprint other) {
            if (other == null || other.Width != Width || other.Height != Height) return -1.0;
            var a = Vector;
            var b = other.Vector;
            double sum = 0;
            for (var i = 0; i < a.Length; i++) sum += a[i] * b[i];
            return Math.Clamp(sum, -1.0, 1.0);
        }

        private static float[] Build(int width, int height, byte[] gray) {
            var n = width * height;
            var local = new float[n];
            // Box mean over (2r+1)^2 via a summed-area table, so the cost does
            // not grow with the radius.
            var sat = new long[(width + 1) * (height + 1)];
            for (var y = 1; y <= height; y++) {
                long row = 0;
                for (var x = 1; x <= width; x++) {
                    row += gray[(y - 1) * width + (x - 1)];
                    sat[y * (width + 1) + x] = sat[(y - 1) * (width + 1) + x] + row;
                }
            }
            var r = LocalRadius;
            for (var y = 0; y < height; y++) {
                var y0 = Math.Max(0, y - r);
                var y1 = Math.Min(height - 1, y + r);
                for (var x = 0; x < width; x++) {
                    var x0 = Math.Max(0, x - r);
                    var x1 = Math.Min(width - 1, x + r);
                    var area = (x1 - x0 + 1) * (y1 - y0 + 1);
                    var sum = sat[(y1 + 1) * (width + 1) + (x1 + 1)] - sat[y0 * (width + 1) + (x1 + 1)]
                            - sat[(y1 + 1) * (width + 1) + x0] + sat[y0 * (width + 1) + x0];
                    local[y * width + x] = gray[y * width + x] - (float)sum / area;
                }
            }
            double mean = 0;
            foreach (var v in local) mean += v;
            mean /= n;
            double norm = 0;
            for (var i = 0; i < n; i++) {
                local[i] -= (float)mean;
                norm += (double)local[i] * local[i];
            }
            norm = Math.Sqrt(norm);
            if (norm < 1e-6) return new float[n];           // a blank picture matches nothing
            for (var i = 0; i < n; i++) local[i] = (float)(local[i] / norm);
            return local;
        }
    }

    /// <summary>Pictures in, thumbnails out.</summary>
    public static class Thumbnails {
        /// <summary>Decode an image file's bytes (JPEG, PNG, BMP...) into a frozen bitmap.</summary>
        public static BitmapSource Decode(byte[] bytes) {
            using var stream = new MemoryStream(bytes);
            var decoder = BitmapDecoder.Create(stream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
            BitmapSource frame = decoder.Frames[0];
            if (frame.CanFreeze && !frame.IsFrozen) frame.Freeze();
            return frame;
        }

        /// <summary>The picture as 8-bit grey, row by row, with its size.</summary>
        public static (byte[] Gray, int Width, int Height) ToGray(BitmapSource image) {
            BitmapSource gray = image.Format == PixelFormats.Gray8
                ? image
                : new FormatConvertedBitmap(image, PixelFormats.Gray8, null, 0);
            var width = gray.PixelWidth;
            var height = gray.PixelHeight;
            var pixels = new byte[width * height];
            gray.CopyPixels(pixels, width, 0);
            return (pixels, width, height);
        }

        /// <summary>
        /// Crop a grey picture and shrink it to the thumbnail size by
        /// averaging, so every source pixel counts once and noise averages
        /// out rather than being sampled.
        /// </summary>
        public static Fingerprint Reduce(byte[] gray, int width, int height, Crop crop, int outWidth, int outHeight) {
            crop = crop.Sane();
            var cx = (int)Math.Round(crop.Left * width);
            var cy = (int)Math.Round(crop.Top * height);
            var cw = Math.Max(1, (int)Math.Round(crop.Width * width));
            var ch = Math.Max(1, (int)Math.Round(crop.Height * height));
            cx = Math.Clamp(cx, 0, width - 1);
            cy = Math.Clamp(cy, 0, height - 1);
            cw = Math.Min(cw, width - cx);
            ch = Math.Min(ch, height - cy);

            var output = new byte[outWidth * outHeight];
            for (var oy = 0; oy < outHeight; oy++) {
                var y0 = cy + (int)((long)oy * ch / outHeight);
                var y1 = cy + (int)((long)(oy + 1) * ch / outHeight);
                if (y1 <= y0) y1 = y0 + 1;
                for (var ox = 0; ox < outWidth; ox++) {
                    var x0 = cx + (int)((long)ox * cw / outWidth);
                    var x1 = cx + (int)((long)(ox + 1) * cw / outWidth);
                    if (x1 <= x0) x1 = x0 + 1;
                    long sum = 0;
                    var count = 0;
                    for (var y = y0; y < y1 && y < height; y++) {
                        var row = y * width;
                        for (var x = x0; x < x1 && x < width; x++) {
                            sum += gray[row + x];
                            count++;
                        }
                    }
                    output[oy * outWidth + ox] = (byte)(count == 0 ? 0 : sum / count);
                }
            }
            return new Fingerprint(outWidth, outHeight, output);
        }

        /// <summary>The whole reduction, from file bytes to fingerprint.</summary>
        public static Fingerprint FromImageBytes(byte[] bytes, Crop crop, int outWidth, int outHeight) {
            var (gray, width, height) = ToGray(Decode(bytes));
            return Reduce(gray, width, height, crop, outWidth, outHeight);
        }
    }
}
