namespace Starfront.PierWatch.Vision {

    /// <summary>
    /// Where a mount pointing is on the sky, worked from the mount's own
    /// axes rather than the clock.
    ///
    /// The thing the camera sees is the mount's *physical pose*: how far
    /// the polar axis has turned (the hour angle) and how far the
    /// declination axis has (the declination), and which side of the pier
    /// the tube hangs on. Altitude is a function of those and the latitude
    /// alone, so a pose learned at midnight means the same thing at dawn,
    /// which is why the map is keyed on hour angle and never on right
    /// ascension.
    /// </summary>
    public static class SkyGeometry {
        private const double Rad = Math.PI / 180.0;

        /// <summary>An hour angle into -12..12, so east is negative and west positive.</summary>
        public static double NormaliseHours(double hours) {
            var h = hours % 24.0;
            if (h < -12.0) h += 24.0;
            if (h >= 12.0) h -= 24.0;
            return h;
        }

        /// <summary>The hour angle of a right ascension at a sidereal time, both in hours.</summary>
        public static double HourAngle(double siderealHours, double rightAscensionHours) =>
            NormaliseHours(siderealHours - rightAscensionHours);

        /// <summary>Altitude and azimuth in degrees of a pose at a latitude; azimuth from north through east.</summary>
        public static (double Altitude, double Azimuth) AltAz(double hourAngleHours, double declinationDeg, double latitudeDeg) {
            var ha = hourAngleHours * 15.0 * Rad;
            var dec = declinationDeg * Rad;
            var lat = latitudeDeg * Rad;
            var sinAlt = Math.Sin(dec) * Math.Sin(lat) + Math.Cos(dec) * Math.Cos(lat) * Math.Cos(ha);
            var alt = Math.Asin(Math.Clamp(sinAlt, -1.0, 1.0));
            var y = -Math.Sin(ha) * Math.Cos(dec);
            var x = Math.Sin(dec) * Math.Cos(lat) - Math.Cos(dec) * Math.Sin(lat) * Math.Cos(ha);
            var az = Math.Atan2(y, x) / Rad;
            if (az < 0) az += 360.0;
            return (alt / Rad, az);
        }

        /// <summary>
        /// The angle in degrees between two poses, as the tube would have to
        /// swing between them. Side of pier is not part of it: the same sky
        /// position on the other side is a different pose, and the caller
        /// compares sides for itself.
        /// </summary>
        public static double Separation(double ha1Hours, double dec1Deg, double ha2Hours, double dec2Deg) {
            var d1 = dec1Deg * Rad;
            var d2 = dec2Deg * Rad;
            var dha = (ha1Hours - ha2Hours) * 15.0 * Rad;
            var cos = Math.Sin(d1) * Math.Sin(d2) + Math.Cos(d1) * Math.Cos(d2) * Math.Cos(dha);
            return Math.Acos(Math.Clamp(cos, -1.0, 1.0)) / Rad;
        }
    }
}
