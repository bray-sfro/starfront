using System.ComponentModel.Composition;
using CommunityToolkit.Mvvm.Input;
using RelayCommand = CommunityToolkit.Mvvm.Input.RelayCommand;
using NINA.Core.Utility;
using NINA.Equipment.Interfaces.Mediator;
using NINA.Plugin;
using NINA.Plugin.Interfaces;
using NINA.Profile.Interfaces;
using Starfront.PierWatch.Services;
using Starfront.PierWatch.Settings;

namespace Starfront.PierWatch {

    /// <summary>
    /// The plugin as N.I.N.A. sees it: identity from the assembly attributes
    /// (generated from PierWatch.props), and the data context of the options
    /// page. The watcher itself lives in <see cref="Runtime"/>, shared with
    /// the dock panel, the safety monitor and the sequencer items.
    /// </summary>
    [Export(typeof(IPluginManifest))]
    public class Plugin : PluginBase, System.ComponentModel.INotifyPropertyChanged {
        private string cameraTest = "";

        [ImportingConstructor]
        public Plugin(IProfileService profileService, ITelescopeMediator telescopeMediator) {
            Runtime.Ensure(profileService, telescopeMediator);
            TestCameraCommand = new AsyncRelayCommand(TestCameraAsync);
            ClearMapCommand = new RelayCommand(() => Runtime.Watcher?.ClearMap());
            WatchCommand = new RelayCommand(() => {
                if (Runtime.Watcher == null) return;
                if (Runtime.Watcher.Watching) Runtime.Watcher.Stop(); else Runtime.Watcher.Start();
            });
            ClearTripCommand = new RelayCommand(() => Runtime.Watcher?.ClearTrip());
        }

        public override Task Initialize() {
            Runtime.Start();
            Logger.Info($"Pier Watch plugin {Version} initialised");
            return Task.CompletedTask;
        }

        public override Task Teardown() {
            Runtime.Shutdown();
            return Task.CompletedTask;
        }

        // -- what the options page binds to ------------------------------------

        public PierWatchSettings Settings => Runtime.Settings;
        public PierWatcher Watcher => Runtime.Watcher;

        public AsyncRelayCommand TestCameraCommand { get; }
        public RelayCommand ClearMapCommand { get; }
        public RelayCommand WatchCommand { get; }
        public RelayCommand ClearTripCommand { get; }

        /// <summary>What the last Test said: the picture's size, or the error.</summary>
        public string CameraTest {
            get => cameraTest;
            private set { cameraTest = value ?? ""; RaisePropertyChanged(); }
        }

        private async Task TestCameraAsync() {
            if (Runtime.Watcher == null) return;
            CameraTest = "asking the camera…";
            CameraTest = await Runtime.Watcher.TestCameraAsync(CancellationToken.None);
        }

        // PluginBase has no property-change notification of its own; the
        // options page is a plain data template, so a manual event does.
        private void RaisePropertyChanged(string name = null) =>
            PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(name));

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;
    }
}
