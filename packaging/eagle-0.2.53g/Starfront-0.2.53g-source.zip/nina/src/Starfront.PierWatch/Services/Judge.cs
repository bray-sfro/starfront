using Starfront.PierWatch.Vision;

namespace Starfront.PierWatch.Services {

    /// <summary>What the mount's driver says about where it is. Unknown while nothing is connected.</summary>
    public readonly record struct Claim(Pose Pose, bool Known) {
        public static readonly Claim None = new(default, false);
    }

    /// <summary>What the camera says, and how surely: the best match's pose and score, and the best rival's score.</summary>
    public readonly record struct Estimate(Pose Pose, double Score, double Rival, bool Known) {
        public static readonly Estimate None = new(default, -1, -1, false);
        public double Margin => Score - Rival;
    }

    /// <summary>The lines the mount must not cross, and how sure the camera has to be before it is believed.</summary>
    public sealed record Limits(
        double HorizonDegrees,
        double PastMeridianHours,
        double TrustScore,
        double TrustMargin,
        double DisagreeDegrees,
        bool StopWhenUnrecognised,
        double LatitudeDegrees);

    public enum Verdict { Safe, Unsure, Violation }

    /// <summary>The decision about one picture, with the sentence that explains it.</summary>
    public sealed record Judgement(Verdict Verdict, string Reason, bool CameraTrusted, double? CameraAltitude, double? MountAltitude);

    /// <summary>
    /// The rules, kept apart from the camera and the mount so they can be
    /// read in one place and tested with made-up numbers.
    ///
    /// Three lines a telescope must not cross: the horizon limit (a tube
    /// pointing into the ground is on its way into the pier or the dome);
    /// the meridian limit on the wrong side of the pier (a tube on the west
    /// side tracking on past the meridian is what a pier crash is); and the
    /// line between the camera's opinion and the driver's (when the camera
    /// is sure the mount is somewhere else, the driver has lost its place,
    /// and everything it will do next is wrong).
    ///
    /// The camera is believed only when its best match is both good and
    /// clearly better than any match elsewhere on the sky. A weak match
    /// means the picture is one the map has not seen - cloud over the
    /// lamp, a new cable, or a pose nobody has visited - and that is only a
    /// fault if the operator has said so.
    /// </summary>
    public static class Judge {
        public static Judgement Decide(Estimate camera, Claim mount, Limits limits) {
            var trusted = camera.Known && camera.Score >= limits.TrustScore && camera.Margin >= limits.TrustMargin;
            double? cameraAlt = trusted
                ? SkyGeometry.AltAz(camera.Pose.HourAngle, camera.Pose.Declination, limits.LatitudeDegrees).Altitude
                : null;
            double? mountAlt = mount.Known
                ? SkyGeometry.AltAz(mount.Pose.HourAngle, mount.Pose.Declination, limits.LatitudeDegrees).Altitude
                : null;

            // The driver's own report first: a driver that says it is below
            // the horizon needs no second opinion to be stopped.
            if (mount.Known) {
                if (mountAlt < limits.HorizonDegrees) {
                    return new Judgement(Verdict.Violation,
                        $"the mount reports {mountAlt:0}° altitude, below the {limits.HorizonDegrees:0}° horizon limit",
                        trusted, cameraAlt, mountAlt);
                }
                var past = PastLimit(mount.Pose, limits.PastMeridianHours);
                if (past != null) {
                    return new Judgement(Verdict.Violation, "the mount reports " + past, trusted, cameraAlt, mountAlt);
                }
            }

            if (trusted) {
                if (cameraAlt < limits.HorizonDegrees) {
                    return new Judgement(Verdict.Violation,
                        $"the camera sees the telescope at {cameraAlt:0}° altitude, below the {limits.HorizonDegrees:0}° horizon limit",
                        true, cameraAlt, mountAlt);
                }
                var past = PastLimit(camera.Pose, limits.PastMeridianHours);
                if (past != null) {
                    return new Judgement(Verdict.Violation, "the camera sees " + past, true, cameraAlt, mountAlt);
                }
                if (mount.Known) {
                    var apart = camera.Pose.SeparationFrom(mount.Pose);
                    var sides = camera.Pose.PierSide != Side.Unknown && mount.Pose.PierSide != Side.Unknown
                                && camera.Pose.PierSide != mount.Pose.PierSide;
                    if (apart > limits.DisagreeDegrees || sides) {
                        var where = sides ? "on the other side of the pier from" : $"{apart:0}° from";
                        return new Judgement(Verdict.Violation,
                            $"the camera puts the telescope {where} where the mount says it is " +
                            $"(camera {camera.Pose}; mount {mount.Pose}) - the mount has lost its place",
                            true, cameraAlt, mountAlt);
                    }
                    return new Judgement(Verdict.Safe,
                        $"camera and mount agree: {camera.Pose}, {cameraAlt:0}° up (match {camera.Score:0.00})",
                        true, cameraAlt, mountAlt);
                }
                return new Judgement(Verdict.Safe,
                    $"the camera sees {camera.Pose}, {cameraAlt:0}° up (match {camera.Score:0.00}); no mount connected",
                    true, cameraAlt, mountAlt);
            }

            // Not trusted: the picture is one the map does not know well.
            var why = !camera.Known
                ? "the map is empty - nothing has been learned yet"
                : camera.Score < limits.TrustScore
                    ? $"the camera does not recognise this picture (best match {camera.Score:0.00}, needs {limits.TrustScore:0.00})"
                    : $"the picture could be more than one place (match {camera.Score:0.00}, a rival at {camera.Rival:0.00})";
            if (limits.StopWhenUnrecognised && camera.Known) {
                return new Judgement(Verdict.Violation, why + " - stopping, as set", false, null, mountAlt);
            }
            return new Judgement(Verdict.Unsure, why, false, null, mountAlt);
        }

        /// <summary>The sentence for a pose past the meridian limit on its side, or null if it is within it.</summary>
        private static string PastLimit(Pose pose, double limitHours) {
            if (limitHours <= 0) return null;
            if (pose.PierSide == Side.West && pose.HourAngle > limitHours) {
                return $"the telescope on the west side {pose.HourAngle:0.00}h past the meridian, over the {limitHours:0.00}h limit - heading for the pier";
            }
            if (pose.PierSide == Side.East && pose.HourAngle < -limitHours) {
                return $"the telescope on the east side {-pose.HourAngle:0.00}h short of the meridian, over the {limitHours:0.00}h limit - heading for the pier";
            }
            return null;
        }
    }
}
