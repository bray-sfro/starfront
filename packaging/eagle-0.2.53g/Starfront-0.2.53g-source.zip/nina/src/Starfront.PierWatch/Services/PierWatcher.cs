using System.Windows.Media.Imaging;
using NINA.Core.Enum;
using NINA.Core.Utility;
using NINA.Core.Utility.Notification;
using NINA.Equipment.Equipment.MyTelescope;
using NINA.Equipment.Interfaces.Mediator;
using Starfront.PierWatch.Settings;
using Starfront.PierWatch.Vision;

namespace Starfront.PierWatch.Services {

    /// <summary>
    /// The encoder itself: a loop that takes a picture, says where the mount
    /// is from it, compares that with what the driver says, and stops the
    /// mount when either breaks a rule.
    ///
    /// It learns as it goes. Whenever the driver reports the mount sitting
    /// still at a pose, the picture is filed under that pose, so a map built
    /// by a survey keeps growing through every night after, and a rig with
    /// no survey at all learns its usual targets within a week. Learning
    /// stops the moment a rule is broken: a picture of the mount somewhere
    /// wrong must never be filed as what "right" looks like.
    /// </summary>
    public sealed class PierWatcher : BaseINPC, IDisposable {
        private readonly PierWatchSettings settings;
        private readonly ITelescopeMediator telescope;
        private readonly FrameSource source = new();
        private readonly object gate = new();

        private PositionMap map;
        private CancellationTokenSource loop;
        private Task loopTask;
        private int violationsInARow;
        private bool mapDirty;
        private DateTime mapSavedUtc = DateTime.UtcNow;
        private Pose? previousClaim;
        private DateTime previousClaimAt;
        private DateTime stillSince;

        private bool watching;
        private string status = "not watching";
        private string lastError = "";
        private BitmapSource lastImage;
        private string lastImageText = "";
        private DateTime? lastPictureUtc;
        private Estimate lastEstimate = Estimate.None;
        private Claim lastClaim = Claim.None;
        private Judgement lastJudgement;
        private bool tripped;
        private string tripReason = "";
        private DateTime? trippedUtc;

        public PierWatcher(PierWatchSettings settings, ITelescopeMediator telescope) {
            this.settings = settings;
            this.telescope = telescope;
            map = LoadMap();
            settings.PropertyChanged += (_, e) => {
                // A new thumbnail size, or a new profile, is a new map.
                if (e.PropertyName is nameof(PierWatchSettings.ThumbWidth) or nameof(PierWatchSettings.ThumbHeight)
                    or nameof(PierWatchSettings.MapPath) or null) {
                    lock (gate) {
                        if (map.Width != settings.ThumbWidth || map.Height != settings.ThumbHeight
                                || e.PropertyName is nameof(PierWatchSettings.MapPath) or null) {
                            SaveMap();
                            map = LoadMap();
                        }
                    }
                    RaisePropertyChanged(nameof(SampleCount));
                }
            };
        }

        // -- what the panel shows ----------------------------------------------

        public bool Watching { get => watching; private set { watching = value; RaisePropertyChanged(); } }
        public string Status { get => status; private set { status = value ?? ""; RaisePropertyChanged(); } }
        public string LastError { get => lastError; private set { lastError = value ?? ""; RaisePropertyChanged(); } }
        public BitmapSource LastImage { get => lastImage; private set { lastImage = value; RaisePropertyChanged(); } }
        public string LastImageText { get => lastImageText; private set { lastImageText = value ?? ""; RaisePropertyChanged(); } }
        public DateTime? LastPictureUtc { get => lastPictureUtc; private set { lastPictureUtc = value; RaisePropertyChanged(); } }
        public Estimate LastEstimate { get => lastEstimate; private set { lastEstimate = value; RaisePropertyChanged(); RaisePropertyChanged(nameof(EstimateText)); } }
        public Claim LastClaim { get => lastClaim; private set { lastClaim = value; RaisePropertyChanged(); RaisePropertyChanged(nameof(MountText)); } }
        public Judgement LastJudgement { get => lastJudgement; private set { lastJudgement = value; RaisePropertyChanged(); RaisePropertyChanged(nameof(VerdictText)); RaisePropertyChanged(nameof(VerdictIsViolation)); RaisePropertyChanged(nameof(VerdictIsSafe)); } }
        public bool Tripped { get => tripped; private set { tripped = value; RaisePropertyChanged(); } }
        public string TripReason { get => tripReason; private set { tripReason = value ?? ""; RaisePropertyChanged(); } }
        public DateTime? TrippedUtc { get => trippedUtc; private set { trippedUtc = value; RaisePropertyChanged(); } }
        public int SampleCount { get { lock (gate) return map.Count; } }

        public string EstimateText => !lastEstimate.Known
            ? "nothing learned yet"
            : $"{lastEstimate.Pose}   match {lastEstimate.Score:0.00}, rival {lastEstimate.Rival:0.00}";

        public string MountText => lastClaim.Known ? lastClaim.Pose.ToString() : "no mount connected";

        public string VerdictText => lastJudgement == null ? "" : lastJudgement.Verdict switch {
            Verdict.Safe => "Safe: " + lastJudgement.Reason,
            Verdict.Unsure => "Unsure: " + lastJudgement.Reason,
            _ => "STOP: " + lastJudgement.Reason,
        };

        public bool VerdictIsViolation => lastJudgement?.Verdict == Verdict.Violation;
        public bool VerdictIsSafe => lastJudgement?.Verdict == Verdict.Safe;

        /// <summary>Whether a picture has arrived recently enough for the verdict to mean anything now.</summary>
        public bool PictureFresh => lastPictureUtc != null
            && (DateTime.UtcNow - lastPictureUtc.Value).TotalSeconds < Math.Max(10, settings.PollSeconds * 3 + 5);

        // -- running -----------------------------------------------------------

        public void Start() {
            lock (gate) {
                if (loop != null) return;
                loop = new CancellationTokenSource();
                var token = loop.Token;
                loopTask = Task.Run(() => RunAsync(token), token);
            }
            Watching = true;
            Status = "watching";
            Logger.Info("Pier Watch: watching " + settings.CameraUrl);
        }

        public void Stop() {
            CancellationTokenSource running;
            lock (gate) {
                running = loop;
                loop = null;
            }
            if (running == null) return;
            running.Cancel();
            try { loopTask?.Wait(TimeSpan.FromSeconds(5)); } catch (Exception) { }
            running.Dispose();
            Watching = false;
            Status = "not watching";
            SaveMap();
            Logger.Info("Pier Watch: stopped watching");
        }

        /// <summary>The operator has looked and is content: the mount may move again.</summary>
        public void ClearTrip() {
            Tripped = false;
            TripReason = "";
            TrippedUtc = null;
            violationsInARow = 0;
            Logger.Info("Pier Watch: trip cleared by the operator");
        }

        /// <summary>One picture now, shown in the panel, to check the address: its size, or why it failed.</summary>
        public async Task<string> TestCameraAsync(CancellationToken token) {
            try {
                var bytes = await source.FetchAsync(settings.CameraUrl, token).ConfigureAwait(false);
                var image = Thumbnails.Decode(bytes);
                LastImage = image;
                LastImageText = $"{image.PixelWidth}×{image.PixelHeight}, {bytes.Length / 1024} KB";
                LastError = "";
                return $"Camera answered: {LastImageText}";
            } catch (Exception ex) {
                LastError = ex.Message;
                return "Camera: " + ex.Message;
            }
        }

        /// <summary>File the picture of this moment under where the mount says it is, still or not.</summary>
        public async Task<bool> LearnNowAsync(CancellationToken token) {
            var bytes = await source.FetchAsync(settings.CameraUrl, token).ConfigureAwait(false);
            var print = Thumbnails.FromImageBytes(bytes, settings.Crop, settings.ThumbWidth, settings.ThumbHeight);
            var claim = ReadClaim(out _);
            if (!claim.Known) return false;
            File(print, claim.Pose);
            return true;
        }

        public void ClearMap() {
            lock (gate) {
                map.Clear();
                mapDirty = true;
            }
            SaveMap();
            RaisePropertyChanged(nameof(SampleCount));
            Logger.Info("Pier Watch: the map was cleared");
        }

        public void SaveMap() {
            try {
                lock (gate) {
                    if (!mapDirty) return;
                    map.Save(settings.MapPath);
                    mapDirty = false;
                    mapSavedUtc = DateTime.UtcNow;
                }
            } catch (Exception ex) {
                Logger.Error("Pier Watch could not save its map", ex);
            }
        }

        // -- the loop ----------------------------------------------------------

        private async Task RunAsync(CancellationToken token) {
            while (!token.IsCancellationRequested) {
                var started = DateTime.UtcNow;
                try {
                    await TickAsync(token).ConfigureAwait(false);
                    LastError = "";
                } catch (OperationCanceledException) when (token.IsCancellationRequested) {
                    break;
                } catch (Exception ex) {
                    LastError = ex.Message;
                    Status = "camera: " + ex.Message;
                }
                var spent = DateTime.UtcNow - started;
                var wait = TimeSpan.FromSeconds(settings.PollSeconds) - spent;
                if (wait > TimeSpan.Zero) {
                    try { await Task.Delay(wait, token).ConfigureAwait(false); } catch (OperationCanceledException) { break; }
                }
            }
        }

        private async Task TickAsync(CancellationToken token) {
            var bytes = await source.FetchAsync(settings.CameraUrl, token).ConfigureAwait(false);
            var image = Thumbnails.Decode(bytes);
            var (gray, width, height) = Thumbnails.ToGray(image);
            var print = Thumbnails.Reduce(gray, width, height, settings.Crop, settings.ThumbWidth, settings.ThumbHeight);
            LastImage = image;
            LastImageText = $"{width}×{height}";
            LastPictureUtc = DateTime.UtcNow;

            Match match;
            lock (gate) match = map.Find(print);
            var estimate = match == null ? Estimate.None : new Estimate(match.Best.Pose, match.Score, match.Rival, true);
            var claim = ReadClaim(out var info);
            var judgement = Judge.Decide(estimate, claim, settings.ToLimits());
            LastEstimate = estimate;
            LastClaim = claim;
            LastJudgement = judgement;

            if (judgement.Verdict == Verdict.Violation) {
                violationsInARow++;
                if (violationsInARow >= settings.ConfirmPictures) Trip(judgement.Reason);
            } else {
                violationsInARow = 0;
                if (settings.LearnAutomatically && claim.Known && info != null && !info.Slewing && IsStill(claim)) {
                    File(print, claim.Pose);
                }
            }
            Status = Tripped ? "tripped - " + TripReason : judgement.Verdict switch {
                Verdict.Safe => "watching - safe",
                Verdict.Unsure => "watching - unsure",
                _ => "watching - rule broken",
            };
            if (mapDirty && (DateTime.UtcNow - mapSavedUtc).TotalSeconds > 60) SaveMap();
        }

        /// <summary>Where the driver says the mount is, as a pose: hour angle from its own sidereal time.</summary>
        private Claim ReadClaim(out TelescopeInfo info) {
            info = null;
            try {
                info = telescope?.GetInfo();
            } catch (Exception) {
                return Claim.None;
            }
            if (info == null || !info.Connected) return Claim.None;
            if (double.IsNaN(info.SiderealTime) || double.IsNaN(info.RightAscension) || double.IsNaN(info.Declination)) return Claim.None;
            var ha = SkyGeometry.HourAngle(info.SiderealTime, info.RightAscension);
            var side = info.SideOfPier switch {
                PierSide.pierEast => Side.East,
                PierSide.pierWest => Side.West,
                _ => Side.Unknown,
            };
            return new Claim(new Pose(ha, info.Declination, side), true);
        }

        /// <summary>
        /// Has the driver reported the same pose for a couple of seconds? Only
        /// tracking moves the hour angle, by a thousandth of a degree a
        /// second, so "the same" is a small tolerance rather than equality.
        /// </summary>
        private bool IsStill(Claim claim) {
            var now = DateTime.UtcNow;
            var still = previousClaim is Pose before
                && before.PierSide == claim.Pose.PierSide
                && before.SeparationFrom(claim.Pose) < 0.05
                && (now - previousClaimAt).TotalSeconds < 30;
            if (!still) stillSince = now;
            previousClaim = claim.Pose;
            previousClaimAt = now;
            return still && (now - stillSince).TotalSeconds >= 2.0;
        }

        private void File(Fingerprint print, Pose pose) {
            lock (gate) {
                map.Add(new PoseSample {
                    HourAngle = pose.HourAngle, Declination = pose.Declination, PierSide = pose.PierSide,
                    TakenUtc = DateTime.UtcNow, Gray = print.Gray,
                });
                mapDirty = true;
            }
            RaisePropertyChanged(nameof(SampleCount));
        }

        /// <summary>
        /// Stop the mount and say so. The first time it is a trip, which stays
        /// until the operator clears it; every confirmed violation after that
        /// stops the mount again, because a mount that moved while tripped
        /// was moved by somebody, and the rule is still broken.
        /// </summary>
        private void Trip(string reason) {
            var first = !Tripped;
            if (first) {
                Tripped = true;
                TripReason = reason;
                TrippedUtc = DateTime.UtcNow;
                Logger.Error("Pier Watch STOPPED THE MOUNT: " + reason);
                try { Notification.ShowError("Pier Watch stopped the mount: " + reason); } catch (Exception) { }
            }
            try {
                if (settings.StopSlew) telescope?.StopSlew();
                if (settings.StopTracking) telescope?.SetTrackingEnabled(false);
            } catch (Exception ex) {
                Logger.Error("Pier Watch could not stop the mount", ex);
            }
        }

        private PositionMap LoadMap() {
            try {
                var loaded = PositionMap.Load(settings.MapPath);
                if (loaded != null && loaded.Width == settings.ThumbWidth && loaded.Height == settings.ThumbHeight) {
                    Logger.Info($"Pier Watch: {loaded.Count} poses read from {settings.MapPath}");
                    return loaded;
                }
                if (loaded != null) Logger.Warning("Pier Watch: the saved map is a different thumbnail size and was set aside");
            } catch (Exception ex) {
                Logger.Error("Pier Watch could not read its map; starting with an empty one", ex);
            }
            return new PositionMap(settings.ThumbWidth, settings.ThumbHeight);
        }

        public void Dispose() {
            Stop();
            source.Dispose();
        }
    }
}
