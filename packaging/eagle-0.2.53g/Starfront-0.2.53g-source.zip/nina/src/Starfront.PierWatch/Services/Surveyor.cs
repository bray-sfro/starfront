using NINA.Astrometry;
using NINA.Core.Model;
using NINA.Core.Utility;
using NINA.Equipment.Interfaces.Mediator;
using Starfront.PierWatch.Vision;

namespace Starfront.PierWatch.Services {

    /// <summary>
    /// Builds the map in one go: walks the mount through a grid of poses
    /// and files a picture at each.
    ///
    /// The grid is in hour angle and declination, because that is what the
    /// camera sees; the right ascension to slew to is worked out from the
    /// sidereal time at that moment. Only poses above the horizon limit
    /// with a margin, and within the meridian limit, are visited - the
    /// survey must never itself do what the watch exists to prevent.
    /// </summary>
    public static class Surveyor {
        /// <summary>Degrees above the horizon limit the survey keeps to.</summary>
        public const double HorizonMargin = 5.0;

        /// <summary>
        /// The poses to visit, in an order that keeps each slew short: rows of
        /// declination, swept east to west and back.
        /// </summary>
        public static IReadOnlyList<Pose> Grid(double latitude, double horizonLimit, double pastMeridianHours, double stepDegrees) {
            stepDegrees = Math.Clamp(stepDegrees, 5, 45);
            var stepHours = stepDegrees / 15.0;
            var reach = pastMeridianHours > 0 ? Math.Min(6.0, pastMeridianHours) : 6.0;
            var poses = new List<Pose>();
            var row = 0;
            for (var dec = -90.0 + stepDegrees; dec <= 90.0 - 1e-9; dec += stepDegrees, row++) {
                var line = new List<Pose>();
                for (var ha = -reach; ha <= reach + 1e-9; ha += stepHours) {
                    var (alt, _) = SkyGeometry.AltAz(ha, dec, latitude);
                    if (alt < horizonLimit + HorizonMargin) continue;
                    line.Add(new Pose(Math.Round(ha, 4), Math.Round(dec, 2), Side.Unknown));
                }
                if (row % 2 == 1) line.Reverse();
                poses.AddRange(line);
            }
            return poses;
        }

        /// <summary>
        /// Slew to each pose, let the mount settle, and file the picture.
        /// Returns how many poses were filed. A slew the mount refuses is
        /// skipped; the operator's own limits in the driver are the last word.
        /// </summary>
        public static async Task<int> RunAsync(PierWatcher watcher, ITelescopeMediator telescope, double longitude,
                                               IReadOnlyList<Pose> grid, double settleSeconds,
                                               IProgress<ApplicationStatus> progress, CancellationToken token) {
            var learned = 0;
            for (var i = 0; i < grid.Count; i++) {
                token.ThrowIfCancellationRequested();
                if (watcher.Tripped) throw new InvalidOperationException("Pier Watch has tripped: " + watcher.TripReason);
                var pose = grid[i];
                var sidereal = AstroUtil.GetLocalSiderealTime(DateTime.Now, longitude);
                var ra = sidereal - pose.HourAngle;
                ra %= 24.0;
                if (ra < 0) ra += 24.0;
                progress?.Report(new ApplicationStatus { Status = $"Pier Watch survey {i + 1}/{grid.Count}: {pose}" });
                var coordinates = new Coordinates(Angle.ByHours(ra), Angle.ByDegree(pose.Declination), Epoch.JNOW);
                bool slewed;
                try {
                    slewed = await telescope.SlewToCoordinatesAsync(coordinates, token).ConfigureAwait(false);
                } catch (OperationCanceledException) {
                    throw;
                } catch (Exception ex) {
                    Logger.Warning($"Pier Watch survey: the mount would not go to {pose} - {ex.Message}");
                    continue;
                }
                if (!slewed) {
                    Logger.Warning($"Pier Watch survey: the mount refused {pose}");
                    continue;
                }
                await Task.Delay(TimeSpan.FromSeconds(Math.Clamp(settleSeconds, 0.5, 30)), token).ConfigureAwait(false);
                try {
                    if (await watcher.LearnNowAsync(token).ConfigureAwait(false)) learned++;
                } catch (OperationCanceledException) {
                    throw;
                } catch (Exception ex) {
                    Logger.Warning($"Pier Watch survey: no picture at {pose} - {ex.Message}");
                }
            }
            watcher.SaveMap();
            Logger.Info($"Pier Watch survey: {learned} of {grid.Count} poses filed");
            return learned;
        }
    }
}
