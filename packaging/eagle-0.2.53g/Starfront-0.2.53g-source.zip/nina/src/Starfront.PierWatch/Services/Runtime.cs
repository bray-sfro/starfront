using NINA.Core.Utility;
using NINA.Equipment.Interfaces.Mediator;
using NINA.Profile.Interfaces;
using Starfront.PierWatch.Settings;

namespace Starfront.PierWatch.Services {

    /// <summary>
    /// The one watcher, shared by every part of the plugin.
    ///
    /// N.I.N.A. composes the manifest, the dock panel, the equipment
    /// provider and the sequencer items in separate MEF containers, so a
    /// service imported in one is not the instance another gets. The host's
    /// own mediators *are* the same instances everywhere, so whichever part
    /// arrives first hands them over here and everything after finds the
    /// watcher ready.
    /// </summary>
    public static class Runtime {
        private static readonly object gate = new();
        private static bool started;

        public static PierWatchSettings Settings { get; private set; }
        public static PierWatcher Watcher { get; private set; }
        public static bool Ready => Watcher != null;

        public static void Ensure(IProfileService profiles, ITelescopeMediator telescope) {
            lock (gate) {
                if (Watcher != null) return;
                Settings = new PierWatchSettings(profiles);
                Watcher = new PierWatcher(Settings, telescope);
            }
        }

        /// <summary>Called once the host has loaded the plugin: begin watching if the profile says to.</summary>
        public static void Start() {
            lock (gate) {
                if (started || Watcher == null) return;
                started = true;
            }
            try {
                if (Settings.WatchAtStart && !string.IsNullOrWhiteSpace(Settings.CameraUrl)) Watcher.Start();
            } catch (Exception ex) {
                Logger.Error("Pier Watch could not start watching", ex);
            }
        }

        public static void Shutdown() {
            PierWatcher watcher;
            lock (gate) {
                watcher = Watcher;
                Watcher = null;
                started = false;
            }
            watcher?.Dispose();
        }
    }
}
